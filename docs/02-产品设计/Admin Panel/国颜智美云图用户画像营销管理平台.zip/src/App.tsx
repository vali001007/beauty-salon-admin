import { useState, createContext, useContext } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { DataCollection } from './components/DataCollection';
import { UserProfile } from './components/UserProfile';
import { MarketingStrategy } from './components/MarketingStrategy';
import { MarketingCopywriter } from './components/MarketingCopywriter';
import { EffectTracking } from './components/EffectTracking';
import { StoreConfiguration } from './components/StoreConfiguration';
import { MarketingMaterials } from './components/MarketingMaterials';
import { ProductManual } from './components/ProductManual';
import { BusinessPlan } from './components/BusinessPlan';
import { Website } from './components/Website';
import { ProductBlueprint } from './components/ProductBlueprint';
import { BusinessCanvas } from './components/BusinessCanvas';
import { MarketingDemo } from './components/MarketingDemo';
import { MarketingPlan } from './components/MarketingPlan';

// 腾讯广告投放数据类型
export interface TencentAdConfig {
  enabled: boolean;
  targetAudience: string[];
  radiusKm: number;
  channels: string[];
  budget: number;
  bidStrategy: string;
  ageRange: {
    min: number;
    max: number;
  };
  gender: string;
  interests: string[];
  schedule: {
    startTime: string;
    endTime: string;
    days: string[];
  };
  status: 'pending' | 'approved' | 'running' | 'paused' | 'completed';
  spend: number;
  impressions: number;
  clicks: number;
  ctr: number;
}

// 定义活动数据类型
export interface CampaignData {
  id: number | string;
  name: string;
  type: string;
  status: string;
  targetGroup: string;
  startDate: string;
  endDate: string;
  budget: number;
  spent: number;
  reach: number;
  conversion: number;
  revenue: number;
  publishedToMiniProgram: boolean;
  description?: string;
  image?: string;
  originalPrice?: number;
  currentPrice?: number;
  discount?: string;
  tag?: string;
  tencentAd?: TencentAdConfig;
}

// 活动上下文
interface CampaignContextType {
  campaigns: CampaignData[];
  publishedCampaigns: CampaignData[];
  addCampaign: (campaign: CampaignData) => void;
  updateCampaign: (id: number | string, updates: Partial<CampaignData>) => void;
  publishToMiniProgram: (id: number | string) => void;
  publishToTencentAd: (id: number | string, adConfig: TencentAdConfig) => void;
}

const CampaignContext = createContext<CampaignContextType | undefined>(undefined);

export const useCampaigns = () => {
  const context = useContext(CampaignContext);
  if (!context) {
    throw new Error('useCampaigns must be used within a CampaignProvider');
  }
  return context;
};

// 初始活动数据 - 来自营销策略模块
const initialCampaigns: CampaignData[] = [
  {
    id: 1,
    name: '春季护肤套餐',
    type: '促销活动',
    status: '进行中',
    targetGroup: '高价值客户',
    startDate: '2024-01-01',
    endDate: '2024-03-31',
    budget: 15000,
    spent: 8500,
    reach: 1247,
    conversion: 24.5,
    revenue: 45680,
    publishedToMiniProgram: true,
    description: '专业敏感肌护理，温和修护',
    originalPrice: 398,
    currentPrice: 298,
    discount: '限时',
    tag: '限时',
    tencentAd: {
      enabled: true,
      targetAudience: ['女性', '25-40岁'],
      radiusKm: 5,
      channels: ['朋友圈', '公众号'],
      budget: 3000,
      bidStrategy: 'CPC',
      ageRange: { min: 25, max: 40 },
      gender: '女性',
      interests: ['美容护肤', '时尚生活'],
      schedule: {
        startTime: '09:00',
        endTime: '22:00',
        days: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
      },
      status: 'running',
      spend: 1680,
      impressions: 45230,
      clicks: 892,
      ctr: 1.97
    }
  },
  {
    id: 2,
    name: '新客体验优惠',
    type: '获客活动',
    status: '进行中',
    targetGroup: '新客户',
    startDate: '2024-01-15',
    endDate: '2024-02-29',
    budget: 8000,
    spent: 3200,
    reach: 856,
    conversion: 18.2,
    revenue: 12340,
    publishedToMiniProgram: true,
    description: '进口精华，深层滋养肌肤',
    currentPrice: 588,
    tag: '热门',
    tencentAd: {
      enabled: true,
      targetAudience: ['年轻女性', '18-35岁'],
      radiusKm: 10,
      channels: ['朋友圈', '视频号'],
      budget: 2000,
      bidStrategy: 'CPM',
      ageRange: { min: 18, max: 35 },
      gender: '女性',
      interests: ['护肤', '美妆'],
      schedule: {
        startTime: '08:00',
        endTime: '23:00',
        days: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
      },
      status: 'running',
      spend: 756,
      impressions: 28950,
      clicks: 432,
      ctr: 1.49
    }
  },
  {
    id: 3,
    name: '会员专享活动',
    type: '留存活动',
    status: '计划中',
    targetGroup: '稳定客户',
    startDate: '2024-02-01',
    endDate: '2024-02-14',
    budget: 12000,
    spent: 0,
    reach: 0,
    conversion: 0,
    revenue: 0,
    publishedToMiniProgram: false,
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [campaigns, setCampaigns] = useState<CampaignData[]>(initialCampaigns);

  // 活动管理函数
  const addCampaign = (campaign: CampaignData) => {
    setCampaigns(prev => [...prev, campaign]);
  };

  const updateCampaign = (id: number | string, updates: Partial<CampaignData>) => {
    setCampaigns(prev => prev.map(campaign => 
      campaign.id === id ? { ...campaign, ...updates } : campaign
    ));
  };

  const publishToMiniProgram = (id: number | string) => {
    updateCampaign(id, { publishedToMiniProgram: true });
  };

  const publishToTencentAd = (id: number | string, adConfig: TencentAdConfig) => {
    updateCampaign(id, { 
      tencentAd: { ...adConfig, enabled: true, status: 'pending' }
    });
  };

  // 获取已发布到小程序的活动
  const publishedCampaigns = campaigns.filter(campaign => 
    campaign.publishedToMiniProgram && campaign.status === '进行中'
  );

  const campaignContextValue: CampaignContextType = {
    campaigns,
    publishedCampaigns,
    addCampaign,
    updateCampaign,
    publishToMiniProgram,
    publishToTencentAd
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'data-collection':
        return <DataCollection />;
      case 'user-profile':
        return <UserProfile onNavigateToStrategy={() => setActiveTab('marketing-strategy')} />;
      case 'marketing-strategy':
        return <MarketingStrategy />;
      case 'marketing-copywriter':
        return <MarketingCopywriter />;
      case 'effect-tracking':
        return <EffectTracking />;
      case 'store-configuration':
        return <StoreConfiguration />;
      case 'marketing-materials':
        return <MarketingMaterials onNavigate={setActiveTab} />;
      case 'product-manual':
        return <ProductManual />;
      case 'business-plan':
        return <BusinessPlan />;
      case 'product-blueprint':
        return <ProductBlueprint />;
      case 'business-canvas':
        return <BusinessCanvas />;
      case 'marketing-demo':
        return <MarketingDemo onNavigateToApp={() => setActiveTab('dashboard')} />;
      case 'marketing-plan':
        return <MarketingPlan onNavigateToApp={() => setActiveTab('dashboard')} />;
      case 'website':
        return <Website onNavigateToApp={() => setActiveTab('dashboard')} />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <CampaignContext.Provider value={campaignContextValue}>
      {(activeTab === 'website' || activeTab === 'marketing-demo' || activeTab === 'marketing-plan' || activeTab === 'product-manual') ? (
        renderContent()
      ) : (
        <div className="flex h-screen bg-background">
          <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
          <main className="flex-1 overflow-auto">
            <div className="p-6">
              {renderContent()}
            </div>
          </main>
        </div>
      )}
    </CampaignContext.Provider>
  );
}