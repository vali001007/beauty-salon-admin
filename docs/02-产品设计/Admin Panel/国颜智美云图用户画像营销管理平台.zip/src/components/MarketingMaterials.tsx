import { FileText, Globe, GitBranch, PieChart, Megaphone, Clipboard, BookOpen } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

interface MarketingMaterialsProps {
  onNavigate: (tab: string) => void;
}

const materials = [
  {
    id: 'product-manual',
    title: '产品说明书',
    description: '完整的产品介绍与功能说明文档',
    icon: BookOpen,
    color: 'text-indigo-500',
    bgColor: 'bg-indigo-50',
  },
  {
    id: 'business-plan',
    title: '商业计划书',
    description: '完整的商业规划与策略文档',
    icon: FileText,
    color: 'text-blue-500',
    bgColor: 'bg-blue-50',
  },
  {
    id: 'product-blueprint',
    title: '产品蓝图',
    description: '产品功能架构与开发路线图',
    icon: GitBranch,
    color: 'text-purple-500',
    bgColor: 'bg-purple-50',
  },
  {
    id: 'business-canvas',
    title: '商业画布',
    description: '精益商业模式可视化分析',
    icon: PieChart,
    color: 'text-green-500',
    bgColor: 'bg-green-50',
  },
  {
    id: 'website',
    title: '官网展示',
    description: '企业官方网站展示页面',
    icon: Globe,
    color: 'text-cyan-500',
    bgColor: 'bg-cyan-50',
  },
  {
    id: 'marketing-demo',
    title: '营销演示',
    description: '营销活动展示与演示页面',
    icon: Megaphone,
    color: 'text-orange-500',
    bgColor: 'bg-orange-50',
  },
  {
    id: 'marketing-plan',
    title: '营销计划书',
    description: '详细的营销策略与执行计划',
    icon: Clipboard,
    color: 'text-pink-500',
    bgColor: 'bg-pink-50',
  },
];

export function MarketingMaterials({ onNavigate }: MarketingMaterialsProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl mb-2">营销材料</h1>
        <p className="text-muted-foreground">
          访问各类营销材料、展示页面和战略文档
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {materials.map((material) => {
          const Icon = material.icon;
          return (
            <Card
              key={material.id}
              className="cursor-pointer hover:shadow-lg transition-all hover:scale-[1.02] border-2 hover:border-primary"
              onClick={() => onNavigate(material.id)}
            >
              <CardHeader>
                <div className={`w-12 h-12 rounded-lg ${material.bgColor} flex items-center justify-center mb-4`}>
                  <Icon className={`w-6 h-6 ${material.color}`} />
                </div>
                <CardTitle>{material.title}</CardTitle>
                <CardDescription>{material.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <button 
                  className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    onNavigate(material.id);
                  }}
                >
                  查看详情
                </button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
