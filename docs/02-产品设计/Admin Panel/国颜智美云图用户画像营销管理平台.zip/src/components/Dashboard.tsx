import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  Users, 
  TrendingUp, 
  Target, 
  DollarSign,
  ArrowUp,
  ArrowDown
} from 'lucide-react';

const metrics = [
  {
    title: '总客户数',
    value: '2,847',
    change: '+12.5%',
    trend: 'up',
    icon: Users,
  },
  {
    title: '活跃客户',
    value: '1,932',
    change: '+8.2%',
    trend: 'up',
    icon: TrendingUp,
  },
  {
    title: '营销转化率',
    value: '18.4%',
    change: '-2.1%',
    trend: 'down',
    icon: Target,
  },
  {
    title: '月收入',
    value: '¥284,750',
    change: '+15.8%',
    trend: 'up',
    icon: DollarSign,
  },
];

const customerSegments = [
  { name: '高价值客户', count: 342, percentage: 85, color: 'bg-green-500' },
  { name: '潜在客户', count: 756, percentage: 65, color: 'bg-blue-500' },
  { name: '流失风险客户', count: 123, percentage: 30, color: 'bg-red-500' },
  { name: '新客户', count: 189, percentage: 45, color: 'bg-purple-500' },
];

const recentCampaigns = [
  {
    name: '春季护肤套餐',
    status: '进行中',
    conversion: '24.5%',
    budget: '¥15,000',
  },
  {
    name: '会员专享活动',
    status: '已完成',
    conversion: '18.2%',
    budget: '¥8,500',
  },
  {
    name: '新客优惠',
    status: '计划中',
    conversion: '-',
    budget: '¥12,000',
  },
];

export function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-medium mb-2">仪表板</h1>
        <p className="text-muted-foreground">
          欢迎使用智美云图用户画像营销管理平台
        </p>
      </div>

      {/* 关键指标 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          const TrendIcon = metric.trend === 'up' ? ArrowUp : ArrowDown;
          return (
            <Card key={metric.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {metric.title}
                </CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metric.value}</div>
                <div className="flex items-center text-xs text-muted-foreground">
                  <TrendIcon className={`h-3 w-3 mr-1 ${
                    metric.trend === 'up' ? 'text-green-500' : 'text-red-500'
                  }`} />
                  <span className={
                    metric.trend === 'up' ? 'text-green-500' : 'text-red-500'
                  }>
                    {metric.change}
                  </span>
                  <span className="ml-1">较上月</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 客户细分 */}
        <Card>
          <CardHeader>
            <CardTitle>客户细分分析</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {customerSegments.map((segment) => (
              <div key={segment.name} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">{segment.name}</span>
                  <span className="text-sm text-muted-foreground">
                    {segment.count} 人
                  </span>
                </div>
                <Progress value={segment.percentage} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* 营销活动 */}
        <Card>
          <CardHeader>
            <CardTitle>最近营销活动</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentCampaigns.map((campaign) => (
                <div key={campaign.name} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div>
                    <p className="font-medium">{campaign.name}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={
                        campaign.status === '进行中' ? 'default' :
                        campaign.status === '已完成' ? 'secondary' : 'outline'
                      }>
                        {campaign.status}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        转化率: {campaign.conversion}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{campaign.budget}</p>
                    <p className="text-sm text-muted-foreground">预算</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}