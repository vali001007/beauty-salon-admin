import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { 
  Brain, 
  Database, 
  Users, 
  Target, 
  TrendingUp, 
  PenTool,
  Store,
  BarChart3,
  Globe,
  FileText,
  Smartphone,
  Cloud,
  Shield,
  Zap,
  ArrowRight,
  ArrowDown,
  ArrowUpRight,
  GitBranch,
  Layers,
  Settings,
  UserCheck,
  MessageCircle,
  Megaphone,
  CheckCircle,
  Circle,
  ArrowRightLeft
} from 'lucide-react';

export function ProductBlueprint() {
  const [activeView, setActiveView] = useState('architecture');

  // 系统架构层级
  const architectureLayers = [
    {
      name: '展示层',
      color: 'bg-blue-100 border-blue-300',
      components: [
        { name: '官网展示', icon: Globe, description: '营销官网和品牌展示' },
        { name: '管理平台', icon: BarChart3, description: '业务管理控制台' },
        { name: '小程序界面', icon: Smartphone, description: '客户端应用界面' }
      ]
    },
    {
      name: '业务层',
      color: 'bg-green-100 border-green-300',
      components: [
        { name: '用户画像引擎', icon: Brain, description: 'AI驱动的客户分析' },
        { name: '营销策略引擎', icon: Target, description: '智能营销策略生成' },
        { name: '内容生成引擎', icon: PenTool, description: 'AI文案和内容创作' },
        { name: '效果追踪引擎', icon: TrendingUp, description: '数据分析和ROI监控' }
      ]
    },
    {
      name: '数据层',
      color: 'bg-purple-100 border-purple-300',
      components: [
        { name: '客户数据库', icon: Users, description: '客户信息和行为数据' },
        { name: '营销数据库', icon: Database, description: '活动和效果数据' },
        { name: '内容资源库', icon: FileText, description: '文案和素材管理' },
        { name: '业务配置库', icon: Settings, description: '店铺和服务配置' }
      ]
    },
    {
      name: '基础设施层',
      color: 'bg-gray-100 border-gray-300',
      components: [
        { name: '云计算平台', icon: Cloud, description: '弹性计算和存储' },
        { name: '安全防护', icon: Shield, description: '数据安全和隐私保护' },
        { name: '性能监控', icon: Zap, description: '系统性能和稳定性' }
      ]
    }
  ];

  // 核心功能模块
  const coreModules = [
    {
      id: 'dashboard',
      name: '仪表板概览',
      icon: BarChart3,
      description: '业务数据总览和关键指标监控',
      color: 'border-blue-500',
      connections: ['data-collection', 'user-profile', 'effect-tracking']
    },
    {
      id: 'data-collection',
      name: '数据采集',
      icon: Database,
      description: '多渠道客户数据收集和整理',
      color: 'border-green-500',
      connections: ['user-profile', 'marketing-strategy']
    },
    {
      id: 'user-profile',
      name: '用户画像',
      icon: Users,
      description: 'AI驱动的客户画像分析和标签化',
      color: 'border-purple-500',
      connections: ['marketing-strategy', 'marketing-copywriter']
    },
    {
      id: 'marketing-strategy',
      name: '营销策略',
      icon: Target,
      description: '个性化营销方案制定和执行',
      color: 'border-orange-500',
      connections: ['marketing-copywriter', 'effect-tracking', 'miniprogram']
    },
    {
      id: 'marketing-copywriter',
      name: '文案生成',
      icon: PenTool,
      description: 'AI智能文案创作和内容优化',
      color: 'border-pink-500',
      connections: ['miniprogram', 'tencent-ads']
    },
    {
      id: 'effect-tracking',
      name: '效果追踪',
      icon: TrendingUp,
      description: '营销效果分析和ROI监控',
      color: 'border-red-500',
      connections: ['dashboard']
    },
    {
      id: 'store-config',
      name: '网店配置',
      icon: Store,
      description: '美容院信息和服务管理',
      color: 'border-teal-500',
      connections: ['miniprogram']
    },
    {
      id: 'miniprogram',
      name: '小程序发布',
      icon: Smartphone,
      description: '客户端应用和在线服务',
      color: 'border-indigo-500',
      connections: []
    }
  ];

  // 用户角色和流程
  const userRoles = [
    {
      name: '美容院老板',
      icon: UserCheck,
      color: 'bg-blue-500',
      responsibilities: ['业务决策', '数据分析', '策略制定', 'ROI监控'],
      mainFlows: ['查看仪表板', '分析用户画像', '制定营销策略', '监控效果']
    },
    {
      name: '营销经理',
      icon: Megaphone,
      color: 'bg-green-500',
      responsibilities: ['活动策划', '内容创作', '渠道管理', '客户沟通'],
      mainFlows: ['创建营销活动', '生成营销文案', '发布到小程序', '追踪效果']
    },
    {
      name: '数据分析师',
      icon: BarChart3,
      color: 'bg-purple-500',
      responsibilities: ['数据收集', '用户分析', '效果评估', '优化建议'],
      mainFlows: ['收集客户数据', '构建用户画像', '分析营销效果', '优化策略']
    },
    {
      name: '客户',
      icon: Users,
      color: 'bg-orange-500',
      responsibilities: ['服务预约', '信息浏览', '活动参与', '反馈评价'],
      mainFlows: ['浏览小程序', '预约服务', '参与活动', '享受服务']
    }
  ];

  // 业务流程
  const businessFlow = [
    { 
      step: 1, 
      name: '数据采集', 
      description: '收集客户基础信息、消费行为、肌肤健康等多维度数据',
      status: 'completed'
    },
    { 
      step: 2, 
      name: '画像构建', 
      description: '利用AI算法分析客户数据，构建精准的用户画像标签',
      status: 'completed'
    },
    { 
      step: 3, 
      name: '策略制定', 
      description: '基于用户画像制定个性化营销策略和活动方案',
      status: 'in-progress'
    },
    { 
      step: 4, 
      name: '内容生成', 
      description: 'AI生成针对性营销文案和活动内容',
      status: 'in-progress'
    },
    { 
      step: 5, 
      name: '渠道投放', 
      description: '将营销内容发布到小程序、腾讯广告等渠道',
      status: 'pending'
    },
    { 
      step: 6, 
      name: '效果监控', 
      description: '实时监控营销效果，分析ROI和客户反馈',
      status: 'pending'
    },
    { 
      step: 7, 
      name: '策略优化', 
      description: '根据效果数据优化营销策略，形成闭环',
      status: 'pending'
    }
  ];

  // 技术栈
  const techStack = {
    frontend: [
      { name: 'React', description: '现代化Web应用框架' },
      { name: 'TypeScript', description: '类型安全的JavaScript' },
      { name: 'Tailwind CSS', description: '原子化CSS框架' },
      { name: 'Vite', description: '快速构建工具' }
    ],
    backend: [
      { name: 'Node.js', description: '服务端JavaScript运行时' },
      { name: 'Express.js', description: 'Web应用框架' },
      { name: 'PostgreSQL', description: '关系型数据库' },
      { name: 'Redis', description: '内存数据库' }
    ],
    ai: [
      { name: 'TensorFlow', description: '机器学习框架' },
      { name: 'OpenAI API', description: '自然语言处理' },
      { name: 'scikit-learn', description: '数据分析和建模' },
      { name: 'Apache Spark', description: '大数据处理' }
    ],
    cloud: [
      { name: '腾讯云', description: '云计算平台' },
      { name: 'Docker', description: '容器化部署' },
      { name: 'Kubernetes', description: '容器编排' },
      { name: 'Nginx', description: '负载均衡和反向代理' }
    ]
  };

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <GitBranch className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold">智美云图产品蓝图</h1>
        </div>
        <p className="text-muted-foreground">
          美容院智能营销管理平台的完整产品架构、功能模块和技术实现方案
        </p>
      </div>

      {/* 视图切换 */}
      <Tabs value={activeView} onValueChange={setActiveView} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="architecture">系统架构</TabsTrigger>
          <TabsTrigger value="modules">功能模块</TabsTrigger>
          <TabsTrigger value="users">用户角色</TabsTrigger>
          <TabsTrigger value="process">业务流程</TabsTrigger>
          <TabsTrigger value="tech">技术栈</TabsTrigger>
        </TabsList>

        {/* 系统架构视图 */}
        <TabsContent value="architecture" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Layers className="w-5 h-5" />
                四层系统架构
              </CardTitle>
              <p className="text-muted-foreground">
                采用分层架构设计，确保系统的可扩展性、可维护性和高性能
              </p>
            </CardHeader>
            <CardContent className="space-y-8">
              {architectureLayers.map((layer, layerIndex) => (
                <div key={layerIndex} className="space-y-4">
                  <div className={`p-4 rounded-lg border-2 ${layer.color}`}>
                    <h3 className="font-medium mb-4">{layer.name}</h3>
                    <div className="grid md:grid-cols-3 gap-4">
                      {layer.components.map((component, componentIndex) => {
                        const Icon = component.icon;
                        return (
                          <div key={componentIndex} className="bg-white p-3 rounded-lg border shadow-sm">
                            <div className="flex items-center gap-2 mb-2">
                              <Icon className="w-4 h-4 text-primary" />
                              <span className="font-medium">{component.name}</span>
                            </div>
                            <p className="text-sm text-muted-foreground">{component.description}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  {layerIndex < architectureLayers.length - 1 && (
                    <div className="flex justify-center">
                      <ArrowDown className="w-6 h-6 text-muted-foreground" />
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* 功能模块视图 */}
        <TabsContent value="modules" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitBranch className="w-5 h-5" />
                核心功能模块关系图
              </CardTitle>
              <p className="text-muted-foreground">
                展示各功能模块之间的依赖关系和数据流向
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {coreModules.map((module) => {
                  const Icon = module.icon;
                  return (
                    <div key={module.id} className={`p-4 rounded-lg border-2 ${module.color} bg-white shadow-sm`}>
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className="w-5 h-5 text-primary" />
                        <h3 className="font-medium">{module.name}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{module.description}</p>
                      {module.connections.length > 0 && (
                        <div className="space-y-1">
                          <div className="text-xs font-medium text-muted-foreground">连接到:</div>
                          <div className="flex flex-wrap gap-1">
                            {module.connections.map((connection) => (
                              <Badge key={connection} variant="secondary" className="text-xs">
                                {coreModules.find(m => m.id === connection)?.name || connection}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 用户角色视图 */}
        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                用户角色和使用流程
              </CardTitle>
              <p className="text-muted-foreground">
                不同用户角色的职责范围和主要使用场景
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {userRoles.map((role, index) => {
                  const Icon = role.icon;
                  return (
                    <div key={index} className="p-6 rounded-lg border bg-card">
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`w-10 h-10 rounded-full ${role.color} flex items-center justify-center`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <h3 className="font-medium">{role.name}</h3>
                      </div>
                      
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2">主要职责</h4>
                          <div className="grid grid-cols-2 gap-1">
                            {role.responsibilities.map((resp, respIndex) => (
                              <div key={respIndex} className="flex items-center gap-2">
                                <CheckCircle className="w-3 h-3 text-green-500" />
                                <span className="text-sm">{resp}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-medium mb-2">主要流程</h4>
                          <div className="space-y-1">
                            {role.mainFlows.map((flow, flowIndex) => (
                              <div key={flowIndex} className="flex items-center gap-2">
                                <ArrowRight className="w-3 h-3 text-muted-foreground" />
                                <span className="text-sm">{flow}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 业务流程视图 */}
        <TabsContent value="process" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ArrowRightLeft className="w-5 h-5" />
                完整业务流程
              </CardTitle>
              <p className="text-muted-foreground">
                从数据采集到效果优化的营销闭环流程
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {businessFlow.map((step, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-medium ${
                        step.status === 'completed' ? 'bg-green-500' :
                        step.status === 'in-progress' ? 'bg-blue-500' : 'bg-gray-400'
                      }`}>
                        {step.step}
                      </div>
                      {index < businessFlow.length - 1 && (
                        <div className="w-px h-8 bg-border mt-2"></div>
                      )}
                    </div>
                    <div className="flex-1 pb-8">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium">{step.name}</h3>
                        <Badge variant={
                          step.status === 'completed' ? 'default' :
                          step.status === 'in-progress' ? 'secondary' : 'outline'
                        }>
                          {step.status === 'completed' ? '已完成' :
                           step.status === 'in-progress' ? '进行中' : '待开始'}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 技术栈视图 */}
        <TabsContent value="tech" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                技术栈架构
              </CardTitle>
              <p className="text-muted-foreground">
                支撑平台运行的完整技术解决方案
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-3 flex items-center gap-2">
                      <Globe className="w-4 h-4 text-blue-500" />
                      前端技术
                    </h3>
                    <div className="space-y-2">
                      {techStack.frontend.map((tech, index) => (
                        <div key={index} className="p-3 rounded-lg border bg-blue-50">
                          <div className="font-medium">{tech.name}</div>
                          <div className="text-sm text-muted-foreground">{tech.description}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3 flex items-center gap-2">
                      <Database className="w-4 h-4 text-green-500" />
                      后端技术
                    </h3>
                    <div className="space-y-2">
                      {techStack.backend.map((tech, index) => (
                        <div key={index} className="p-3 rounded-lg border bg-green-50">
                          <div className="font-medium">{tech.name}</div>
                          <div className="text-sm text-muted-foreground">{tech.description}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-3 flex items-center gap-2">
                      <Brain className="w-4 h-4 text-purple-500" />
                      AI技术
                    </h3>
                    <div className="space-y-2">
                      {techStack.ai.map((tech, index) => (
                        <div key={index} className="p-3 rounded-lg border bg-purple-50">
                          <div className="font-medium">{tech.name}</div>
                          <div className="text-sm text-muted-foreground">{tech.description}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3 flex items-center gap-2">
                      <Cloud className="w-4 h-4 text-orange-500" />
                      云平台
                    </h3>
                    <div className="space-y-2">
                      {techStack.cloud.map((tech, index) => (
                        <div key={index} className="p-3 rounded-lg border bg-orange-50">
                          <div className="font-medium">{tech.name}</div>
                          <div className="text-sm text-muted-foreground">{tech.description}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 总结卡片 */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">产品蓝图总结</h3>
              <p className="text-muted-foreground">
                智美云图采用现代化的分层架构设计，集成AI技术和云计算平台，为美容院提供完整的数字化营销解决方案。
                平台涵盖数据采集、用户画像、策略制定、内容生成、渠道投放和效果追踪的全链路营销服务，
                支持多角色协作和灵活的业务配置，助力美容院实现精准营销和业务增长。
              </p>
              <div className="flex gap-2 mt-4">
                <Badge variant="secondary">分层架构</Badge>
                <Badge variant="secondary">AI驱动</Badge>
                <Badge variant="secondary">全链路营销</Badge>
                <Badge variant="secondary">多角色协作</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}