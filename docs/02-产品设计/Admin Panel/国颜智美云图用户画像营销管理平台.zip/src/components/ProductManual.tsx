import { useState } from 'react';
import { 
  Sparkles, 
  BarChart3, 
  Database, 
  Users, 
  Target, 
  TrendingUp, 
  PenTool, 
  Store,
  CheckCircle2,
  Zap,
  Shield,
  Smartphone,
  Cloud,
  LineChart,
  Heart,
  Award,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import highValueCustomerImg from 'figma:asset/7beebea4358f82c7485cbab47a1d4a7a9a953eca.png';
import mixedSkinImg from 'figma:asset/633b37c179a89568ba3056d069864382ff1c8224.png';
import normalSkinImg from 'figma:asset/af4c42decc14f52c6f66c3ea3a1b3aaa27e1b68b.png';
import sensitiveSkinImg from 'figma:asset/8d1f2bfb7821e868b866b0c11b46cfbe7b2ed7eb.png';
import newCustomerImg from 'figma:asset/e36afb331e943b7d4b34c5dd050ba0f2a19e099d.png';
import churnRiskCustomerImg from 'figma:asset/001c01f1fd19a1a3687278a1a2554f2c4e51f0de.png';
import oilySkinImg from 'figma:asset/3aaa560066067c74349ba3850c1addefb0026562.png';
import sensitiveSkinNewImg from 'figma:asset/c5d9f503102c27d45aa9999f317fecb567678a54.png';
import marketingStrategyDemoImg from 'figma:asset/d957f8b28e280b92f57061448cedbdac2d36a942.png';
import tencentAdDemoImg from 'figma:asset/d957f8b28e280b92f57061448cedbdac2d36a942.png';
import aiRecommendationImg from 'figma:asset/a7cb9e1ffc9a45ddc97a97d4e59e37f6f1ab59a5.png';

export function ProductManual() {
  const [currentPage, setCurrentPage] = useState(0);
  const totalPages = 11;

  const nextPage = () => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 0:
        return (
          <div className="h-full flex flex-col items-center justify-center bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-600 text-white p-16">
            <div className="flex items-center gap-4 mb-8">
              <Sparkles className="w-20 h-20" />
            </div>
            <h1 className="text-6xl mb-6 text-center">美点</h1>
            <h2 className="text-3xl mb-12 text-center opacity-90">美业一站式智能服务平台</h2>
            <div className="w-32 h-1 bg-white/30 mb-12"></div>
            <p className="text-xl text-center opacity-80 max-w-2xl leading-relaxed">
              基于AI的美容院智能营销解决方案<br/>
              提供"数据采集-画像构建-策略执行-效果追踪"全链路服务
            </p>
            <div className="mt-12 text-lg opacity-70">
              产品说明书 v1.0
            </div>
          </div>
        );
      
      case 1:
        return (
          <div className="h-full p-16 flex flex-col">
            <div className="mb-8">
              <h2 className="text-4xl mb-4 text-primary">产品概述</h2>
              <div className="w-20 h-1 bg-primary"></div>
            </div>
            
            <div className="flex-1 grid grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl mb-4 text-foreground">核心价值</h3>
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    智美云图是专为美容院打造的智能营销管理平台，通过AI技术实现精准营销、个性化服务和业绩提升。平台整合了数据采集、用户画像、营销策略、效果追踪等核心功能，帮助美容院实现数字化转型。
                  </p>
                </div>
                
                <div>
                  <h3 className="text-2xl mb-4 text-foreground">目标用户</h3>
                  <ul className="space-y-2 text-lg text-muted-foreground">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                      中小型美容院经营者
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                      美容院连锁品牌
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                      美容健康管理机构
                    </li>
                  </ul>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl mb-4 text-foreground">核心优势</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Zap className="w-6 h-6 text-amber-500 flex-shrink-0 mt-1" />
                      <div>
                        <div className="text-lg mb-1">AI智能分析</div>
                        <div className="text-muted-foreground">基于大数据的用户画像和营销策略</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Smartphone className="w-6 h-6 text-blue-500 flex-shrink-0 mt-1" />
                      <div>
                        <div className="text-lg mb-1">小程序集成</div>
                        <div className="text-muted-foreground">一键发布营销活动到线上</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <LineChart className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                      <div>
                        <div className="text-lg mb-1">全链路追踪</div>
                        <div className="text-muted-foreground">从策划到执行的完整数据闭环</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Shield className="w-6 h-6 text-purple-500 flex-shrink-0 mt-1" />
                      <div>
                        <div className="text-lg mb-1">数据安全</div>
                        <div className="text-muted-foreground">企业级数据保护和隐私管理</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 2:
        return (
          <div className="h-full p-16 flex flex-col">
            <div className="mb-8">
              <h2 className="text-4xl mb-4 text-primary">功能架构</h2>
              <div className="w-20 h-1 bg-primary"></div>
            </div>
            
            <div className="flex-1">
              <div className="grid grid-cols-3 gap-6 h-full">
                <div className="col-span-3 grid grid-cols-4 gap-4">
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 border-2 border-blue-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                        <BarChart3 className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl">仪表板</h3>
                    </div>
                    <p className="text-muted-foreground">
                      数据可视化总览，实时监控关键指标
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6 border-2 border-purple-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center">
                        <Database className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl">数据采集</h3>
                    </div>
                    <p className="text-muted-foreground">
                      多维度客户信息采集与管理
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-6 border-2 border-green-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                        <Users className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl">用户画像</h3>
                    </div>
                    <p className="text-muted-foreground">
                      AI智能分析，精准客户细分
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-6 border-2 border-orange-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center">
                        <Target className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl">营销策略</h3>
                    </div>
                    <p className="text-muted-foreground">
                      智能推荐个性化营销方案
                    </p>
                  </div>
                </div>

                <div className="col-span-3 grid grid-cols-3 gap-4">
                  <div className="bg-gradient-to-br from-pink-50 to-pink-100 rounded-xl p-6 border-2 border-pink-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-pink-500 rounded-lg flex items-center justify-center">
                        <PenTool className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl">文案生成</h3>
                    </div>
                    <p className="text-muted-foreground">
                      AI自动生成营销文案内容
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-xl p-6 border-2 border-cyan-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-cyan-500 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl">效果追踪</h3>
                    </div>
                    <p className="text-muted-foreground">
                      营销活动效果实时监控分析
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl p-6 border-2 border-indigo-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-indigo-500 rounded-lg flex items-center justify-center">
                        <Store className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-xl">网店配置</h3>
                    </div>
                    <p className="text-muted-foreground">
                      小程序商城配置与发布管理
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="h-full p-16 flex flex-col">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-16 h-16 bg-purple-500 rounded-xl flex items-center justify-center">
                <Database className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-4xl text-primary">数据采集模块</h2>
                <p className="text-muted-foreground text-lg">多维度客户数据管理</p>
              </div>
            </div>
            
            <div className="flex-1 grid grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl mb-4">核心功能</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                      <div>
                        <div className="text-lg mb-1">客户信息管理</div>
                        <div className="text-sm text-muted-foreground">基础信息、联系方式、会员等级</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                      <div>
                        <div className="text-lg mb-1">消费行为画像</div>
                        <div className="text-sm text-muted-foreground">消费频次、金额、偏好项目分析</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                      <div>
                        <div className="text-lg mb-1">肌肤与健康画像</div>
                        <div className="text-sm text-muted-foreground">肤质类型、皮肤问题、健康状况</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl mb-4">应用价值</h3>
                  <div className="space-y-4">
                    <div className="p-5 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg border border-blue-200">
                      <div className="text-lg mb-2">📊 数据可视化</div>
                      <p className="text-muted-foreground">
                        直观展示客户分布、消费趋势等关键数据
                      </p>
                    </div>
                    <div className="p-5 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg border border-purple-200">
                      <div className="text-lg mb-2">🎯 精准营销</div>
                      <p className="text-muted-foreground">
                        基于多维数据实现个性化推荐和营销
                      </p>
                    </div>
                    <div className="p-5 bg-gradient-to-br from-green-50 to-green-100 rounded-lg border border-green-200">
                      <div className="text-lg mb-2">💡 智能分析</div>
                      <p className="text-muted-foreground">
                        AI自动分析客户特征，提供决策支持
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="h-full p-12 flex flex-col">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-green-500 rounded-xl flex items-center justify-center">
                <Users className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-4xl text-primary">用户画像模块</h2>
                <p className="text-muted-foreground text-lg">AI智能客户细分与分析</p>
              </div>
            </div>
            
            <div className="flex-1 grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-2xl mb-3">客户细分维度</h3>
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="p-3 bg-gradient-to-r from-amber-50 to-amber-100 rounded-lg border-l-4 border-amber-500">
                      <div className="text-base mb-1">高价值客户</div>
                      <div className="text-xs text-muted-foreground">消费金额高、忠诚度高</div>
                    </div>
                    <div className="p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg border-l-4 border-blue-500">
                      <div className="text-base mb-1">潜力客户</div>
                      <div className="text-xs text-muted-foreground">消费潜力大、待激活</div>
                    </div>
                    <div className="p-3 bg-gradient-to-r from-green-50 to-green-100 rounded-lg border-l-4 border-green-500">
                      <div className="text-base mb-1">稳定客户</div>
                      <div className="text-xs text-muted-foreground">定期消费、关系稳定</div>
                    </div>
                    <div className="p-3 bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg border-l-4 border-orange-500">
                      <div className="text-base mb-1">新客户</div>
                      <div className="text-xs text-muted-foreground">新注册、需要培育</div>
                    </div>
                    <div className="p-3 bg-gradient-to-r from-red-50 to-red-100 rounded-lg border-l-4 border-red-500">
                      <div className="text-base mb-1">流失风险客户</div>
                      <div className="text-xs text-muted-foreground">活跃度下降、需挽回</div>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-3">
                  <ImageWithFallback 
                    src={highValueCustomerImg} 
                    alt="高价值客户画像示例" 
                    className="w-full h-auto rounded-lg"
                  />
                  <ImageWithFallback 
                    src={newCustomerImg} 
                    alt="新客户画像示例" 
                    className="w-full h-auto rounded-lg"
                  />
                  <ImageWithFallback 
                    src={churnRiskCustomerImg} 
                    alt="流失风险客户画像示例" 
                    className="w-full h-auto rounded-lg"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-2xl mb-3">肤质画像分类</h3>
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg border-l-4 border-blue-500">
                      <div className="text-base mb-1">干性肌肤</div>
                      <div className="text-xs text-muted-foreground">缺水紧绷、需要滋润</div>
                    </div>
                    <div className="p-3 bg-gradient-to-r from-green-50 to-green-100 rounded-lg border-l-4 border-green-500">
                      <div className="text-base mb-1">油性肌肤</div>
                      <div className="text-xs text-muted-foreground">油脂分泌旺盛、需控油</div>
                    </div>
                    <div className="p-3 bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg border-l-4 border-purple-500">
                      <div className="text-base mb-1">混合性肌肤</div>
                      <div className="text-xs text-muted-foreground">T区油、两颊干、需平衡</div>
                    </div>
                    <div className="p-3 bg-gradient-to-r from-pink-50 to-pink-100 rounded-lg border-l-4 border-pink-500">
                      <div className="text-base mb-1">敏感性肌肤</div>
                      <div className="text-xs text-muted-foreground">易泛红过敏、需温和护理</div>
                    </div>
                    <div className="p-3 bg-gradient-to-r from-cyan-50 to-cyan-100 rounded-lg border-l-4 border-cyan-500">
                      <div className="text-base mb-1">中性肌肤</div>
                      <div className="text-xs text-muted-foreground">水油平衡、健康状态</div>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-3">
                  <ImageWithFallback 
                    src={oilySkinImg} 
                    alt="油性肌肤画像示例" 
                    className="w-full h-auto rounded-lg"
                  />
                  <ImageWithFallback 
                    src={sensitiveSkinNewImg} 
                    alt="敏感性肌肤画像示例" 
                    className="w-full h-auto rounded-lg"
                  />
                  <ImageWithFallback 
                    src={mixedSkinImg} 
                    alt="混合性肌肤画像示例" 
                    className="w-full h-auto rounded-lg"
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="h-full p-16 flex flex-col">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-16 h-16 bg-orange-500 rounded-xl flex items-center justify-center">
                <Target className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-4xl text-primary">营销策略模块</h2>
                <p className="text-muted-foreground text-lg">智能营销活动管理与执行</p>
              </div>
            </div>
            
            <div className="flex-1 flex flex-col gap-6">
              {/* 第一行：AI智能推荐（含活动类型） + 全生命周期营销 */}
              <div className="grid grid-cols-2 gap-6">
                {/* 左侧：AI智能推荐（包含活动类型）+ 原型图片 */}
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col">
                    <h3 className="text-2xl mb-3">AI智能推荐</h3>
                    <div className="p-4 bg-gradient-to-br from-violet-50 to-purple-100 rounded-lg border-2 border-violet-300 flex flex-col">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="w-5 h-5 text-violet-600" />
                        <span className="text-base">智能推荐多种营销活动</span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-3">
                        基于客户画像和历史数据，AI自动推荐最适合的营销活动方案
                      </p>
                      
                      {/* 活动类型四宫格 */}
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 bg-blue-50 rounded-lg border border-blue-200 text-center flex flex-col items-center justify-center">
                          <div className="text-2xl mb-1">🎁</div>
                          <div className="text-sm">促销活动</div>
                        </div>
                        <div className="p-2 bg-green-50 rounded-lg border border-green-200 text-center flex flex-col items-center justify-center">
                          <div className="text-2xl mb-1">👥</div>
                          <div className="text-sm">获客活动</div>
                        </div>
                        <div className="p-2 bg-purple-50 rounded-lg border border-purple-200 text-center flex flex-col items-center justify-center">
                          <div className="text-2xl mb-1">💎</div>
                          <div className="text-sm">留存活动</div>
                        </div>
                        <div className="p-2 bg-pink-50 rounded-lg border border-pink-200 text-center flex flex-col items-center justify-center">
                          <div className="text-2xl mb-1">🎯</div>
                          <div className="text-sm">转化活动</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* AI智能推荐原型图片 */}
                  <div className="rounded-xl overflow-hidden border-4 border-purple-300 shadow-lg">
                    <ImageWithFallback 
                      src={aiRecommendationImg} 
                      alt="AI智能推荐原型页面"
                      className="w-full h-auto object-contain"
                    />
                  </div>
                </div>

                {/* 右侧：全生命周期营销 + 原型图片 */}
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col">
                    <h3 className="text-2xl mb-3">全生命周期营销</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-orange-50 rounded-lg border border-orange-200 flex flex-col items-center justify-center text-center">
                        <div className="text-3xl mb-1">📝</div>
                        <div className="text-base mb-1">活动创建与管理</div>
                        <div className="text-xs text-muted-foreground">可视化创建营销活动</div>
                      </div>
                      <div className="p-3 bg-cyan-50 rounded-lg border border-cyan-200 flex flex-col items-center justify-center text-center">
                        <div className="text-3xl mb-1">📱</div>
                        <div className="text-base mb-1">小程序发布</div>
                        <div className="text-xs text-muted-foreground">一键发布到小程序</div>
                      </div>
                      <div className="p-3 bg-rose-50 rounded-lg border border-rose-200 flex flex-col items-center justify-center text-center">
                        <div className="text-3xl mb-1">📢</div>
                        <div className="text-base mb-1">腾讯广告投放</div>
                        <div className="text-xs text-muted-foreground">精准渠道投放</div>
                      </div>
                      <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 flex flex-col items-center justify-center text-center">
                        <div className="text-3xl mb-1">📊</div>
                        <div className="text-base mb-1">效果实时监控</div>
                        <div className="text-xs text-muted-foreground">数据实时追踪</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* 腾讯广告投放原型图片 */}
                  <div className="rounded-xl overflow-hidden border-4 border-orange-300 shadow-lg">
                    <ImageWithFallback 
                      src={tencentAdDemoImg} 
                      alt="腾讯广告投放原型页面"
                      className="w-full h-auto object-contain"
                    />
                  </div>
                </div>
              </div>

            </div>
          </div>
        );

      case 6:
        return (
          <div className="h-full p-16 flex flex-col">
            <div className="mb-8">
              <h2 className="text-4xl mb-4 text-primary">其他核心模块</h2>
              <div className="w-20 h-1 bg-primary"></div>
            </div>
            
            <div className="flex-1 grid grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-pink-50 to-pink-100 rounded-xl p-6 border-2 border-pink-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-14 h-14 bg-pink-500 rounded-xl flex items-center justify-center">
                    <PenTool className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl">文案生成</h3>
                </div>
                <div className="space-y-3 text-muted-foreground">
                  <p>• AI自动生成营销文案</p>
                  <p>• 支持多种风格和场景</p>
                  <p>• 一键应用到营销活动</p>
                  <p>• 提升内容创作效率</p>
                </div>
              </div>

              <div className="bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-xl p-6 border-2 border-cyan-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-14 h-14 bg-cyan-500 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl">效果追踪</h3>
                </div>
                <div className="space-y-3 text-muted-foreground">
                  <p>• 多维度数据分析</p>
                  <p>• 可视化图表展示</p>
                  <p>• ROI自动计算</p>
                  <p>• 趋势预测与建议</p>
                </div>
              </div>

              <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl p-6 border-2 border-indigo-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-14 h-14 bg-indigo-500 rounded-xl flex items-center justify-center">
                    <Store className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl">网店配置</h3>
                </div>
                <div className="space-y-3 text-muted-foreground">
                  <p>• 小程序商城配置</p>
                  <p>• 项目与服务管理</p>
                  <p>• 在线预约功能</p>
                  <p>• 一键发布上线</p>
                </div>
              </div>
            </div>

            <div className="mt-8 space-y-6">
              <div className="rounded-xl overflow-hidden border-2 border-purple-200 shadow-lg">
                <ImageWithFallback 
                  src={marketingStrategyDemoImg} 
                  alt="营销策略示例" 
                  className="w-full h-auto"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="p-5 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg border border-amber-200">
                  <div className="flex items-center gap-3 mb-2">
                    <Heart className="w-6 h-6 text-amber-600" />
                    <h4 className="text-xl">全链路营销闭环</h4>
                  </div>
                  <p className="text-muted-foreground">
                    从数据采集、画像分析、策略制定到效果追踪，形成完整的营销管理闭环
                  </p>
                </div>
                <div className="p-5 bg-gradient-to-r from-violet-50 to-purple-50 rounded-lg border border-violet-200">
                  <div className="flex items-center gap-3 mb-2">
                    <Cloud className="w-6 h-6 text-violet-600" />
                    <h4 className="text-xl">云端协同办公</h4>
                  </div>
                  <p className="text-muted-foreground">
                    数据云端存储，多终端同步，团队协作更高效，随时随地管理美容院业务
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="h-full p-16 flex flex-col">
            <div className="mb-8">
              <h2 className="text-4xl mb-4 text-primary">技术优势</h2>
              <div className="w-20 h-1 bg-primary"></div>
            </div>
            
            <div className="flex-1 grid grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border-2 border-blue-200">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                      <Sparkles className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-2xl">AI智能引擎</h3>
                  </div>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>✓ 深度学习用户行为模式</li>
                    <li>✓ 智能推荐营销策略</li>
                    <li>✓ 自动生成个性化内容</li>
                    <li>✓ 预测客户消费趋势</li>
                  </ul>
                </div>

                <div className="p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl border-2 border-green-200">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                      <Shield className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-2xl">数据安全</h3>
                  </div>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>✓ 企业级数据加密存储</li>
                    <li>✓ 多重身份验证机制</li>
                    <li>✓ 权限分级管理</li>
                    <li>✓ 定期数据备份</li>
                  </ul>
                </div>
              </div>

              <div className="space-y-6">
                <div className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border-2 border-purple-200">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center">
                      <Cloud className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-2xl">云端架构</h3>
                  </div>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>✓ 弹性扩展，按需付费</li>
                    <li>✓ 99.9%服务可用性</li>
                    <li>✓ 全球CDN加速访问</li>
                    <li>✓ 自动化运维保障</li>
                  </ul>
                </div>

                <div className="p-6 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl border-2 border-orange-200">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center">
                      <Smartphone className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-2xl">多端支持</h3>
                  </div>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>✓ Web端管理后台</li>
                    <li>✓ 微信小程序商城</li>
                    <li>✓ 移动端响应式设计</li>
                    <li>✓ 数据实时同步</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        );

      case 8:
        return (
          <div className="h-full p-16 flex flex-col">
            <div className="mb-8">
              <h2 className="text-4xl mb-4 text-primary">应用场景</h2>
              <div className="w-20 h-1 bg-primary"></div>
            </div>
            
            <div className="flex-1 space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 rounded-xl border-2 border-pink-200">
                  <h3 className="text-2xl mb-4">场景一：新客引流</h3>
                  <div className="space-y-3 text-muted-foreground">
                    <p><span className="text-primary">→</span> 通过AI分析周边潜在客户群体</p>
                    <p><span className="text-primary">→</span> 投放精准的朋友圈广告</p>
                    <p><span className="text-primary">→</span> 发布限时新客体验优惠</p>
                    <p><span className="text-primary">→</span> 小程序在线预约快速转化</p>
                    <p><span className="text-primary">→</span> 实时追踪获客成本和效果</p>
                  </div>
                </div>

                <div className="p-6 bg-gradient-to-br from-blue-50 via-cyan-50 to-blue-100 rounded-xl border-2 border-blue-200">
                  <h3 className="text-2xl mb-4">场景二：会员激活</h3>
                  <div className="space-y-3 text-muted-foreground">
                    <p><span className="text-primary">→</span> 识别沉睡客户和流失风险客户</p>
                    <p><span className="text-primary">→</span> AI推荐专属唤醒活动方案</p>
                    <p><span className="text-primary">→</span> 定向推送个性化护理套餐</p>
                    <p><span className="text-primary">→</span> 通过小程序发放优惠券</p>
                    <p><span className="text-primary">→</span> 监控客户回流和复购情况</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 bg-gradient-to-br from-green-50 via-emerald-50 to-green-100 rounded-xl border-2 border-green-200">
                  <h3 className="text-2xl mb-4">场景三：精准营销</h3>
                  <div className="space-y-3 text-muted-foreground">
                    <p><span className="text-primary">→</span> 基于肤质画像推荐适配项目</p>
                    <p><span className="text-primary">→</span> 针对不同客群定制活动</p>
                    <p><span className="text-primary">→</span> AI生成个性化营销文案</p>
                    <p><span className="text-primary">→</span> 多渠道同步发布活动信息</p>
                    <p><span className="text-primary">→</span> 分析转化漏斗优化策略</p>
                  </div>
                </div>

                <div className="p-6 bg-gradient-to-br from-purple-50 via-violet-50 to-purple-100 rounded-xl border-2 border-purple-200">
                  <h3 className="text-2xl mb-4">场景四：业绩提升</h3>
                  <div className="space-y-3 text-muted-foreground">
                    <p><span className="text-primary">→</span> 实时监控各项经营指标</p>
                    <p><span className="text-primary">→</span> 发现高价值客户深度运营</p>
                    <p><span className="text-primary">→</span> 设计会员升级激励方案</p>
                    <p><span className="text-primary">→</span> 推出组合套餐提升客单价</p>
                    <p><span className="text-primary">→</span> 数据驱动持续优化策略</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 9:
        return (
          <div className="h-full p-16 flex flex-col">
            <div className="mb-8">
              <h2 className="text-4xl mb-4 text-primary">客户价值</h2>
              <div className="w-20 h-1 bg-primary"></div>
            </div>
            
            <div className="flex-1 grid grid-cols-3 gap-6">
              <div className="space-y-6">
                <div className="text-center p-8 bg-gradient-to-b from-blue-50 to-blue-100 rounded-xl border-2 border-blue-200">
                  <div className="text-5xl mb-4">📈</div>
                  <h3 className="text-2xl mb-3">提升营收</h3>
                  <div className="text-4xl mb-2 text-blue-600">35%+</div>
                  <p className="text-muted-foreground">平均营收增长</p>
                </div>

                <div className="text-center p-8 bg-gradient-to-b from-green-50 to-green-100 rounded-xl border-2 border-green-200">
                  <div className="text-5xl mb-4">💰</div>
                  <h3 className="text-2xl mb-3">降低成本</h3>
                  <div className="text-4xl mb-2 text-green-600">40%+</div>
                  <p className="text-muted-foreground">营销成本节省</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="text-center p-8 bg-gradient-to-b from-purple-50 to-purple-100 rounded-xl border-2 border-purple-200">
                  <div className="text-5xl mb-4">👥</div>
                  <h3 className="text-2xl mb-3">客户增长</h3>
                  <div className="text-4xl mb-2 text-purple-600">50%+</div>
                  <p className="text-muted-foreground">新客获取提升</p>
                </div>

                <div className="text-center p-8 bg-gradient-to-b from-orange-50 to-orange-100 rounded-xl border-2 border-orange-200">
                  <div className="text-5xl mb-4">🎯</div>
                  <h3 className="text-2xl mb-3">转化提升</h3>
                  <div className="text-4xl mb-2 text-orange-600">60%+</div>
                  <p className="text-muted-foreground">营销转化率</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="text-center p-8 bg-gradient-to-b from-pink-50 to-pink-100 rounded-xl border-2 border-pink-200">
                  <div className="text-5xl mb-4">⏱️</div>
                  <h3 className="text-2xl mb-3">节省时间</h3>
                  <div className="text-4xl mb-2 text-pink-600">70%+</div>
                  <p className="text-muted-foreground">运营效率提升</p>
                </div>

                <div className="text-center p-8 bg-gradient-to-b from-cyan-50 to-cyan-100 rounded-xl border-2 border-cyan-200">
                  <div className="text-5xl mb-4">❤️</div>
                  <h3 className="text-2xl mb-3">客户满意</h3>
                  <div className="text-4xl mb-2 text-cyan-600">95%+</div>
                  <p className="text-muted-foreground">客户满意度</p>
                </div>
              </div>
            </div>

            <div className="mt-8 p-6 bg-gradient-to-r from-violet-100 via-purple-100 to-fuchsia-100 rounded-xl border-2 border-violet-300">
              <div className="flex items-center justify-center gap-3">
                <Award className="w-8 h-8 text-violet-600" />
                <p className="text-xl text-center">
                  <span className="text-violet-600">数据来源：</span>基于100+家美容院实际使用效果统计
                </p>
              </div>
            </div>
          </div>
        );

      case 10:
        return (
          <div className="h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-16">
            <div className="flex items-center gap-4 mb-8">
              <Sparkles className="w-16 h-16 text-primary" />
            </div>
            <h2 className="text-5xl mb-6 text-center">感谢您的关注</h2>
            <div className="w-32 h-1 bg-primary/30 mb-12"></div>
            
            <div className="max-w-2xl w-full space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 bg-white rounded-xl border-2 border-border text-center">
                  <div className="text-4xl mb-3">📧</div>
                  <h3 className="text-xl mb-2">商务咨询</h3>
                  <p className="text-muted-foreground">business@zhimeiyuntu.com</p>
                </div>
                
                <div className="p-6 bg-white rounded-xl border-2 border-border text-center">
                  <div className="text-4xl mb-3">📱</div>
                  <h3 className="text-xl mb-2">客服热线</h3>
                  <p className="text-muted-foreground">400-888-8888</p>
                </div>
              </div>

              <div className="p-8 bg-gradient-to-br from-violet-50 to-purple-50 rounded-xl border-2 border-violet-200 text-center">
                <h3 className="text-2xl mb-4">申请免费��用</h3>
                <p className="text-lg text-muted-foreground mb-4">
                  立即体验智美云图，开启美容院智能营销新时代
                </p>
                <div className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-lg text-lg">
                  扫码申请试用
                </div>
              </div>
            </div>

            <div className="mt-12 text-muted-foreground text-center">
              <p className="mb-2">智美云图 · 用户画像营销管理平台</p>
              <p className="text-sm">让每一次营销都精准有效</p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* 导航栏 */}
      <div className="sticky top-0 z-10 bg-white border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <span className="text-lg">智美云图 · 产品说明书</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              美容院智能营销解决方案
            </span>
            <span className="text-sm text-muted-foreground">
              第 {currentPage + 1} / {totalPages} 页
            </span>
          </div>
        </div>
      </div>

      {/* 页面内容 */}
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-6">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden" style={{ aspectRatio: '16/9' }}>
            {renderPage()}
          </div>
        </div>
      </div>

      {/* 分页控制 */}
      <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 flex items-center gap-4 bg-white rounded-full shadow-lg px-6 py-3 border border-border">
        <Button
          variant="outline"
          size="sm"
          onClick={prevPage}
          disabled={currentPage === 0}
          className="rounded-full"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          上一页
        </Button>
        
        <div className="flex items-center gap-2">
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPage(i)}
              className={`w-2 h-2 rounded-full transition-all ${
                i === currentPage 
                  ? 'bg-primary w-8' 
                  : 'bg-muted hover:bg-muted-foreground/30'
              }`}
              aria-label={`前往第 ${i + 1} 页`}
            />
          ))}
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={nextPage}
          disabled={currentPage === totalPages - 1}
          className="rounded-full"
        >
          下一页
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </div>
  );
}
