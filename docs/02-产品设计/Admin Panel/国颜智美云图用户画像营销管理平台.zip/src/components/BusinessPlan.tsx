import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { TrendingUp, Users, Target, DollarSign, BarChart3, Lightbulb, Shield, Calendar, Award, Brain } from "lucide-react";

export function BusinessPlan() {
  return (
    <div className="max-w-4xl mx-auto space-y-8 p-6">
      {/* 标题页 */}
      <div className="text-center space-y-6 py-12">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            智美云图
          </h1>
          <p className="text-xl text-muted-foreground">用户画像营销管理平台</p>
          <p className="text-lg">商业计划书</p>
        </div>
        <div className="flex justify-center space-x-8 text-sm text-muted-foreground">
          <div>版本: 1.0</div>
          <div>日期: 2024年9月</div>
          <div>机密文件</div>
        </div>
      </div>

      {/* 执行摘要 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-blue-600" />
            执行摘要
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3>公司愿景</h3>
              <p className="text-muted-foreground">
                成为中国领先的美容院智能营销解决方案提供商，通过AI技术赋能传统美业，实现数字化转型升级。
              </p>
              
              <h3>核心价值</h3>
              <p className="text-muted-foreground">
                提供"数据采集-画像构建-策略执行-效果追踪"全链路智能营销服务，帮助美容院提升客户留存率和营业收入。
              </p>
            </div>
            
            <div className="space-y-4">
              <h3>市场机会</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">¥2,000亿</div>
                  <div className="text-sm text-muted-foreground">美容行业市场规模</div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">50万+</div>
                  <div className="text-sm text-muted-foreground">全国美容院数量</div>
                </div>
              </div>
              
              <h3>融资需求</h3>
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">¥5,000万</div>
                <div className="text-sm text-muted-foreground">A轮融资金额</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 公司概述 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-600" />
            公司概述
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3>成立时间</h3>
              <p className="text-muted-foreground">2024年1月</p>
            </div>
            <div>
              <h3>注册资本</h3>
              <p className="text-muted-foreground">1,000万元</p>
            </div>
            <div>
              <h3>员工规模</h3>
              <p className="text-muted-foreground">25人</p>
            </div>
          </div>
          
          <div>
            <h3>产品定位</h3>
            <p className="text-muted-foreground mb-4">
              智美云图是专为美容院打造的AI驱动的用户画像营销管理平台，通过先进的数据分析和机器学习技术，为美容院提供精准的客户洞察和个性化营销解决方案。
            </p>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4>核心模块</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">仪表板概览</Badge>
                  <Badge variant="outline">数据采集</Badge>
                  <Badge variant="outline">用户画像</Badge>
                  <Badge variant="outline">营销策略</Badge>
                  <Badge variant="outline">效果追踪</Badge>
                  <Badge variant="outline">文案生成</Badge>
                </div>
              </div>
              <div className="space-y-2">
                <h4>技术特色</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">AI肌肤检测</Badge>
                  <Badge variant="secondary">智能画像分析</Badge>
                  <Badge variant="secondary">自动化营销</Badge>
                  <Badge variant="secondary">小程序集成</Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 市场分析 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-green-600" />
            市场分析
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3>市场规模</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span>美容服务市场</span>
                  <span className="font-semibold">¥2,000亿</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>美业SaaS市场</span>
                  <span className="font-semibold">¥120亿</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>目标市场（TAM）</span>
                  <span className="font-semibold text-blue-600">¥60亿</span>
                </div>
              </div>
              
              <h3>市场趋势</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• 美容院数字化转型需求激增</li>
                <li>• 客户体验个性化要求提升</li>
                <li>• 数据驱动营销成为主流</li>
                <li>• AI技术在美业应用加速</li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h3>目标客户</h3>
              <div className="space-y-3">
                <div className="border rounded-lg p-4">
                  <h4>中高端美容院</h4>
                  <p className="text-sm text-muted-foreground">员工10-50人，年营收500万-2000万</p>
                  <Badge variant="outline" className="mt-2">主要客群 70%</Badge>
                </div>
                <div className="border rounded-lg p-4">
                  <h4>连锁美容品牌</h4>
                  <p className="text-sm text-muted-foreground">多店经营，需要统一管理</p>
                  <Badge variant="outline" className="mt-2">重点客群 20%</Badge>
                </div>
                <div className="border rounded-lg p-4">
                  <h4>新兴美容工作室</h4>
                  <p className="text-sm text-muted-foreground">注重个性化服务的精品店</p>
                  <Badge variant="outline" className="mt-2">潜力客群 10%</Badge>
                </div>
              </div>
            </div>
          </div>
          
          <Separator />
          
          <div>
            <h3>竞争分析</h3>
            <div className="grid md:grid-cols-3 gap-4 mt-4">
              <div className="border rounded-lg p-4">
                <h4>传统美业软件</h4>
                <p className="text-sm text-muted-foreground mb-2">主要提供基础管理功能</p>
                <div className="space-y-1 text-xs">
                  <div className="text-red-600">缺乏智能分析</div>
                  <div className="text-red-600">营销功能薄弱</div>
                  <div className="text-green-600">市场份额大</div>
                </div>
              </div>
              <div className="border rounded-lg p-4">
                <h4>通用CRM系统</h4>
                <p className="text-sm text-muted-foreground mb-2">标准化客户管理工具</p>
                <div className="space-y-1 text-xs">
                  <div className="text-red-600">不够专业化</div>
                  <div className="text-green-600">功能相对完善</div>
                  <div className="text-green-600">技术相对成熟</div>
                </div>
              </div>
              <div className="border rounded-lg p-4 border-blue-200 bg-blue-50">
                <h4>智美云图</h4>
                <p className="text-sm text-muted-foreground mb-2">AI驱动的专业解决方案</p>
                <div className="space-y-1 text-xs">
                  <div className="text-green-600">美业专业化</div>
                  <div className="text-green-600">AI技术领先</div>
                  <div className="text-green-600">全链路闭环</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 产品与服务 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-orange-600" />
            产品与服务
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3>核心功能模块</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <h4>仪表板概览</h4>
                    <p className="text-sm text-muted-foreground">实时业务数据监控和关键指标展示</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <h4>数据采集</h4>
                    <p className="text-sm text-muted-foreground">多维度客户信息收集和管理</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <h4>用户画像</h4>
                    <p className="text-sm text-muted-foreground">AI驱动的客户分析和标签体系</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <h4>营销策略</h4>
                    <p className="text-sm text-muted-foreground">智能营销活动策划和执行</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <h4>效果追踪</h4>
                    <p className="text-sm text-muted-foreground">营销ROI分析和效果优化</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <h4>文案生成</h4>
                    <p className="text-sm text-muted-foreground">AI智能营销文案创作</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3>技术优势</h3>
              <div className="space-y-3">
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
                  <h4>AI肌肤检测</h4>
                  <p className="text-sm text-muted-foreground">基于计算机视觉的专业肌肤分析技术</p>
                </div>
                <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg">
                  <h4>智能用户画像</h4>
                  <p className="text-sm text-muted-foreground">多维度数据融合的客户洞察算法</p>
                </div>
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg">
                  <h4>小程序集成</h4>
                  <p className="text-sm text-muted-foreground">一键发布营销活动到客户端小程序</p>
                </div>
                <div className="bg-gradient-to-r from-orange-50 to-red-50 p-4 rounded-lg">
                  <h4>腾讯广告投放</h4>
                  <p className="text-sm text-muted-foreground">直接集成腾讯朋友圈广告投放</p>
                </div>
              </div>
            </div>
          </div>
          
          <Separator />
          
          <div>
            <h3>服务模式</h3>
            <div className="grid md:grid-cols-3 gap-4 mt-4">
              <div className="border rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-blue-600 mb-2">基础版</div>
                <div className="text-muted-foreground mb-4">¥12,000/年</div>
                <ul className="text-sm space-y-1">
                  <li>• 核心功能模块</li>
                  <li>• 200个客户额度</li>
                  <li>• 基础客服支持</li>
                </ul>
              </div>
              <div className="border-2 border-blue-600 rounded-lg p-4 text-center bg-blue-50">
                <div className="text-2xl font-bold text-blue-600 mb-2">专业版</div>
                <div className="text-muted-foreground mb-4">¥24,000/年</div>
                <ul className="text-sm space-y-1">
                  <li>• 全功能模块</li>
                  <li>• 1000个客户额度</li>
                  <li>• AI功能增强</li>
                  <li>• 专属客户经理</li>
                </ul>
                <Badge className="mt-2">推荐</Badge>
              </div>
              <div className="border rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-purple-600 mb-2">企业版</div>
                <div className="text-muted-foreground mb-4">¥48,000/年</div>
                <ul className="text-sm space-y-1">
                  <li>• 定制化功能</li>
                  <li>• 无限客户额度</li>
                  <li>• 多店管理</li>
                  <li>• 7×24小时支持</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 商业模式 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-green-600" />
            商业模式
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3>收入模式</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span>SaaS订阅费</span>
                  <span className="font-semibold text-blue-600">70%</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span>定制开发</span>
                  <span className="font-semibold text-green-600">20%</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                  <span>增值服务</span>
                  <span className="font-semibold text-purple-600">10%</span>
                </div>
              </div>
              
              <h3>成本结构</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>研发成本</span>
                  <span>40%</span>
                </div>
                <div className="flex justify-between">
                  <span>销售营销</span>
                  <span>30%</span>
                </div>
                <div className="flex justify-between">
                  <span>运营管理</span>
                  <span>20%</span>
                </div>
                <div className="flex justify-between">
                  <span>基础设施</span>
                  <span>10%</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3>客户获取策略</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• 数字营销和内容营销</li>
                <li>• 行业展会和合作伙伴渠道</li>
                <li>• 客户推荐和口碑传播</li>
                <li>• 免费试用和体验营销</li>
              </ul>
              
              <h3>客户留存策略</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• 优质的客户成功服务</li>
                <li>• 持续的产品功能更新</li>
                <li>• 行业最佳实践分享</li>
                <li>• 客户社区建设</li>
              </ul>
              
              <h3>规模化优势</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• 边际成本递减</li>
                <li>• 数据价值增长</li>
                <li>• 网络效应增强</li>
                <li>• 技术壁垒提升</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 财务预测 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-green-600" />
            财务预测
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h3>三年财务预测 (单位：万元)</h3>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3">财务指标</th>
                    <th className="text-right p-3">2024年</th>
                    <th className="text-right p-3">2025年</th>
                    <th className="text-right p-3">2026年</th>
                  </tr>
                </thead>
                <tbody className="space-y-2">
                  <tr className="border-b">
                    <td className="p-3">营业收入</td>
                    <td className="text-right p-3">800</td>
                    <td className="text-right p-3">3,200</td>
                    <td className="text-right p-3">8,500</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-3">毛利润</td>
                    <td className="text-right p-3">640</td>
                    <td className="text-right p-3">2,720</td>
                    <td className="text-right p-3">7,650</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-3">净利润</td>
                    <td className="text-right p-3">-200</td>
                    <td className="text-right p-3">800</td>
                    <td className="text-right p-3">3,400</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-3">客户数量</td>
                    <td className="text-right p-3">100</td>
                    <td className="text-right p-3">500</td>
                    <td className="text-right p-3">1,200</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-3">ARPU (年)</td>
                    <td className="text-right p-3">8,000</td>
                    <td className="text-right p-3">6,400</td>
                    <td className="text-right p-3">7,083</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3>关键假设</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• 年客户增长率：400%-140%</li>
                <li>• 客户年续费率：85%</li>
                <li>• 毛利率：80%-90%</li>
                <li>• 市场渗透率：0.02%-0.24%</li>
              </ul>
            </div>
            <div>
              <h3>盈利能力分析</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• 2025年实现盈亏平衡</li>
                <li>• 2026年净利率达到40%</li>
                <li>• 客户获取成本回收期：18个月</li>
                <li>• 客户生命周期价值：5万元</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 融资需求 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-purple-600" />
            融资需求
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3>融资金额：5,000万元</h3>
              <p className="text-muted-foreground">
                计划进行A轮融资，出让15%股权，引入战略投资者和财务投资者，加速产品研发和市场拓展。
              </p>
              
              <h3>资金用途</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span>产品研发</span>
                  <span className="font-semibold text-blue-600">40% (2,000万)</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span>市场拓展</span>
                  <span className="font-semibold text-green-600">30% (1,500万)</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                  <span>团队建设</span>
                  <span className="font-semibold text-purple-600">20% (1,000万)</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                  <span>运营资金</span>
                  <span className="font-semibold text-orange-600">10% (500万)</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3>投资亮点</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• 垂直行业专业化优势明显</li>
                <li>• AI技术领先，壁垒较高</li>
                <li>• SaaS模式可持续增长</li>
                <li>• 市场空间巨大，竞争格局良好</li>
                <li>• 团队经验丰富，执行力强</li>
              </ul>
              
              <h3>退出机制</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• IPO上市：3-5年后科创板上市</li>
                <li>• 并购退出：被大型软件厂商收购</li>
                <li>• 股权转让：向后轮投资者转让</li>
              </ul>
              
              <h3>估值基础</h3>
              <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg">
                <div className="text-lg font-semibold">估值：3.3亿元</div>
                <div className="text-sm text-muted-foreground">基于2026年预期收入10倍PS估值</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 团队介绍 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-600" />
            核心团队
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="border rounded-lg p-4">
                <h4>创始人 & CEO</h4>
                <p className="font-semibold">张明华</p>
                <p className="text-sm text-muted-foreground">
                  15年美业和技术经验，前腾讯高级产品经理，深度理解美业痛点和技术趋势。
                </p>
              </div>
              
              <div className="border rounded-lg p-4">
                <h4>技术合伙人 & CTO</h4>
                <p className="font-semibold">李晓东</p>
                <p className="text-sm text-muted-foreground">
                  AI和大数据专家，前阿里巴巴技术专家，拥有多项AI算法专利。
                </p>
              </div>
              
              <div className="border rounded-lg p-4">
                <h4>产品合伙人 & CPO</h4>
                <p className="font-semibold">王雅婷</p>
                <p className="text-sm text-muted-foreground">
                  资深产品经理，前美团高级产品经理，专注SaaS产品设计和用户体验。
                </p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="border rounded-lg p-4">
                <h4>销售合伙人 & CSO</h4>
                <p className="font-semibold">陈建国</p>
                <p className="text-sm text-muted-foreground">
                  美业渠道专家，在美业拥有丰富的客户资源和合作伙伴网络。
                </p>
              </div>
              
              <div className="border rounded-lg p-4">
                <h4>运营合伙人 & COO</h4>
                <p className="font-semibold">赵莉娜</p>
                <p className="text-sm text-muted-foreground">
                  运营管理专家，前字节跳动运营总监，擅长用户增长和数据运营。
                </p>
              </div>
              
              <h3>团队规模</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-xl font-bold text-blue-600">12人</div>
                  <div className="text-sm text-muted-foreground">研发团队</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-xl font-bold text-green-600">8人</div>
                  <div className="text-sm text-muted-foreground">销售运营</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 风险分析 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-red-600" />
            风险分析与应对
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3>市场风险</h3>
              <div className="space-y-3">
                <div className="border-l-4 border-red-500 pl-4">
                  <h4>竞争加剧</h4>
                  <p className="text-sm text-muted-foreground">大厂进入，价格战风险</p>
                  <p className="text-xs text-green-600">应对：技术壁垒，差异化定位</p>
                </div>
                <div className="border-l-4 border-orange-500 pl-4">
                  <h4>市场教育成本高</h4>
                  <p className="text-sm text-muted-foreground">美业数字化程度较低</p>
                  <p className="text-xs text-green-600">应对：行业标杆案例，免费试用</p>
                </div>
              </div>
              
              <h3>技术风险</h3>
              <div className="space-y-3">
                <div className="border-l-4 border-purple-500 pl-4">
                  <h4>AI算法准确性</h4>
                  <p className="text-sm text-muted-foreground">肌肤检测准确率要求高</p>
                  <p className="text-xs text-green-600">应对：持续算法优化，专家验证</p>
                </div>
                <div className="border-l-4 border-blue-500 pl-4">
                  <h4>数据安全合规</h4>
                  <p className="text-sm text-muted-foreground">用户隐私保护要求</p>
                  <p className="text-xs text-green-600">应对：等保认证，数据加密</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3>运营风险</h3>
              <div className="space-y-3">
                <div className="border-l-4 border-green-500 pl-4">
                  <h4>人才流失</h4>
                  <p className="text-sm text-muted-foreground">核心技术人员离职</p>
                  <p className="text-xs text-green-600">应对：股权激励，文化建设</p>
                </div>
                <div className="border-l-4 border-yellow-500 pl-4">
                  <h4>资金链断裂</h4>
                  <p className="text-sm text-muted-foreground">融资进度不及预期</p>
                  <p className="text-xs text-green-600">应对：多轮次融资，现金流管控</p>
                </div>
              </div>
              
              <h3>财务风险</h3>
              <div className="space-y-3">
                <div className="border-l-4 border-indigo-500 pl-4">
                  <h4>客户流失率高</h4>
                  <p className="text-sm text-muted-foreground">续费率不达预期</p>
                  <p className="text-xs text-green-600">应对：客户成功团队，产品价值提升</p>
                </div>
                <div className="border-l-4 border-pink-500 pl-4">
                  <h4>获客成本上升</h4>
                  <p className="text-sm text-muted-foreground">营销效率下降</p>
                  <p className="text-xs text-green-600">应对：口碑营销，渠道多元化</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 发展规划 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-blue-600" />
            发展规划
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-6">
            <div className="relative">
              <div className="absolute left-6 top-8 bottom-0 w-px bg-border"></div>
              
              <div className="space-y-8">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold">
                    2024
                  </div>
                  <div className="space-y-2">
                    <h3>产品完善期</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• 完成核心功能开发和测试</li>
                      <li>• 获得100家种子客户</li>
                      <li>• 建立客户成功团队</li>
                      <li>• 完成天使轮融资</li>
                    </ul>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center font-semibold">
                    2025
                  </div>
                  <div className="space-y-2">
                    <h3>市场扩张期</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• 服务500家美容院客户</li>
                      <li>• 拓展一二线城市市场</li>
                      <li>• 建立渠道合作伙伴网络</li>
                      <li>• 完成A轮融资5000万</li>
                    </ul>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-purple-600 text-white rounded-full flex items-center justify-center font-semibold">
                    2026
                  </div>
                  <div className="space-y-2">
                    <h3>规模化增长期</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• 覆盖1200家美容院</li>
                      <li>• 下沉三四线城市</li>
                      <li>• 推出行业解决方案</li>
                      <li>• 筹备B轮融资</li>
                    </ul>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-orange-600 text-white rounded-full flex items-center justify-center font-semibold">
                    2027
                  </div>
                  <div className="space-y-2">
                    <h3>平台化发展期</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• 建立美业生态平台</li>
                      <li>• 拓展相邻行业市场</li>
                      <li>• 国际市场探索</li>
                      <li>• 启动IPO准备</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 附录 */}
      <Card>
        <CardHeader>
          <CardTitle>附录</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3>联系方式</h3>
              <div className="space-y-2 text-sm">
                <div>公司地址：北京市海淀区中关村软件园</div>
                <div>联系电话：400-888-9999</div>
                <div>官方网站：www.zhimeiyt.com</div>
                <div>商务邮箱：business@zhimeiyt.com</div>
              </div>
            </div>
            <div>
              <h3>法律声明</h3>
              <p className="text-sm text-muted-foreground">
                本商业计划书包含的所有信息均为机密信息，仅供投资决策参考。未经授权，不得复制、传播或用于其他用途。
              </p>
            </div>
          </div>
          
          <Separator />
          
          <div className="text-center text-sm text-muted-foreground">
            <p>智美云图科技有限公司 © 2024 版权所有</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}