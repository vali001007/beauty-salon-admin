import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Brain, 
  TrendingUp, 
  Users, 
  Target, 
  Sparkles, 
  BarChart3, 
  Database, 
  PenTool,
  Store,
  FileText,
  CheckCircle,
  ArrowRight,
  Play,
  Star,
  Award,
  Shield,
  Phone,
  Mail,
  MapPin,
  Menu,
  X
} from 'lucide-react';

interface WebsiteProps {
  onNavigateToApp?: () => void;
}

export function Website({ onNavigateToApp }: WebsiteProps = {}) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  const features = [
    {
      icon: Brain,
      title: 'AI智能分析',
      description: '基于深度学习的肌肤检测和用户画像分析，为每位客户提供个性化建议'
    },
    {
      icon: Target,
      title: '精准营销',
      description: '数据驱动的营销策略制定，提升客户转化率和留存率'
    },
    {
      icon: BarChart3,
      title: '实时监控',
      description: '全方位的业务数据监控和效果追踪，让每一分投入都有据可循'
    },
    {
      icon: Store,
      title: '小程序集成',
      description: '一键发布营销活动到客户小程序，打通线上线下服务闭环'
    },
    {
      icon: PenTool,
      title: 'AI文案生成',
      description: '智能生成营销文案和活动内容，提升营销效率和专业度'
    },
    {
      icon: TrendingUp,
      title: '效果追踪',
      description: '详细的ROI分析和效果报告，持续优化营销策略'
    }
  ];

  const solutions = [
    {
      title: '客户留存提升',
      description: '通过精准的用户画像分析，制定个性化服务方案，提升客户满意度和忠诚度',
      results: ['客户留存率提升35%', '复购率增长42%', '客户满意度达95%'],
      image: 'https://images.unsplash.com/photo-1611211235015-e2e3a7d09e97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBiZWF1dHklMjBzYWxvbiUyMGludGVyaW9yfGVufDF8fHx8MTc1ODUzNjI3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      title: '营销效率优化',
      description: 'AI驱动的营销策略和自动化工具，大幅提升营销投入产出比',
      results: ['营销ROI提升60%', '获客成本降低30%', '转化率提升25%'],
      image: 'https://images.unsplash.com/photo-1608222351212-18fe0ec7b13b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGFuYWx5dGljcyUyMGRhc2hib2FyZHxlbnwxfHx8fDE3NTg1MTc1NjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      title: '数字化转型',
      description: '全面的数字化解决方案，帮助美容院实现现代化管理和服务升级',
      results: ['运营效率提升50%', '服务质量提升40%', '品牌形象升级'],
      image: 'https://images.unsplash.com/photo-1712482937664-5697b56ed6f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWF1dHklMjBza2luY2FyZSUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzU4NTQ3OTI4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    }
  ];

  const testimonials = [
    {
      name: '张丽华',
      role: '丽颜美容院 创始人',
      content: '使用智美云图后，我们的客户留存率提升了35%，营销效果显著改善。AI肌肤检测功能特别受客户欢迎。',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b647?w=64&h=64&fit=crop&crop=face',
      rating: 5
    },
    {
      name: '王明',
      role: '美丽人生连锁 运营总监',
      content: '平台的数据分析功能帮助我们制定了更精准的营销策略，ROI提升了60%，这是我们见过最专业的美业解决方案。',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop&crop=face',
      rating: 5
    },
    {
      name: '李雅婷',
      role: '悦美工作室 店长',
      content: '小程序功能让我们与客户的互动更加便捷，客户预约量增长了40%，服务效率也大大提升。',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop&crop=face',
      rating: 5
    }
  ];

  const pricingPlans = [
    {
      name: '基础版',
      price: '12,000',
      period: '年',
      description: '适合中小型美容院',
      features: [
        '核心功能模块',
        '200个客户额度',
        '基础AI分析',
        '小程序发布',
        '基础客服支持',
        '数据报表'
      ],
      recommended: false
    },
    {
      name: '专业版',
      price: '24,000',
      period: '年',
      description: '适合中高端美容院',
      features: [
        '全功能模块',
        '1000个客户额度',
        '高级AI分析',
        '营销自动化',
        '腾讯广告投放',
        '专属客户经理',
        '优先技术支持'
      ],
      recommended: true
    },
    {
      name: '企业版',
      price: '48,000',
      period: '年',
      description: '适合连锁美容品牌',
      features: [
        '定制化功能',
        '无限客户额度',
        '多店管理',
        '高级数据分析',
        'API接口',
        '专属成功团队',
        '7×24小时支持'
      ],
      recommended: false
    }
  ];

  const stats = [
    { number: '500+', label: '服务美容院' },
    { number: '50万+', label: '分析客户数据' },
    { number: '35%', label: '平均留存提升' },
    { number: '60%', label: '营销ROI提升' }
  ];

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* 导航栏 */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 via-pink-500 to-rose-500 p-1.5 flex items-center justify-center shadow-lg">
                <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
                  {/* 中心：抽象人脸轮廓 - 代表"用户画像" */}
                  <ellipse cx="16" cy="14" rx="7" ry="9" fill="white" fillOpacity="0.25"/>
                  
                  {/* 花瓣形状环绕 - 代表"美" */}
                  {/* 上花瓣 */}
                  <path d="M16 4 C14 4 13 6 13 8 C13 10 14 11 16 11 C18 11 19 10 19 8 C19 6 18 4 16 4 Z" fill="white" fillOpacity="0.9"/>
                  {/* 右上花瓣 */}
                  <path d="M22 8 C21 6.5 19 6 17.5 7 C16 8 15.5 10 16.5 11.5 C17.5 13 19.5 13 21 12 C22.5 11 23 9 22 8 Z" fill="white" fillOpacity="0.85"/>
                  {/* 右花瓣 */}
                  <path d="M25 14 C25 12 23.5 11 22 11.5 C20.5 12 19.5 13.5 20 15 C20.5 16.5 22 17 23.5 16.5 C25 16 26 15 25 14 Z" fill="white" fillOpacity="0.8"/>
                  {/* 右下花瓣 */}
                  <path d="M22 20 C23 18.5 22.5 16.5 21 16 C19.5 15.5 17.5 16.5 17 18 C16.5 19.5 17 21 18.5 21.5 C20 22 21 21.5 22 20 Z" fill="white" fillOpacity="0.85"/>
                  {/* 左下花瓣 */}
                  <path d="M10 20 C9 21.5 9.5 23 11 23.5 C12.5 24 14.5 23 15 21.5 C15.5 20 15 18.5 13.5 18 C12 17.5 11 18.5 10 20 Z" fill="white" fillOpacity="0.85"/>
                  {/* 左花瓣 */}
                  <path d="M7 14 C7 16 8.5 17 10 16.5 C11.5 16 12.5 14.5 12 13 C11.5 11.5 10 11 8.5 11.5 C7 12 6 13 7 14 Z" fill="white" fillOpacity="0.8"/>
                  {/* 左上花瓣 */}
                  <path d="M10 8 C11 6.5 10.5 4.5 9 4.5 C7.5 4.5 6 5.5 6 7 C6 8.5 7 10 8.5 10.5 C10 11 11 9.5 10 8 Z" fill="white" fillOpacity="0.85"/>
                  
                  {/* 中心星光点 - 代表"智能"和"数据洞察" */}
                  <circle cx="16" cy="14" r="2" fill="white" fillOpacity="0.95"/>
                  
                  {/* 底部数据连接点 - 代表"云图"和"数据" */}
                  <circle cx="12" cy="26" r="1" fill="white" fillOpacity="0.7"/>
                  <circle cx="16" cy="27" r="1" fill="white" fillOpacity="0.7"/>
                  <circle cx="20" cy="26" r="1" fill="white" fillOpacity="0.7"/>
                  <path d="M12 26 L16 27 L20 26" stroke="white" strokeWidth="0.5" strokeOpacity="0.5"/>
                </svg>
              </div>
              <div>
                <div>智美云图</div>
                <div className="text-xs text-muted-foreground">用户画像营销管理平台</div>
              </div>
            </div>
            
            {/* 桌面导航 */}
            <nav className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection('home')}
                className={`transition-colors hover:text-primary ${activeSection === 'home' ? 'text-primary' : 'text-muted-foreground'}`}
              >
                首页
              </button>
              <button 
                onClick={() => scrollToSection('features')}
                className={`transition-colors hover:text-primary ${activeSection === 'features' ? 'text-primary' : 'text-muted-foreground'}`}
              >
                产品功能
              </button>
              <button 
                onClick={() => scrollToSection('solutions')}
                className={`transition-colors hover:text-primary ${activeSection === 'solutions' ? 'text-primary' : 'text-muted-foreground'}`}
              >
                解决方案
              </button>
              <button 
                onClick={() => scrollToSection('pricing')}
                className={`transition-colors hover:text-primary ${activeSection === 'pricing' ? 'text-primary' : 'text-muted-foreground'}`}
              >
                价格方案
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className={`transition-colors hover:text-primary ${activeSection === 'about' ? 'text-primary' : 'text-muted-foreground'}`}
              >
                关于我们
              </button>
            </nav>
            
            <div className="hidden md:flex items-center gap-4">
              <Button variant="ghost">登录</Button>
              <Button>免费试用</Button>
              {onNavigateToApp && (
                <Button variant="outline" onClick={onNavigateToApp}>
                  进入平台
                </Button>
              )}
            </div>
            
            {/* 移动端菜单按钮 */}
            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
          
          {/* 移动端菜单 */}
          {isMenuOpen && (
            <div className="md:hidden border-t bg-background py-4">
              <nav className="flex flex-col space-y-4">
                <button onClick={() => scrollToSection('home')} className="text-left">首页</button>
                <button onClick={() => scrollToSection('features')} className="text-left">产品功能</button>
                <button onClick={() => scrollToSection('solutions')} className="text-left">解决方案</button>
                <button onClick={() => scrollToSection('pricing')} className="text-left">价格方案</button>
                <button onClick={() => scrollToSection('about')} className="text-left">关于我们</button>
                <Separator />
                <div className="flex flex-col gap-2">
                  <Button variant="ghost" size="sm">登录</Button>
                  <Button size="sm">免费试用</Button>
                  {onNavigateToApp && (
                    <Button variant="outline" size="sm" onClick={onNavigateToApp}>
                      进入平台
                    </Button>
                  )}
                </div>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* 主要内容 */}
      <main>
        {/* 首页 Hero Section */}
        <section id="home" className="py-20 lg:py-32">
          <div className="container mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="space-y-4">
                  <Badge variant="secondary" className="w-fit">
                    AI驱动 · 数据赋能
                  </Badge>
                  <h1 className="text-4xl lg:text-6xl tracking-tight">
                    让美容院营销
                    <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                      更智能
                    </span>
                  </h1>
                  <p className="text-xl text-muted-foreground max-w-md">
                    智美云图为美容院提供AI驱动的用户画像分析和精准营销解决方案，助力业务增长。
                  </p>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="gap-2">
                    <Play className="w-4 h-4" />
                    免费试用30天
                  </Button>
                  <Button variant="outline" size="lg">
                    查看演示
                  </Button>
                </div>
                
                <div className="grid grid-cols-4 gap-8 pt-8">
                  {stats.map((stat, index) => (
                    <div key={index} className="text-center">
                      <div className="text-2xl text-primary">{stat.number}</div>
                      <div className="text-sm text-muted-foreground">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="relative">
                <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                  <ImageWithFallback 
                    src="https://images.unsplash.com/photo-1611211235015-e2e3a7d09e97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBiZWF1dHklMjBzYWxvbiUyMGludGVyaW9yfGVufDF8fHx8MTc1ODUzNjI3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="现代美容院"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -left-6 bg-card p-6 rounded-lg shadow-lg border">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <div>营销ROI提升</div>
                      <div className="text-2xl text-green-600">+60%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 产品功能 */}
        <section id="features" className="py-20 bg-muted/30">
          <div className="container mx-auto px-6">
            <div className="text-center space-y-4 mb-16">
              <Badge variant="secondary">核心功能</Badge>
              <h2 className="text-3xl lg:text-4xl">
                六大核心模块，构建营销闭环
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                从数据采集到效果追踪，智美云图为美容院提供完整���智能营销解决方案
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
              {/* 数据采集模块 */}
              <Card className="group hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-blue-50 to-blue-100/50 border-blue-200 overflow-hidden">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-500/30 transition-colors">
                    <Database className="w-8 h-8 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">数据采集</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-center">
                    多渠道数据采集，包含消费行为画像和肌肤健康画像，构建完整的客户数据库。
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">智能客户信息采集</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">消费行为数据追踪</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">肌肤健康状态记录</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 用户画像模块 */}
              <Card className="group hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-purple-50 to-purple-100/50 border-purple-200 overflow-hidden">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-500/30 transition-colors">
                    <Brain className="w-8 h-8 text-purple-600" />
                  </div>
                  <CardTitle className="text-xl">AI用户画像</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-center">
                    基于AI算法构建精准的客户画像，实现个性化服务和精准营销推荐。
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">AI智能画像生成</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">多维度客户分析</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">个性化推荐引擎</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 营销策略模块 */}
              <Card className="group hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-green-50 to-green-100/50 border-green-200 overflow-hidden">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-500/30 transition-colors">
                    <Target className="w-8 h-8 text-green-600" />
                  </div>
                  <CardTitle className="text-xl">营销策略</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-center">
                    智能营销策略制定，支持活动创建和多渠道投放，提升营销效果。
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">智能策略推荐</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">活动快速创建</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">多平台一键投放</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 效果追踪模块 */}
              <Card className="group hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-orange-50 to-orange-100/50 border-orange-200 overflow-hidden">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-orange-500/30 transition-colors">
                    <TrendingUp className="w-8 h-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-xl">效果追踪</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-center">
                    实时监控营销效果，提供详细的数据分析和ROI计算，优化营销策略。
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">实时数据监控</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">ROI自动计算</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">可视化报表分析</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 营销文案生成模块 */}
              <Card className="group hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-pink-50 to-pink-100/50 border-pink-200 overflow-hidden">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-pink-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-pink-500/30 transition-colors">
                    <PenTool className="w-8 h-8 text-pink-600" />
                  </div>
                  <CardTitle className="text-xl">AI文案生成</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-center">
                    AI智能生成营销文案，支持多种文案类型和风格，提升营销内容创作效率。
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">智能文案生成</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">多种风格模板</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">一键活动链接生成</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 美容院网店配置模块 */}
              <Card className="group hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-indigo-50 to-indigo-100/50 border-indigo-200 overflow-hidden">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-indigo-500/30 transition-colors">
                    <Store className="w-8 h-8 text-indigo-600" />
                  </div>
                  <CardTitle className="text-xl">网店配置</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-center">
                    完整的网店管理系统，支持线上小程序发布，打通线上线下营销闭环。
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">一站式店铺管理</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">小程序一键发布</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">线上线下数据打通</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* 解决方案 */}
        <section id="solutions" className="py-20">
          <div className="container mx-auto px-6">
            <div className="text-center space-y-4 mb-16">
              <Badge variant="secondary">解决方案</Badge>
              <h2 className="text-3xl lg:text-4xl">
                针对美业痛点，提供专业解决方案
              </h2>
            </div>
            
            <div className="space-y-16">
              {solutions.map((solution, index) => (
                <div key={index} className={`grid lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''}`}>
                  <div className={`space-y-6 ${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
                    <h3 className="text-2xl">{solution.title}</h3>
                    <p className="text-lg text-muted-foreground">{solution.description}</p>
                    <div className="space-y-3">
                      {solution.results.map((result, resultIndex) => (
                        <div key={resultIndex} className="flex items-center gap-3">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span>{result}</span>
                        </div>
                      ))}
                    </div>
                    <Button className="gap-2">
                      了解更多 <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className={`${index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}`}>
                    <div className="aspect-[4/3] rounded-xl overflow-hidden shadow-lg">
                      <ImageWithFallback 
                        src={solution.image}
                        alt={solution.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 客户证言 */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-6">
            <div className="text-center space-y-4 mb-16">
              <Badge variant="secondary">客户证言</Badge>
              <h2 className="text-3xl lg:text-4xl">
                来自客户的真实反馈
              </h2>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="p-6">
                  <CardContent className="space-y-4 p-0">
                    <div className="flex gap-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-muted-foreground italic">"{testimonial.content}"</p>
                    <div className="flex items-center gap-3">
                      <ImageWithFallback 
                        src={testimonial.avatar}
                        alt={testimonial.name}
                        className="w-10 h-10 rounded-full"
                      />
                      <div>
                        <div>{testimonial.name}</div>
                        <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* 价格方案 */}
        <section id="pricing" className="py-20">
          <div className="container mx-auto px-6">
            <div className="text-center space-y-4 mb-16">
              <Badge variant="secondary">价格方案</Badge>
              <h2 className="text-3xl lg:text-4xl">
                选择适合您的方案
              </h2>
              <p className="text-xl text-muted-foreground">
                透明定价，无隐藏费用，随时可以升级或取消
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {pricingPlans.map((plan, index) => (
                <Card key={index} className={`relative ${plan.recommended ? 'ring-2 ring-primary shadow-lg' : ''}`}>
                  {plan.recommended && (
                    <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">
                      推荐方案
                    </Badge>
                  )}
                  <CardHeader className="text-center">
                    <CardTitle>{plan.name}</CardTitle>
                    <div className="space-y-2">
                      <div className="text-3xl">
                        ¥{plan.price}
                        <span className="text-base text-muted-foreground">/{plan.period}</span>
                      </div>
                      <p className="text-muted-foreground">{plan.description}</p>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center gap-3">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button 
                      className="w-full" 
                      variant={plan.recommended ? 'default' : 'outline'}
                    >
                      {plan.recommended ? '立即开始' : '选择方案'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* 关于我们 */}
        <section id="about" className="py-20 bg-muted/30">
          <div className="container mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="space-y-4">
                  <Badge variant="secondary">关于我们</Badge>
                  <h2 className="text-3xl lg:text-4xl">
                    专注美业数字化转型的技术团队
                  </h2>
                  <p className="text-lg text-muted-foreground">
                    我们是一支来自腾讯、阿里等知名企业的技术团队，深度理解美业痛点，致力于用AI技术赋能传统美业，助力行业数字化升级。
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-primary" />
                      <span>行业专业</span>
                    </div>
                    <p className="text-sm text-muted-foreground">15年美业经验积累</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Brain className="w-5 h-5 text-primary" />
                      <span>技术领先</span>
                    </div>
                    <p className="text-sm text-muted-foreground">自主研发AI算法</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-primary" />
                      <span>客户优先</span>
                    </div>
                    <p className="text-sm text-muted-foreground">专业客户成功团队</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Shield className="w-5 h-5 text-primary" />
                      <span>安全可靠</span>
                    </div>
                    <p className="text-sm text-muted-foreground">企业级安全保障</p>
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <div className="aspect-[4/3] rounded-xl overflow-hidden shadow-lg">
                  <ImageWithFallback 
                    src="https://images.unsplash.com/photo-1709715357520-5e1047a2b691?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFtJTIwbWVldGluZyUyMGJ1c2luZXNzfGVufDF8fHx8MTc1ODU0NzkzNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="团队会议"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <CardContent className="p-12 text-center space-y-6">
                <h2 className="text-3xl lg:text-4xl">
                  准备开始您的数字化转型之旅？
                </h2>
                <p className="text-xl opacity-90 max-w-2xl mx-auto">
                  立即体验智美云图，让AI技术为您的美容院带来更多客户和收入
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" variant="secondary" className="gap-2">
                    <Play className="w-4 h-4" />
                    免费试用30天
                  </Button>
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                    预约演示
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* 页脚 */}
      <footer className="bg-muted/50 py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-primary" />
                <span>智美云图</span>
              </div>
              <p className="text-sm text-muted-foreground">
                专业的美容院智能营销解决方案提供商
              </p>
            </div>
            
            <div className="space-y-4">
              <h4>产品</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>用户画像分析</li>
                <li>营销策略制定</li>
                <li>效果追踪</li>
                <li>小程序集成</li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4>服务</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>客户培训</li>
                <li>技术支持</li>
                <li>定制开发</li>
                <li>数据迁移</li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4>联系我们</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>400-888-9999</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>contact@zhimeiyt.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>北京市海淀区中关村软件园</span>
                </div>
              </div>
            </div>
          </div>
          
          <Separator className="my-8" />
          
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>© 2024 智美云图科技有限公司. 保留所有权利.</p>
            <div className="flex gap-6">
              <button>隐私政策</button>
              <button>服务条款</button>
              <button>Cookie政策</button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}