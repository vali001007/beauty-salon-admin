import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  Target, 
  TrendingUp, 
  Users, 
  Brain,
  Smartphone,
  BarChart3,
  Zap,
  Shield,
  Star,
  CheckCircle,
  ArrowRight,
  Play,
  Download,
  Phone,
  Mail,
  Calendar,
  Award,
  Sparkles,
  DollarSign,
  Clock,
  Globe,
  Heart,
  MessageSquare,
  Camera,
  Palette,
  Database,
  ChevronRight,
  Lightbulb,
  Rocket
} from 'lucide-react';

interface MarketingDemoProps {
  onNavigateToApp?: () => void;
}

export function MarketingDemo({ onNavigateToApp }: MarketingDemoProps) {
  const [activeSection, setActiveSection] = useState('overview');

  // 核心功能特性
  const coreFeatures = [
    {
      icon: Brain,
      title: 'AI智能画像',
      description: '基于多维度数据构建精准客户画像',
      benefit: '提升转化率50%+',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      icon: Target,
      title: '精准营销',
      description: '数据驱动的个性化营销策略',
      benefit: '降低获客成本30%+',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      icon: Smartphone,
      title: '小程序集成',
      description: '一键发布到微信小程序生态',
      benefit: '扩大客户触达200%+',
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      icon: BarChart3,
      title: '效果追踪',
      description: '实时数据分析和ROI监控',
      benefit: '提升营销ROI 40%+',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    }
  ];

  // 成功案例数据
  const successCases = [
    {
      name: '雅致美容院',
      type: '连锁美容院',
      location: '深圳',
      stores: 12,
      results: {
        revenueGrowth: 65,
        customerGrowth: 120,
        conversionRate: 45,
        timeframe: '6个月'
      },
      testimonial: '智美云图帮助我们实现了数字化转型，客户画像功能让我们的营销更加精准，业绩提升显著。',
      avatar: '🏪'
    },
    {
      name: '美丽人生美容',
      type: '高端美容院',
      location: '上海',
      stores: 3,
      results: {
        revenueGrowth: 85,
        customerGrowth: 95,
        conversionRate: 60,
        timeframe: '4个月'
      },
      testimonial: 'AI智能推荐让我们的服务更个性化，客户满意度大幅提升，复购率明显增加。',
      avatar: '💎'
    },
    {
      name: '青春美肌工作室',
      type: '个人工作室',
      location: '广州',
      stores: 1,
      results: {
        revenueGrowth: 150,
        customerGrowth: 180,
        conversionRate: 75,
        timeframe: '3个月'
      },
      testimonial: '作为小型工作室，这个平台让我也能享受到大品牌的营销工具，效果超出预期。',
      avatar: '✨'
    }
  ];

  // 价格方案
  const pricingPlans = [
    {
      name: '基础版',
      price: 999,
      period: '月',
      description: '适合小型美容院',
      features: [
        '基础客户画像',
        '简单营销策略',
        '小程序发布',
        '基础数据分析',
        '邮件客服支持'
      ],
      limitations: [
        '客户数量: 500个',
        '营销活动: 5个/月',
        '数据存储: 1GB'
      ],
      recommended: false,
      badge: null
    },
    {
      name: '专业版',
      price: 2999,
      period: '月',
      description: '适合中型连锁美容院',
      features: [
        '高级AI客户画像',
        '智能营销策略',
        '小程序定制',
        '实时效果追踪',
        '腾讯广告集成',
        '电话客服支持'
      ],
      limitations: [
        '客户数量: 5000个',
        '营销活动: 20个/月',
        '数据存储: 10GB'
      ],
      recommended: true,
      badge: '推荐'
    },
    {
      name: '企业版',
      price: 59999,
      period: '年',
      description: '适合大型连锁企业',
      features: [
        '全功能AI分析',
        '定制营销方案',
        '多品牌管理',
        '高级数据洞察',
        'API集成',
        '专属客户经理',
        '现场培训支持'
      ],
      limitations: [
        '客户数量: 无限制',
        '营销活动: 无限制',
        '数据存储: 100GB'
      ],
      recommended: false,
      badge: '企业首选'
    }
  ];

  // 实施流程
  const implementationSteps = [
    {
      step: 1,
      title: '需求分析',
      description: '深入了解您的业务需求和目标',
      duration: '1-2天',
      deliverables: ['需求分析报告', '解决方案建议']
    },
    {
      step: 2,
      title: '系统配置',
      description: '根据您的业务配置系统参数',
      duration: '3-5天',
      deliverables: ['系统配置文档', '数据导入方案']
    },
    {
      step: 3,
      title: '数据迁移',
      description: '安全迁移现有客户和业务数据',
      duration: '2-3天',
      deliverables: ['数据迁移报告', '数据质量检查']
    },
    {
      step: 4,
      title: '团队培训',
      description: '全面培训您的团队使用系统',
      duration: '1-2天',
      deliverables: ['培训材料', '操作手册']
    },
    {
      step: 5,
      title: '上线运营',
      description: '正式上线并提供持续支持',
      duration: '持续',
      deliverables: ['上线报告', '运营支持']
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 导航栏 */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl">智美云图</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <button 
                onClick={() => setActiveSection('overview')}
                className={`hover:text-primary transition-colors ${activeSection === 'overview' ? 'text-primary font-medium' : 'text-muted-foreground'}`}
              >
                产品概述
              </button>
              <button 
                onClick={() => setActiveSection('features')}
                className={`hover:text-primary transition-colors ${activeSection === 'features' ? 'text-primary font-medium' : 'text-muted-foreground'}`}
              >
                核心功能
              </button>
              <button 
                onClick={() => setActiveSection('cases')}
                className={`hover:text-primary transition-colors ${activeSection === 'cases' ? 'text-primary font-medium' : 'text-muted-foreground'}`}
              >
                成功案例
              </button>
              <button 
                onClick={() => setActiveSection('pricing')}
                className={`hover:text-primary transition-colors ${activeSection === 'pricing' ? 'text-primary font-medium' : 'text-muted-foreground'}`}
              >
                价格方案
              </button>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm">
                <Play className="w-4 h-4 mr-2" />
                观看演示
              </Button>
              <Button size="sm">
                <Calendar className="w-4 h-4 mr-2" />
                预约咨询
              </Button>
              {onNavigateToApp && (
                <Button variant="outline" size="sm" onClick={onNavigateToApp}>
                  <ArrowRight className="w-4 h-4 mr-2" />
                  进入产品
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* 英雄区域 */}
      {activeSection === 'overview' && (
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center space-y-8">
              <div className="space-y-4">
                <Badge variant="secondary" className="px-4 py-2">
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI驱动的美容院营销解决方案
                </Badge>
                <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  智美云图·用户画像营销管理平台
                </h1>
                <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                  提供"数据采集-画像构建-策略执行-效果追踪"全链路服务，
                  助力美容院实现数字化转型，提升营销效果和客户价值
                </p>
              </div>
              
              <div className="flex items-center justify-center gap-6">
                <Button size="lg" className="px-8">
                  <Rocket className="w-5 h-5 mr-2" />
                  免费试用
                </Button>
                <Button variant="outline" size="lg" className="px-8">
                  <Download className="w-5 h-5 mr-2" />
                  下载资料
                </Button>
              </div>

              {/* 核心数据展示 */}
              <div className="grid md:grid-cols-4 gap-8 mt-16">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">500+</div>
                  <div className="text-muted-foreground">合作美容院</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">50%+</div>
                  <div className="text-muted-foreground">平均转化率提升</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">200%+</div>
                  <div className="text-muted-foreground">客户触达增长</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">98%</div>
                  <div className="text-muted-foreground">客户满意度</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* 核心功能 */}
      {activeSection === 'features' && (
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center space-y-4 mb-16">
              <h2 className="text-4xl font-bold">核心功能特性</h2>
              <p className="text-xl text-muted-foreground">
                六大核心模块，构建完整的营销闭环
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {coreFeatures.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 bg-white/50 backdrop-blur-sm">
                    <CardContent className="p-8 text-center space-y-4">
                      <div className={`w-16 h-16 mx-auto rounded-xl ${feature.bgColor} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <Icon className={`w-8 h-8 ${feature.color}`} />
                      </div>
                      <h3 className="font-bold text-lg">{feature.title}</h3>
                      <p className="text-muted-foreground">{feature.description}</p>
                      <Badge variant="secondary" className="font-medium">
                        {feature.benefit}
                      </Badge>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* 功能模块详情 */}
            <Tabs defaultValue="dashboard" className="w-full">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="dashboard">仪表板</TabsTrigger>
                <TabsTrigger value="collection">数据采集</TabsTrigger>
                <TabsTrigger value="profile">用户画像</TabsTrigger>
                <TabsTrigger value="strategy">营销策略</TabsTrigger>
                <TabsTrigger value="tracking">效果追踪</TabsTrigger>
                <TabsTrigger value="copywriter">文案生成</TabsTrigger>
              </TabsList>
              
              <TabsContent value="dashboard" className="mt-8">
                <Card>
                  <CardContent className="p-8">
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                      <div className="space-y-6">
                        <h3 className="text-2xl font-bold">智能仪表板概览</h3>
                        <p className="text-muted-foreground text-lg">
                          实时监控业务关键指标，一目了然掌握经营状况。
                          包含客户数据、营销效果、收入分析等核心数据。
                        </p>
                        <ul className="space-y-3">
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>实时业务数据监控</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>关键指标可视化展示</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>自定义报表生成</span>
                          </li>
                        </ul>
                      </div>
                      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-8">
                        <div className="text-center space-y-4">
                          <BarChart3 className="w-20 h-20 text-blue-600 mx-auto" />
                          <p className="text-muted-foreground">仪表板界面预览</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="collection" className="mt-8">
                <Card>
                  <CardContent className="p-8">
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                      <div className="space-y-6">
                        <h3 className="text-2xl font-bold">智能数据采集</h3>
                        <p className="text-muted-foreground text-lg">
                          多渠道数据采集，构建完整的客户数据基础。
                          支持消费行为画像和肌肤健康画像分析。
                        </p>
                        <ul className="space-y-3">
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>多渠道数据整合</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>消费行为分析</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>肌肤健康档案</span>
                          </li>
                        </ul>
                      </div>
                      <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-8">
                        <div className="text-center space-y-4">
                          <Database className="w-20 h-20 text-green-600 mx-auto" />
                          <p className="text-muted-foreground">数据采集界面</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="profile" className="mt-8">
                <Card>
                  <CardContent className="p-8">
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                      <div className="space-y-6">
                        <h3 className="text-2xl font-bold">AI用户画像</h3>
                        <p className="text-muted-foreground text-lg">
                          基于AI算法构建精准的客户画像，
                          实现个性化服务和精准营销推荐。
                        </p>
                        <ul className="space-y-3">
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>AI智能画像生成</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>多维度客户分析</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>个性化推荐引擎</span>
                          </li>
                        </ul>
                      </div>
                      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-8">
                        <div className="text-center space-y-4">
                          <Brain className="w-20 h-20 text-purple-600 mx-auto" />
                          <p className="text-muted-foreground">用户画像分析</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="strategy" className="mt-8">
                <Card>
                  <CardContent className="p-8">
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                      <div className="space-y-6">
                        <h3 className="text-2xl font-bold">智能营销策略</h3>
                        <p className="text-muted-foreground text-lg">
                          基于用户画像制定个性化营销策略，
                          支持多渠道营销活动创建和管理。
                        </p>
                        <ul className="space-y-3">
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>智能策略推荐</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>活动创建管理</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>腾讯广告投放</span>
                          </li>
                        </ul>
                      </div>
                      <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-8">
                        <div className="text-center space-y-4">
                          <Target className="w-20 h-20 text-orange-600 mx-auto" />
                          <p className="text-muted-foreground">营销策略配置</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="tracking" className="mt-8">
                <Card>
                  <CardContent className="p-8">
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                      <div className="space-y-6">
                        <h3 className="text-2xl font-bold">实时效果追踪</h3>
                        <p className="text-muted-foreground text-lg">
                          全面追踪营销活动效果，实时监控ROI，
                          提供详细的数据分析和优化建议。
                        </p>
                        <ul className="space-y-3">
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>实时数据监控</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>ROI分析报告</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>优化建议生成</span>
                          </li>
                        </ul>
                      </div>
                      <div className="bg-gradient-to-br from-teal-50 to-green-50 rounded-xl p-8">
                        <div className="text-center space-y-4">
                          <TrendingUp className="w-20 h-20 text-teal-600 mx-auto" />
                          <p className="text-muted-foreground">效果追踪分析</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="copywriter" className="mt-8">
                <Card>
                  <CardContent className="p-8">
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                      <div className="space-y-6">
                        <h3 className="text-2xl font-bold">AI文案生成</h3>
                        <p className="text-muted-foreground text-lg">
                          AI驱动的营销文案生成工具，
                          快��创建高质量的营销内容和广告文案。
                        </p>
                        <ul className="space-y-3">
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>AI智能文案生成</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>多场景模板库</span>
                          </li>
                          <li className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span>品牌风格定制</span>
                          </li>
                        </ul>
                      </div>
                      <div className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-xl p-8">
                        <div className="text-center space-y-4">
                          <Palette className="w-20 h-20 text-pink-600 mx-auto" />
                          <p className="text-muted-foreground">文案生成工具</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </section>
      )}

      {/* 成功案例 */}
      {activeSection === 'cases' && (
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center space-y-4 mb-16">
              <h2 className="text-4xl font-bold">成功案例</h2>
              <p className="text-xl text-muted-foreground">
                真实客户案例，见证平台价值
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {successCases.map((case_, index) => (
                <Card key={index} className="group hover:shadow-xl transition-all duration-300">
                  <CardHeader className="text-center">
                    <div className="text-4xl mb-4">{case_.avatar}</div>
                    <CardTitle className="text-xl">{case_.name}</CardTitle>
                    <p className="text-muted-foreground">
                      {case_.type} · {case_.location} · {case_.stores}家门店
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* 效果数据 */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          +{case_.results.revenueGrowth}%
                        </div>
                        <div className="text-sm text-muted-foreground">营业额增长</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          +{case_.results.customerGrowth}%
                        </div>
                        <div className="text-sm text-muted-foreground">客户增长</div>
                      </div>
                      <div className="text-center col-span-2">
                        <div className="text-2xl font-bold text-purple-600">
                          {case_.results.conversionRate}%
                        </div>
                        <div className="text-sm text-muted-foreground">转化率提升</div>
                      </div>
                    </div>

                    {/* 时间框架 */}
                    <div className="text-center">
                      <Badge variant="secondary">
                        <Clock className="w-4 h-4 mr-2" />
                        {case_.results.timeframe}内实现
                      </Badge>
                    </div>

                    {/* 客户评价 */}
                    <blockquote className="text-sm text-muted-foreground italic">
                      "{case_.testimonial}"
                    </blockquote>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* 更多案例按钮 */}
            <div className="text-center mt-12">
              <Button variant="outline" size="lg">
                查看更多案例
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </section>
      )}

      {/* 价格方案 */}
      {activeSection === 'pricing' && (
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center space-y-4 mb-16">
              <h2 className="text-4xl font-bold">价格方案</h2>
              <p className="text-xl text-muted-foreground">
                选择最适合您业务规模的方案
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-16">
              {pricingPlans.map((plan, index) => (
                <Card key={index} className={`relative ${plan.recommended ? 'ring-2 ring-primary shadow-xl scale-105' : ''}`}>
                  {plan.badge && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="px-4 py-1">
                        {plan.badge}
                      </Badge>
                    </div>
                  )}
                  <CardHeader className="text-center space-y-4">
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <div className="space-y-1">
                      <div className="flex items-center justify-center gap-1">
                        <span className="text-sm">¥</span>
                        <span className="text-4xl font-bold">{plan.price.toLocaleString()}</span>
                        <span className="text-muted-foreground">/{plan.period}</span>
                      </div>
                      <p className="text-muted-foreground">{plan.description}</p>
                    </div>
                    <Button 
                      className={plan.recommended ? 'w-full' : 'w-full'} 
                      variant={plan.recommended ? 'default' : 'outline'}
                    >
                      {plan.recommended ? '立即开始' : '选择方案'}
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* 功能特性 */}
                    <div className="space-y-3">
                      <h4 className="font-medium">包含功能：</h4>
                      <ul className="space-y-2">
                        {plan.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center gap-3">
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                            <span className="text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* 使用限制 */}
                    <div className="space-y-3">
                      <h4 className="font-medium">使用限制：</h4>
                      <ul className="space-y-2">
                        {plan.limitations.map((limit, limitIndex) => (
                          <li key={limitIndex} className="flex items-center gap-3">
                            <Badge variant="secondary" className="flex-shrink-0 text-xs">
                              限制
                            </Badge>
                            <span className="text-sm text-muted-foreground">{limit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* 实施流程 */}
            <Card className="mb-16">
              <CardHeader>
                <CardTitle className="text-center text-2xl">实施流程</CardTitle>
                <p className="text-center text-muted-foreground">
                  专业的实施团队，确保快速上线
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {implementationSteps.map((step, index) => (
                    <div key={index} className="flex gap-6">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                          {step.step}
                        </div>
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-4">
                          <h3 className="font-bold text-lg">{step.title}</h3>
                          <Badge variant="outline">
                            <Clock className="w-3 h-3 mr-1" />
                            {step.duration}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground">{step.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {step.deliverables.map((deliverable, delIndex) => (
                            <Badge key={delIndex} variant="secondary" className="text-xs">
                              {deliverable}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 联系我们 */}
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-primary/20">
              <CardContent className="p-8 text-center space-y-6">
                <h3 className="text-2xl font-bold">准备开始数字化转型？</h3>
                <p className="text-muted-foreground text-lg">
                  联系我们的专业顾问，获取个性化解决方案和报价
                </p>
                <div className="flex items-center justify-center gap-4">
                  <Button size="lg" className="px-8">
                    <Phone className="w-5 h-5 mr-2" />
                    电话咨询：400-888-8888
                  </Button>
                  <Button variant="outline" size="lg" className="px-8">
                    <Mail className="w-5 h-5 mr-2" />
                    邮件联系
                  </Button>
                </div>
                <div className="flex items-center justify-center gap-8 text-sm text-muted-foreground">
                  <span>✓ 免费试用30天</span>
                  <span>✓ 专业技术支持</span>
                  <span>✓ 数据安全保障</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* 页脚 */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-xl">智美云图</span>
              </div>
              <p className="text-gray-400">
                AI驱动的美容院营销管理平台，助力行业数字化转型
              </p>
            </div>
            <div className="space-y-4">
              <h4 className="font-bold">产品功能</h4>
              <ul className="space-y-2 text-gray-400">
                <li>AI用户画像</li>
                <li>精准营销</li>
                <li>效果追踪</li>
                <li>文案生成</li>
              </ul>
            </div>
            <div className="space-y-4">
              <h4 className="font-bold">服务支持</h4>
              <ul className="space-y-2 text-gray-400">
                <li>技术文档</li>
                <li>视频教程</li>
                <li>在线客服</li>
                <li>培训服务</li>
              </ul>
            </div>
            <div className="space-y-4">
              <h4 className="font-bold">联系我们</h4>
              <ul className="space-y-2 text-gray-400">
                <li>电话：400-888-8888</li>
                <li>邮箱：contact@zhimei.com</li>
                <li>地址：深圳市南山区</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 智美云图. 保留所有权利.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}