import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import { useCampaigns } from '../App';
import { toast } from 'sonner@2.0.3';
import { 
  PenTool, 
  Sparkles, 
  Users, 
  Copy,
  Download,
  RefreshCw,
  Settings,
  Plus,
  Trash2,
  Edit,
  Eye,
  Heart,
  Gift,
  Calendar,
  Star,
  MessageCircle,
  Zap,
  Target,
  Clock,
  Link2,
  ExternalLink,
  Share2,
  QrCode
} from 'lucide-react';

// 模拟客户数据
const mockCustomers = [
  {
    id: 1,
    name: '张美丽',
    age: 28,
    skinType: '混合性',
    concerns: ['毛孔粗大', '暗沉'],
    level: '中等消费',
    frequency: '月2-3次',
    avgAmount: 420,
    preferences: ['面部护理', '美甲'],
    promotionSensitive: '高',
    loyaltyScore: 78,
    lastVisit: '2024-01-15',
  },
  {
    id: 2,
    name: '李雅静',
    age: 35,
    skinType: '干性',
    concerns: ['细纹', '缺水'],
    level: '高消费',
    frequency: '月1次',
    avgAmount: 650,
    preferences: ['面部护理', '身体SPA'],
    promotionSensitive: '中',
    loyaltyScore: 88,
    lastVisit: '2024-01-20',
  },
  {
    id: 3,
    name: '王优雅',
    age: 42,
    skinType: '敏感性',
    concerns: ['敏感泛红', '松弛'],
    level: '超高消费',
    frequency: '月4-5次',
    avgAmount: 890,
    preferences: ['抗衰护理', '身体护理'],
    promotionSensitive: '低',
    loyaltyScore: 95,
    lastVisit: '2024-01-18',
  },
];

// 文案类型模板
const copyTemplates = [
  {
    id: 'promotion',
    name: '促销活动',
    icon: Gift,
    description: '优惠活动、限时折扣等促销文案',
    tags: ['限时优惠', '专享折扣', '会员特价'],
    prompt: '基于客户的消费水平和偏好，生成吸引人的促销活动文案，突出优惠力度和服务特色。',
  },
  {
    id: 'service-recommend',
    name: '服务推荐',
    icon: Heart,
    description: '个性化服务推荐和介绍文案',
    tags: ['专业护理', '定制服务', '美肌方案'],
    prompt: '根据客户的肌肤类型和关注问题，推荐最适合的服务项目，专业而贴心。',
  },
  {
    id: 'seasonal',
    name: '季节营销',
    icon: Calendar,
    description: '节日祝福、季节护理等主题文案',
    tags: ['春季护肤', '夏日美白', '节日祝福'],
    prompt: '结合季节特点和节日氛围，为客户推送应季护理建议和节日祝福。',
  },
  {
    id: 'retention',
    name: '客户留存',
    icon: Star,
    description: '感谢回馈、忠诚度提升文案',
    tags: ['感谢回馈', 'VIP专享', '忠诚客户'],
    prompt: '对忠诚客户表达感谢，提供专属优惠，增强客户归属感和满意度。',
  },
  {
    id: 'winback',
    name: '流失召回',
    icon: MessageCircle,
    description: '唤回流失客户的关怀文案',
    tags: ['想念您', '专属优惠', '重新体验'],
    prompt: '用温暖的语调表达对流失客户的关怀，提供诱人的回归优惠。',
  },
];

// 生成的文案历史
const generatedCopies = [
  {
    id: 1,
    customer: '张美丽',
    type: '促销活动',
    content: '亲爱的张美丽，您专属的春季护肤套餐来了！针对您关注的毛孔粗大问题，我们特别推出深层清洁+收毛孔护理套餐，限时8折优惠！让您的肌肤在春日里焕发新生光彩✨',
    tags: ['限时优惠', '专享折扣', '深层清洁'],
    createdAt: '2024-01-22 14:30',
    status: '已发送',
  },
  {
    id: 2,
    customer: '李雅静',
    type: '服务推荐',
    content: '李女士，根据您的干性肌肤特点，我们为您精心准备了玻尿酸深度补水护理。这项服务特别适合改善细纹和缺水问题，让您的肌肤重现水润光泽。立即预约享受专业护理！',
    tags: ['专业护理', '定制服务', '深度补水'],
    createdAt: '2024-01-21 16:45',
    status: '草稿',
  },
  {
    id: 3,
    customer: '王优雅',
    type: '客户留存',
    content: '王女士，感谢您一直以来对我们的信任！作为我们的VIP客户，您的每一次到店都让我们倍感荣幸。特为您准备了专属抗衰护理套餐，让我们继续为您的美丽护航💎',
    tags: ['VIP专享', '忠诚客户', '抗衰护理'],
    createdAt: '2024-01-20 10:15',
    status: '已发送',
  },
];

export function MarketingCopywriter() {
  const { campaigns } = useCampaigns();
  const [selectedCustomers, setSelectedCustomers] = useState<number[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [customPrompt, setCustomPrompt] = useState('');
  const [customTags, setCustomTags] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState('generate');
  const [selectedCampaign, setSelectedCampaign] = useState<string>('');
  const [activityLinks, setActivityLinks] = useState<string[]>([]);

  const handleCustomerToggle = (customerId: number) => {
    setSelectedCustomers(prev => 
      prev.includes(customerId)
        ? prev.filter(id => id !== customerId)
        : [...prev, customerId]
    );
  };

  const handleGenerateCopy = async () => {
    if (selectedCustomers.length === 0 || !selectedTemplate) {
      return;
    }

    setIsGenerating(true);
    
    // 模拟API调用生成文案
    setTimeout(() => {
      const template = copyTemplates.find(t => t.id === selectedTemplate);
      const customer = mockCustomers.find(c => selectedCustomers.includes(c.id));
      
      if (template && customer) {
        // 这里是模拟生成的文案，实际应该调用AI接口
        let simulatedContent = '';
        
        switch (template.id) {
          case 'promotion':
            simulatedContent = `亲爱的${customer.name}，您专属的优惠活动来了！针对您关注的${customer.concerns.join('、')}问题，我们特别推出${customer.preferences.join('+')}套餐，限时特价¥${Math.round(customer.avgAmount * 0.8)}！让您的肌肤焕发新生光彩✨`;
            break;
          case 'service-recommend':
            simulatedContent = `${customer.name}女士，根据您的${customer.skinType}肌肤特点，我们为您精心准备了专业护理方案。特别适合改善${customer.concerns.join('和')}问题，让您的肌肤重现健康光泽。立即预约享受专业定制服务！`;
            break;
          case 'seasonal':
            simulatedContent = `${customer.name}，春季护肤季到了！根据您的${customer.skinType}肌肤，我们推荐春季修护套餐，专门针对${customer.concerns[0]}问题设计。让您的肌肤在春日里绽放自然美丽🌸`;
            break;
          case 'retention':
            simulatedContent = `${customer.name}女士，感谢您一直以来的信任！作为我们的${customer.level}客户，您的每次到店都让我们倍感荣幸。特为您准备了专属${customer.preferences[0]}套餐，让我们继续为您的美丽护航💎`;
            break;
          case 'winback':
            simulatedContent = `${customer.name}，好久不见，我们很想念您！特别为您准备了专属回归优惠：${customer.preferences.join('+')}套餐仅需¥${Math.round(customer.avgAmount * 0.7)}。期待您的再次光临，让我们重新为您的美丽加分！`;
            break;
          default:
            simulatedContent = `${customer.name}，我们为您精心定制了专属护理方案...`;
        }
        
        setGeneratedContent(simulatedContent);
      }
      
      setIsGenerating(false);
    }, 2000);
  };

  const handleSaveCopy = () => {
    // 这里应该保存文案到数据库
    console.log('保存文案:', generatedContent);
    toast.success('文案已保存');
  };

  const handleCopyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generatedContent);
      toast.success('文案已复制到剪贴板');
    } catch (error) {
      // 如果剪贴板API失败，使用备用方案
      const textarea = document.createElement('textarea');
      textarea.value = generatedContent;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        toast.success('文案已复制到剪贴板');
      } catch (err) {
        toast.error('复制失败，请手动复制');
      }
      document.body.removeChild(textarea);
    }
  };

  const handleCopyActivityLink = async (link: string) => {
    try {
      await navigator.clipboard.writeText(link);
      toast.success('链接已复制到剪贴板');
    } catch (error) {
      // 如果剪贴板API失败，使用备用方案
      const textarea = document.createElement('textarea');
      textarea.value = link;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        toast.success('链接已复制到剪贴板');
      } catch (err) {
        toast.error('复制失败，请手动复制');
      }
      document.body.removeChild(textarea);
    }
  };

  const handleGenerateActivityLink = () => {
    // 根据选中的活动生成链接
    const selectedCampaignData = campaigns.find(c => c.id.toString() === selectedCampaign);
    if (selectedCampaignData) {
      const newLink = `https://miniprogram.example.com/activity/${selectedCampaign}?ref=copywriter&utm_source=marketing_copy&utm_medium=link&utm_campaign=${encodeURIComponent(selectedCampaignData.name)}`;
      setActivityLinks(prev => [...prev, newLink]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-medium mb-2 flex items-center gap-2">
            <PenTool className="w-8 h-8" />
            营销文案生成
          </h1>
          <p className="text-muted-foreground">
            基于用户画像智能生成个性化营销文案，提升客户互动效果
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                模板设置
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>文案模板设置</DialogTitle>
                <DialogDescription>
                  创建和编辑营销文案生成模板
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>模板名称</Label>
                  <Input placeholder="输入模板名称" />
                </div>
                <div className="space-y-2">
                  <Label>提示词</Label>
                  <Textarea placeholder="输入生成文案的提示词..." rows={4} />
                </div>
                <div className="space-y-2">
                  <Label>标签</Label>
                  <Input placeholder="输入标签，用逗号分隔" />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline">取消</Button>
                  <Button>保存模板</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            批量导出
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="generate">智能生成</TabsTrigger>
          <TabsTrigger value="templates">模板管理</TabsTrigger>
          <TabsTrigger value="history">历史记录</TabsTrigger>
        </TabsList>

        {/* 智能生成 */}
        <TabsContent value="generate" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* 左侧：客户选择和设置 */}
            <div className="lg:col-span-1 space-y-4">
              {/* 客户选择 */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    选择目标客户
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {mockCustomers.map((customer) => (
                    <div key={customer.id} className="flex items-start space-x-3 p-3 bg-muted rounded-lg">
                      <Checkbox 
                        checked={selectedCustomers.includes(customer.id)}
                        onCheckedChange={() => handleCustomerToggle(customer.id)}
                      />
                      <div className="flex-1">
                        <p className="font-medium">{customer.name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">{customer.level}</Badge>
                          <Badge variant="secondary" className="text-xs">{customer.skinType}</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {customer.concerns.join('、')} • {customer.frequency}
                        </p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* 文案类型选择 */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    文案类型
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {copyTemplates.map((template) => {
                    const Icon = template.icon;
                    return (
                      <div 
                        key={template.id}
                        className={`p-2 rounded-lg border cursor-pointer transition-colors ${
                          selectedTemplate === template.id 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:bg-muted'
                        }`}
                        onClick={() => setSelectedTemplate(template.id)}
                      >
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4" />
                          <span className="font-medium text-sm">{template.name}</span>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              {/* 自定义设置 */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5" />
                    自定义设置
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>自定义提示词</Label>
                    <Textarea 
                      placeholder="输入额外的提示词来定制文案风格..."
                      value={customPrompt}
                      onChange={(e) => setCustomPrompt(e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>自定义标签</Label>
                    <Input 
                      placeholder="输入标签，用逗号分隔"
                      value={customTags}
                      onChange={(e) => setCustomTags(e.target.value)}
                    />
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={handleGenerateCopy}
                    disabled={selectedCustomers.length === 0 || !selectedTemplate || isGenerating}
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        生成中...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        生成文案
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* 右侧：生成结果 */}
            <div className="lg:col-span-2">
              <Card className="h-full">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center gap-2">
                      <MessageCircle className="w-5 h-5" />
                      生成结果
                    </CardTitle>
                    {generatedContent && (
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={handleCopyToClipboard}>
                          <Copy className="w-4 h-4 mr-2" />
                          复制
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleSaveCopy}>
                          <Download className="w-4 h-4 mr-2" />
                          保存
                        </Button>
                        <Button size="sm" onClick={handleGenerateCopy}>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          重新生成
                        </Button>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {generatedContent ? (
                    <div className="space-y-4">
                      <div className="p-4 bg-muted rounded-lg">
                        <p className="whitespace-pre-wrap">{generatedContent}</p>
                      </div>
                      
                      {/* 文案分析 */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="text-center p-3 bg-blue-50 rounded-lg">
                          <p className="text-lg font-bold text-blue-600">{generatedContent.length}</p>
                          <p className="text-sm text-blue-700">字符数</p>
                        </div>
                        <div className="text-center p-3 bg-green-50 rounded-lg">
                          <p className="text-lg font-bold text-green-600">85%</p>
                          <p className="text-sm text-green-700">个性化程度</p>
                        </div>
                        <div className="text-center p-3 bg-purple-50 rounded-lg">
                          <p className="text-lg font-bold text-purple-600">高</p>
                          <p className="text-sm text-purple-700">吸引力评��</p>
                        </div>
                      </div>

                      {/* 优化建议 */}
                      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <h4 className="font-medium text-yellow-800 mb-2">💡 优化建议</h4>
                        <ul className="text-sm text-yellow-700 space-y-1">
                          <li>• 可以加入更多情感化的词汇来增强感染力</li>
                          <li>• 建议添加明确的行动召唤，如"立即预约"</li>
                          <li>• 可以突出限时性来增加紧迫感</li>
                        </ul>
                      </div>

                      {/* 活动链接 */}
                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-medium text-blue-800 flex items-center gap-2">
                            <Link2 className="w-4 h-4" />
                            活动链接
                          </h4>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="text-blue-600 border-blue-300 hover:bg-blue-100">
                                <Plus className="w-3 h-3 mr-1" />
                                添加链接
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-md">
                              <DialogHeader>
                                <DialogTitle>添加活动链接</DialogTitle>
                                <DialogDescription>
                                  选择要关联到文案中的营销活动
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="space-y-2">
                                  <Label>选择活动</Label>
                                  <Select value={selectedCampaign} onValueChange={setSelectedCampaign}>
                                    <SelectTrigger>
                                      <SelectValue placeholder="选择要关联的活动" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {campaigns.filter(c => c.status === '进行中').map((campaign) => (
                                        <SelectItem key={campaign.id} value={campaign.id.toString()}>
                                          {campaign.name}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div className="flex justify-end gap-2">
                                  <Button variant="outline" onClick={() => setSelectedCampaign('')}>
                                    取消
                                  </Button>
                                  <Button onClick={handleGenerateActivityLink} disabled={!selectedCampaign}>
                                    生成链接
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                        
                        {activityLinks.length > 0 ? (
                          <div className="space-y-3">
                            {activityLinks.map((link, index) => {
                              const campaignId = link.match(/activity\/(\d+)/)?.[1];
                              const campaign = campaigns.find(c => c.id.toString() === campaignId);
                              
                              return (
                                <div key={index} className="bg-white border border-blue-200 rounded-lg p-3">
                                  <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2">
                                      <ExternalLink className="w-4 h-4 text-blue-600" />
                                      <span className="font-medium text-sm text-blue-800">
                                        {campaign?.name || '未知活动'}
                                      </span>
                                      {campaign && (
                                        <Badge variant="outline" className="text-xs text-blue-600 border-blue-300">
                                          {campaign.type}
                                        </Badge>
                                      )}
                                    </div>
                                    <div className="flex gap-1">
                                      <Button 
                                        variant="ghost" 
                                        size="sm" 
                                        onClick={() => handleCopyActivityLink(link)}
                                        className="h-8 w-8 p-0"
                                      >
                                        <Copy className="w-3 h-3" />
                                      </Button>
                                      <Button 
                                        variant="ghost" 
                                        size="sm"
                                        className="h-8 w-8 p-0"
                                      >
                                        <QrCode className="w-3 h-3" />
                                      </Button>
                                      <Button 
                                        variant="ghost" 
                                        size="sm"
                                        className="h-8 w-8 p-0"
                                      >
                                        <Share2 className="w-3 h-3" />
                                      </Button>
                                    </div>
                                  </div>
                                  <div className="bg-gray-100 rounded p-2 text-xs text-gray-600 font-mono break-all">
                                    {link}
                                  </div>
                                  <div className="flex items-center gap-4 mt-2 text-xs text-blue-600">
                                    <span>• 包含追踪参数</span>
                                    <span>• 自动统计点击</span>
                                    <span>• 支持数据分析</span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <div className="text-center py-4">
                            <Link2 className="w-8 h-8 mx-auto text-blue-400 mb-2" />
                            <p className="text-sm text-blue-600 mb-1">还没有添加活动链接</p>
                            <p className="text-xs text-blue-500">
                              添加链接可以直接引导客户参与活动，提升转化效果
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <MessageCircle className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                      <p className="text-muted-foreground mb-2">还没有生成文案</p>
                      <p className="text-sm text-muted-foreground">
                        请选择目标客户和文案类型，然后点击"生成文案"
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* 模板管理 */}
        <TabsContent value="templates" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">文案模板管理</h3>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              添加模板
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {copyTemplates.map((template) => {
              const Icon = template.icon;
              return (
                <Card key={template.id}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <Icon className="w-5 h-5" />
                        <CardTitle className="text-base">{template.name}</CardTitle>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      {template.description}
                    </p>
                    <div className="space-y-2">
                      <Label className="text-xs">提示词</Label>
                      <p className="text-xs bg-muted p-2 rounded">
                        {template.prompt}
                      </p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">标签</Label>
                      <div className="flex flex-wrap gap-1">
                        {template.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* 历史记录 */}
        <TabsContent value="history" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">文案生成历史</h3>
            <div className="flex gap-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="draft">草稿</SelectItem>
                  <SelectItem value="sent">已发送</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                导出
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            {generatedCopies.map((copy) => (
              <Card key={copy.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <div>
                        <p className="font-medium">{copy.customer}</p>
                        <p className="text-sm text-muted-foreground">{copy.type}</p>
                      </div>
                      <Badge variant={copy.status === '已发送' ? 'secondary' : 'outline'}>
                        {copy.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {copy.createdAt}
                      </span>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-3 bg-muted rounded-lg mb-3">
                    <p className="text-sm">{copy.content}</p>
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    {copy.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}