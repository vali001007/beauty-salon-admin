import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { useCampaigns } from '../App';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { 
  Home, 
  Calendar, 
  MessageCircle, 
  User,
  Bell,
  Search,
  Star,
  Clock,
  MapPin,
  Phone,
  Camera,
  Send,
  Upload,
  ShoppingBag,
  CreditCard,
  Gift,
  Settings,
  ChevronRight,
  Zap,
  Sparkles,
  Bot,
  Image as ImageIcon,
  CheckCircle,
  Wifi,
  Battery,
  Signal,
  X
} from 'lucide-react';

interface CompleteMiniprogramPreviewProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// 服务数据
const servicesData = [
  {
    id: 1,
    name: '深层清洁护理',
    category: '面部护理',
    duration: 90,
    price: 298,
    description: '深层清洁毛孔，去除黑头粉刺，改善肌肤质感',
    image: '✨',
    popular: true,
  },
  {
    id: 2,
    name: '抗衰老精华护理',
    category: '抗衰管理',
    duration: 120,
    price: 588,
    description: '使用进口精华，深层滋养，延缓肌肤衰老',
    image: '🌸',
    popular: true,
  },
  {
    id: 3,
    name: '时尚造型设计',
    category: '发型服务',
    duration: 180,
    price: 688,
    description: '个性化发型设计，包含洗剪吹造型全套服务',
    image: '💇',
    popular: false,
  },
];

// 技师数据
const staffData = [
  {
    id: 1,
    name: '张美美',
    position: '高级美容师',
    avatar: '👩‍💼',
    experience: '8年',
    specialties: ['面部护理', '抗衰管理'],
    rating: 4.9,
    available: true,
  },
  {
    id: 2,
    name: '李造型',
    position: '首席发型师',
    avatar: '👨‍🦱',
    experience: '10年',
    specialties: ['发型设计', '染烫护理'],
    rating: 4.8,
    available: true,
  },
  {
    id: 3,
    name: '王护肤',
    position: '皮肤管理师',
    avatar: '👩‍⚕️',
    experience: '6年',
    specialties: ['问题肌肤', '深层清洁'],
    rating: 4.7,
    available: true,
  },
];

// 可预约时间段
const availableTimeSlots = [
  '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '13:00', '13:30', '14:00', '14:30', '15:00', '15:30',
  '16:00', '16:30', '17:00', '17:30', '18:00', '18:30',
  '19:00', '19:30', '20:00', '20:30'
];

// 获取未来7天日期
const getNextDays = (count: number) => {
  const days = [];
  for (let i = 0; i < count; i++) {
    const date = new Date();
    date.setDate(date.getDate() + i);
    days.push({
      date: date.toISOString().split('T')[0],
      display: i === 0 ? '今天' : i === 1 ? '明天' : `${date.getMonth() + 1}月${date.getDate()}日`,
      dayOfWeek: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()]
    });
  }
  return days;
};

export function CompleteMiniprogramPreview({ open, onOpenChange }: CompleteMiniprogramPreviewProps) {
  const { publishedCampaigns } = useCampaigns();
  const [currentPage, setCurrentPage] = useState('home');
  const [chatMessages, setChatMessages] = useState<Array<{
    type: 'bot' | 'user';
    content: string;
    timestamp: string;
    image?: string;
  }>>([ 
    {
      type: 'bot',
      content: '您好！我是您的专属美容顾问，很高兴为您服务！我可以为您提供皮肤检测、护肤知识咨询和服务推荐。请问有什么可以帮助您的吗？',
      timestamp: '10:30'
    }
  ]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<any>(null);
  const [bookingForm, setBookingForm] = useState({
    serviceId: '',
    date: '',
    time: '',
    staffId: '',
    notes: ''
  });
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [reportDialogOpen, setReportDialogOpen] = useState(false);

  const getCurrentTime = () => {
    const now = new Date();
    return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
  };

  const handleBookingClick = (service: any) => {
    setSelectedService(service);
    setBookingForm({
      serviceId: service.id.toString(),
      date: '',
      time: '',
      staffId: '',
      notes: ''
    });
    setBookingDialogOpen(true);
  };

  const handleBookingSubmit = () => {
    // 这里可以处理预约提交逻辑
    console.log('预约信息:', {
      service: selectedService,
      form: bookingForm
    });
    setBookingDialogOpen(false);
    // 可以添加成功提示
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setUploadedImage(imageUrl);
        performSkinAnalysis(imageUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  const performSkinAnalysis = (imageUrl: string) => {
    setIsAnalyzing(true);
    
    // 添加上传成功消息
    const uploadMessage = {
      type: 'user',
      content: '图片上传成功，正在进行AI皮肤检测分析...',
      timestamp: getCurrentTime(),
      image: imageUrl
    };
    
    setChatMessages(prev => [...prev, uploadMessage]);

    // 模拟AI分析过程
    setTimeout(() => {
      const analysisResult = {
        type: 'bot',
        content: generateSkinAnalysisReport(),
        timestamp: getCurrentTime()
      };
      
      setChatMessages(prev => [...prev, analysisResult]);
      setIsAnalyzing(false);
    }, 3000);
  };

  const generateSkinAnalysisReport = () => {
    return `🔍 **AI皮肤检测分析报告**

**📋 检测结果概述：**
根据AI深度学习分析，您的肌肤状况评估如下：
• 肌肤类型：混合性肌肤
• 水油平衡：T区偏油，两颊偏干
• 肌肤年龄：比实际年龄年轻2-3岁
• 主要问题：毛孔粗大、轻微色素沉着
• 肌肤评分：78/100（良好）

**🛍️ 推荐护肤产品：**
1. **雅诗兰黛小棕瓶精华** - ¥980
   深层修护，改善肌肤质感
2. **海蓝之谜精华面霜** - ¥1,580  
   强效保湿，平衡水油
3. **资生堂红腰子精华** - ¥680
   提亮肤色，淡化色斑

**💆‍♀️ 推荐护理项目：**
1. **深层清洁护理** - ¥298
   专业毛孔清洁，收敛毛孔
2. **美白焕肤护理** - ¥588
   淡化色斑，提亮肤色  
3. **水光针护理** - ¥888
   深层补水，改善肌肤质感

**📊 查看完整报告：**
📋 [点击查看《专业肌肤分析完整报告》]
包含：详细数据分析、护肤建议、保养方案等

需要预约相关护理服务吗？我可以为您安排专业技师！`;
  };

  const triggerImageUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = handleImageUpload;
    input.click();
  };

  const sendMessage = () => {
    if (!currentMessage.trim()) return;
    
    const newMessage = {
      type: 'user',
      content: currentMessage,
      timestamp: getCurrentTime()
    };
    
    setChatMessages(prev => [...prev, newMessage]);
    setCurrentMessage('');
    
    // 模拟AI回复
    setTimeout(() => {
      const responses = [
        '根据您的描述，我建议您选择深层清洁护理项目，这个项目特别适合您的肌肤状况。',
        '这是一个很好的问题！对于您的肌肤类型，我推荐使用温和的氨基酸洁面产品。',
        '您可��上传一张面部照片，我将为您进行专业的肌肤分析。',
        '根据我们的专业分析，建议您每周进行2-3次深层护理。'
      ];
      
      const botResponse = {
        type: 'bot',
        content: responses[Math.floor(Math.random() * responses.length)],
        timestamp: getCurrentTime()
      };
      
      setChatMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const HomePage = () => (
    <div className="space-y-4 px-4">
      {/* 轮播图区域 */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-2">春季焕肤特惠</h3>
        <p className="text-sm opacity-90 mb-3">专业肌肤护理，重焕年轻光彩</p>
        <Button 
          size="sm" 
          className="bg-white/20 hover:bg-white/30 text-white border-white/30 rounded-full px-6"
          onClick={() => handleBookingClick(servicesData[0])}
        >
          立即预约
        </Button>
      </div>

      {/* 快捷功能 */}
      <div className="grid grid-cols-4 gap-4">
        <div className="text-center">
          <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mb-2 mx-auto">
            <Calendar className="w-7 h-7 text-blue-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">在线预约</span>
        </div>
        <div 
          className="text-center"
          onClick={() => setCurrentPage('ai')}
        >
          <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center mb-2 mx-auto">
            <Bot className="w-7 h-7 text-green-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">AI助理</span>
        </div>
        <div className="text-center">
          <div className="w-14 h-14 bg-orange-100 rounded-2xl flex items-center justify-center mb-2 mx-auto">
            <ShoppingBag className="w-7 h-7 text-orange-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">产品商城</span>
        </div>
        <div className="text-center">
          <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center mb-2 mx-auto">
            <Gift className="w-7 h-7 text-purple-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">会员专区</span>
        </div>
      </div>

      {/* AI皮肤检测卡片 */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-1">AI皮肤检测</h3>
            <p className="text-sm opacity-90">上传照片，获得专业肌肤分析报告</p>
          </div>
          <Button 
            className="bg-white/20 hover:bg-white/30 text-white border-white/30 rounded-full px-6"
            onClick={() => setCurrentPage('ai')}
          >
            上传
          </Button>
        </div>
      </div>

      {/* 营销活动 - 从营销策略同步 */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-900">热门活动</h4>
          <span className="text-sm text-gray-500">更多</span>
        </div>
        <div className="space-y-3">
          {publishedCampaigns.length > 0 ? (
            publishedCampaigns.map((campaign, index) => (
              <Card key={campaign.id} className="rounded-3xl shadow-sm overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className={`w-16 h-16 bg-gradient-to-br ${ 
                      index % 2 === 0 
                        ? 'from-pink-400 to-purple-500' 
                        : 'from-blue-400 to-cyan-500'
                    } rounded-2xl flex items-center justify-center`}>
                      {index % 2 === 0 ? (
                        <Sparkles className="w-8 h-8 text-white" />
                      ) : (
                        <Zap className="w-8 h-8 text-white" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h5 className="font-semibold text-base">{campaign.name}</h5>
                      <p className="text-sm text-gray-500 mt-1">
                        {campaign.description || `${campaign.type} - ${campaign.targetGroup}`}
                      </p>
                      <div className="flex items-center gap-3 mt-2">
                        <span className="text-lg font-bold text-red-600">
                          ¥{campaign.currentPrice || campaign.budget}
                        </span>
                        {campaign.originalPrice && (
                          <span className="text-sm text-gray-400 line-through">
                            ¥{campaign.originalPrice}
                          </span>
                        )}
                        {campaign.tag && (
                          <Badge 
                            variant={campaign.tag === '限时' ? 'destructive' : 'outline'} 
                            className="text-xs font-medium"
                          >
                            {campaign.tag}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            // 如果没有发布的活动，显示默认活动
            <>
              <Card className="rounded-3xl shadow-sm overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-pink-400 to-purple-500 rounded-2xl flex items-center justify-center">
                      <Sparkles className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <h5 className="font-semibold text-base">春季敏感肌修护套餐</h5>
                      <p className="text-sm text-gray-500 mt-1">专业敏感肌护理，温和修护</p>
                      <div className="flex items-center gap-3 mt-2">
                        <span className="text-lg font-bold text-red-600">¥298</span>
                        <span className="text-sm text-gray-400 line-through">¥398</span>
                        <Badge variant="destructive" className="text-xs font-medium">限时</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="rounded-3xl shadow-sm overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-2xl flex items-center justify-center">
                      <Zap className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <h5 className="font-semibold text-base">抗衰老精华护理</h5>
                      <p className="text-sm text-gray-500 mt-1">进口精华，深层滋养肌肤</p>
                      <div className="flex items-center gap-3 mt-2">
                        <span className="text-lg font-bold text-red-600">¥588</span>
                        <Badge variant="outline" className="text-xs font-medium">热门</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>

      {/* 热门推荐服务 */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-900">热门服务</h4>
          <span className="text-sm text-gray-500" onClick={() => setCurrentPage('booking')}>更多</span>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Card className="rounded-3xl shadow-sm overflow-hidden">
            <CardContent className="p-4">
              <div className="aspect-square bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl mb-3 flex items-center justify-center">
                <span className="text-3xl">✨</span>
              </div>
              <h5 className="font-semibold text-base">深层清洁护理</h5>
              <p className="text-sm text-gray-500 mt-1">90分钟 · ¥298</p>
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <span className="text-sm">4.9</span>
                </div>
                <span className="text-xs text-gray-500">已预约128次</span>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl shadow-sm overflow-hidden">
            <CardContent className="p-4">
              <div className="aspect-square bg-gradient-to-br from-blue-100 to-cyan-100 rounded-2xl mb-3 flex items-center justify-center">
                <span className="text-3xl">💆</span>
              </div>
              <h5 className="font-semibold text-base">时尚造型设计</h5>
              <p className="text-sm text-gray-500 mt-1">180分钟 · ¥688</p>
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <span className="text-sm">4.8</span>
                </div>
                <span className="text-xs text-gray-500">已预约86次</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 促销产品 */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-900">促销产品</h4>
          <span className="text-sm text-gray-500">更多</span>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Card className="rounded-3xl shadow-sm overflow-hidden">
            <CardContent className="p-4">
              <div className="aspect-square bg-gradient-to-br from-amber-100 to-yellow-100 rounded-2xl mb-3 flex items-center justify-center">
                <span className="text-3xl">🧴</span>
              </div>
              <h5 className="font-semibold text-base">海蓝之谜精华面霜</h5>
              <p className="text-sm text-gray-500 mt-1">50ml</p>
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-red-600">¥1580</span>
                  <span className="text-sm text-gray-400 line-through">¥1680</span>
                </div>
                <Badge variant="destructive" className="text-xs font-medium">9.4折</Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl shadow-sm overflow-hidden">
            <CardContent className="p-4">
              <div className="aspect-square bg-gradient-to-br from-rose-100 to-pink-100 rounded-2xl mb-3 flex items-center justify-center">
                <span className="text-3xl">💄</span>
              </div>
              <h5 className="font-semibold text-base">雅诗兰黛小棕瓶</h5>
              <p className="text-sm text-gray-500 mt-1">30ml</p>
              <div className="flex items-center justify-between mt-3">
                <span className="text-lg font-bold text-red-600">¥980</span>
                <Badge variant="outline" className="text-xs font-medium">热销</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 底部间距 */}
      <div className="h-4"></div>
    </div>
  );

  const BookingPage = () => (
    <div className="space-y-4 px-4">
      {/* 搜索栏 */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input placeholder="搜索服务项目" className="pl-10 rounded-2xl" />
      </div>

      {/* 服务分类 */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <Badge variant="default" className="whitespace-nowrap rounded-full px-4">全部</Badge>
        <Badge variant="outline" className="whitespace-nowrap rounded-full px-4">面部护理</Badge>
        <Badge variant="outline" className="whitespace-nowrap rounded-full px-4">抗衰管理</Badge>
        <Badge variant="outline" className="whitespace-nowrap rounded-full px-4">发型服务</Badge>
        <Badge variant="outline" className="whitespace-nowrap rounded-full px-4">身体护理</Badge>
      </div>

      {/* 服务列表 */}
      <div className="space-y-4">
        {servicesData.map((service, index) => (
          <Card key={service.id} className="rounded-3xl shadow-sm overflow-hidden">
            <CardContent className="p-4">
              <div className="flex gap-4">
                <div className="w-24 h-24 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl flex items-center justify-center">
                  <span className="text-3xl">{service.image}</span>
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-semibold text-base">{service.name}</h5>
                    {service.popular && (
                      <Badge variant="outline" className="text-xs font-medium rounded-full">热门</Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-500 mb-3">{service.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm">
                      <span className="flex items-center gap-1 text-gray-500">
                        <Clock className="w-4 h-4" />
                        {service.duration}分钟
                      </span>
                      <span className="text-lg font-bold text-red-600">¥{service.price}</span>
                    </div>
                    <Button 
                      size="sm" 
                      className="rounded-full px-6"
                      onClick={() => handleBookingClick(service)}
                    >
                      立即预约
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 技师选择提示 */}
      <Card className="bg-blue-50 border-blue-200 rounded-3xl">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-2xl flex items-center justify-center">
              <User className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="font-semibold text-blue-800">专业技师服务</p>
              <p className="text-sm text-blue-600">可选择指定技师，享受专业个性化服务</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 底部间距 */}
      <div className="h-4"></div>
    </div>
  );

  const AIAssistantPage = () => (
    <div className="flex flex-col h-full px-4">
      {/* AI助理功能菜单 */}
      <div className="space-y-4 mb-4">
        <div className="grid grid-cols-3 gap-3">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex flex-col items-center gap-2 h-auto py-4 rounded-2xl"
            onClick={triggerImageUpload}
            disabled={isAnalyzing}
          >
            <Camera className="w-5 h-5" />
            <span className="text-sm">皮肤检测</span>
          </Button>
          <Button variant="outline" size="sm" className="flex flex-col items-center gap-2 h-auto py-4 rounded-2xl">
            <Sparkles className="w-5 h-5" />
            <span className="text-sm">护肤知识</span>
          </Button>
          <Button variant="outline" size="sm" className="flex flex-col items-center gap-2 h-auto py-4 rounded-2xl">
            <MessageCircle className="w-5 h-5" />
            <span className="text-sm">服务咨询</span>
          </Button>
        </div>
        
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200 rounded-3xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-2xl flex items-center justify-center">
                <ImageIcon className="w-5 h-5 text-purple-600" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-purple-800">AI皮肤检测</p>
                <p className="text-sm text-purple-600">上传照片，获得专业肌肤分析报告</p>
              </div>
              <Button 
                size="sm" 
                className="rounded-full px-6"
                onClick={triggerImageUpload}
                disabled={isAnalyzing}
              >
                <Upload className="w-4 h-4 mr-1" />
                {isAnalyzing ? '分析中...' : '上传'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 聊天区域 */}
      <div className="flex-1 bg-gray-50 rounded-3xl p-4 mb-4">
        <ScrollArea className="h-full">
          <div className="space-y-3">
            {chatMessages.map((message, index) => (
              <div key={index} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex gap-3 max-w-[85%] ${message.type === 'user' ? 'flex-row-reverse' : ''}`}>
                  <Avatar className="w-8 h-8">
                    {message.type === 'bot' ? (
                      <div className="w-full h-full bg-purple-100 rounded-full flex items-center justify-center">
                        <Bot className="w-4 h-4 text-purple-600" />
                      </div>
                    ) : (
                      <AvatarFallback className="text-sm">我</AvatarFallback>
                    )}
                  </Avatar>
                  <div className={`rounded-2xl p-3 ${
                    message.type === 'user' 
                      ? 'bg-purple-600 text-white' 
                      : 'bg-white border shadow-sm'
                  }`}>
                    {(message as any).image && (
                      <div className="mb-2">
                        <img 
                          src={(message as any).image} 
                          alt="上传的皮肤照片" 
                          className="w-full max-w-[140px] h-auto rounded-xl border"
                        />
                      </div>
                    )}
                    <div className="text-sm whitespace-pre-line">
                      {message.content.includes('[点击查看《专业肌肤分析完整报告》]') ? (
                        <div>
                          {message.content.split('[点击查看《专业肌肤分析完整报告》]').map((part, i) => (
                            <span key={i}>
                              {part}
                              {i === 0 && (
                                <button
                                  onClick={() => setReportDialogOpen(true)}
                                  className="inline-block bg-purple-100 text-purple-600 px-3 py-1 rounded-full text-sm hover:bg-purple-200 transition-colors mt-2"
                                >
                                  点击查看《专业肌肤分析完整报告》
                                </button>
                              )}
                            </span>
                          ))}
                        </div>
                      ) : (
                        message.content
                      )}
                    </div>
                    <p className={`text-xs mt-2 ${
                      message.type === 'user' ? 'text-purple-200' : 'text-gray-400'
                    }`}>
                      {message.timestamp}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {isAnalyzing && (
              <div className="flex justify-start">
                <div className="flex gap-3 max-w-[85%]">
                  <Avatar className="w-8 h-8">
                    <div className="w-full h-full bg-purple-100 rounded-full flex items-center justify-center">
                      <Bot className="w-4 h-4 text-purple-600" />
                    </div>
                  </Avatar>
                  <div className="rounded-2xl p-3 bg-white border shadow-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
                      <span className="text-sm">AI正在分析您的肌肤...</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* 输入框 */}
      <div className="flex gap-3">
        <Input 
          placeholder="请输入您的问题..." 
          value={currentMessage}
          onChange={(e) => setCurrentMessage(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
          className="rounded-2xl"
        />
        <Button size="sm" onClick={sendMessage} className="rounded-2xl px-4">
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );

  const ProfilePage = () => (
    <div className="space-y-4 px-4">
      {/* 用户信息 */}
      <Card className="rounded-3xl shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Avatar className="w-20 h-20">
              <AvatarImage src="/avatar-user.jpg" alt="用户头像" />
              <AvatarFallback className="text-lg">李小美</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h4 className="text-lg font-semibold">李小美</h4>
              <p className="text-base text-gray-500">VIP会员</p>
              <div className="flex items-center gap-6 mt-3">
                <div className="text-center">
                  <p className="text-lg font-bold text-purple-600">1280</p>
                  <p className="text-sm text-gray-500">积分</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold text-orange-600">¥2680</p>
                  <p className="text-sm text-gray-500">余额</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold text-green-600">85%</p>
                  <p className="text-sm text-gray-500">折扣</p>
                </div>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </div>
        </CardContent>
      </Card>

      {/* 快捷功能 */}
      <div className="grid grid-cols-4 gap-4">
        <div className="text-center">
          <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mb-2 mx-auto">
            <Calendar className="w-7 h-7 text-blue-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">我的预约</span>
        </div>
        <div className="text-center">
          <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center mb-2 mx-auto">
            <CreditCard className="w-7 h-7 text-green-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">充值</span>
        </div>
        <div className="text-center">
          <div className="w-14 h-14 bg-orange-100 rounded-2xl flex items-center justify-center mb-2 mx-auto">
            <Gift className="w-7 h-7 text-orange-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">我的优惠</span>
        </div>
        <div className="text-center">
          <div className="w-14 h-14 bg-gray-100 rounded-2xl flex items-center justify-center mb-2 mx-auto">
            <Settings className="w-7 h-7 text-gray-600" />
          </div>
          <span className="text-sm font-medium text-gray-700">设置</span>
        </div>
      </div>

      {/* 最近预约 */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-900">最近预约</h4>
          <span className="text-sm text-gray-500">查看全部</span>
        </div>
        <Card className="rounded-3xl shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl flex items-center justify-center">
                <span className="text-2xl">✨</span>
              </div>
              <div className="flex-1">
                <h5 className="font-semibold text-base">深层清洁护理</h5>
                <p className="text-sm text-gray-500 mt-1">张美美 · 高级美容师</p>
                <p className="text-sm text-gray-500">2024年1月20日 14:00</p>
              </div>
              <Badge variant="outline" className="rounded-full">已完成</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 会员特权 */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-900">会员特权</h4>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Card className="rounded-3xl shadow-sm bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
                <Star className="w-6 h-6 text-purple-600" />
              </div>
              <h5 className="font-semibold text-purple-800">VIP专享</h5>
              <p className="text-sm text-purple-600 mt-1">专属技师服务</p>
            </CardContent>
          </Card>
          <Card className="rounded-3xl shadow-sm bg-gradient-to-br from-orange-50 to-yellow-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
                <Gift className="w-6 h-6 text-orange-600" />
              </div>
              <h5 className="font-semibold text-orange-800">积分兑换</h5>
              <p className="text-sm text-orange-600 mt-1">积分换好礼</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 底部间距 */}
      <div className="h-4"></div>
    </div>
  );

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'booking':
        return <BookingPage />;
      case 'ai':
        return <AIAssistantPage />;
      case 'profile':
        return <ProfilePage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="max-w-none p-0 bg-transparent border-none shadow-none"
        aria-describedby="store-miniprogram-preview-description"
      >
        <DialogHeader className="sr-only">
          <DialogTitle>网店小程序预览</DialogTitle>
          <DialogDescription id="store-miniprogram-preview-description">
            预览美容院网店小程序的完整界面和功能
          </DialogDescription>
        </DialogHeader>
        
        {/* iPhone 16 尺寸容器 - 比例约为 9:19.5 */}
        <div className="relative mx-auto bg-black rounded-[2.5rem] p-2 shadow-2xl" style={{ width: '375px', height: '812px' }}>
          {/* 手机外壳装饰 */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-32 h-6 bg-black rounded-b-2xl"></div>
          
          {/* 手机屏幕 */}
          <div className="w-full h-full bg-white rounded-[2rem] overflow-hidden flex flex-col">
            {/* 状态栏 */}
            <div className="bg-black text-white px-6 py-2 flex justify-between items-center text-sm font-medium">
              <div className="flex items-center gap-1">
                <Signal className="w-4 h-4" />
                <Wifi className="w-4 h-4" />
              </div>
              <div className="text-center flex-1 font-semibold">{getCurrentTime()}</div>
              <div className="flex items-center gap-1">
                <span>100%</span>
                <Battery className="w-4 h-4 fill-white" />
              </div>
            </div>

            {/* 小程序导航栏 */}
            <div className="bg-white border-b px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-lg">✨</span>
                </div>
                <div>
                  <h3 className="text-base font-medium text-gray-900">雅敏美容沙龙</h3>
                  <p className="text-sm text-gray-500">专业美容护肤</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 rounded-full"
                  onClick={() => onOpenChange(false)}
                  aria-label="关闭预览"
                >
                  <X className="w-4 h-4 text-gray-400" />
                </Button>
              </div>
            </div>

            {/* 小程序内容区域 - 可滚动 */}
            <div className="flex-1 bg-gray-50 overflow-y-auto">
              {renderCurrentPage()}
            </div>

            {/* 小程序底部导航栏 */}
            <div className="bg-white border-t border-gray-100 safe-area-bottom">
              <div className="grid grid-cols-4 py-1">
                <button 
                  className={`text-center py-2 ${currentPage === 'home' ? 'text-purple-600' : 'text-gray-500'}`}
                  onClick={() => setCurrentPage('home')}
                >
                  <Home className={`w-5 h-5 mx-auto mb-1 ${currentPage === 'home' ? 'text-purple-600' : 'text-gray-400'}`} />
                  <span className="text-xs font-medium">首页</span>
                </button>
                <button 
                  className={`text-center py-2 ${currentPage === 'booking' ? 'text-purple-600' : 'text-gray-500'}`}
                  onClick={() => setCurrentPage('booking')}
                >
                  <Calendar className={`w-5 h-5 mx-auto mb-1 ${currentPage === 'booking' ? 'text-purple-600' : 'text-gray-400'}`} />
                  <span className="text-xs font-medium">预约</span>
                </button>
                <button 
                  className={`text-center py-2 ${currentPage === 'ai' ? 'text-purple-600' : 'text-gray-500'}`}
                  onClick={() => setCurrentPage('ai')}
                >
                  <Bot className={`w-5 h-5 mx-auto mb-1 ${currentPage === 'ai' ? 'text-purple-600' : 'text-gray-400'}`} />
                  <span className="text-xs font-medium">AI助理</span>
                </button>
                <button 
                  className={`text-center py-2 ${currentPage === 'profile' ? 'text-purple-600' : 'text-gray-500'}`}
                  onClick={() => setCurrentPage('profile')}
                >
                  <User className={`w-5 h-5 mx-auto mb-1 ${currentPage === 'profile' ? 'text-purple-600' : 'text-gray-400'}`} />
                  <span className="text-xs font-medium">我的</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 预约对话框 */}
        <Dialog open={bookingDialogOpen} onOpenChange={setBookingDialogOpen}>
          <DialogContent 
            className="max-w-md"
            aria-describedby="booking-service-description"
          >
            <DialogHeader>
              <DialogTitle>预约服务</DialogTitle>
              <DialogDescription id="booking-service-description">
                请选择预约时间和技师
              </DialogDescription>
            </DialogHeader>
            {selectedService && (
              <div className="space-y-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <h4 className="font-medium">{selectedService.name}</h4>
                  <p className="text-sm text-gray-500 mt-1">{selectedService.description}</p>
                  <div className="flex items-center gap-4 mt-2 text-sm">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {selectedService.duration}分钟
                    </span>
                    <span className="font-medium text-red-600">¥{selectedService.price}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>选择日期</Label>
                  <Select value={bookingForm.date} onValueChange={(value) => setBookingForm({...bookingForm, date: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="请选择预约日期" />
                    </SelectTrigger>
                    <SelectContent>
                      {getNextDays(7).map((day) => (
                        <SelectItem key={day.date} value={day.date}>
                          {day.display} {day.dayOfWeek}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>选择时间</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {availableTimeSlots.map((time) => (
                      <button
                        key={time}
                        className={`p-2 text-sm border rounded ${
                          bookingForm.time === time 
                            ? 'border-purple-600 bg-purple-50 text-purple-600' 
                            : 'border-gray-200 hover:border-purple-300'
                        }`}
                        onClick={() => setBookingForm({...bookingForm, time})}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>选择技师</Label>
                  <Select value={bookingForm.staffId} onValueChange={(value) => setBookingForm({...bookingForm, staffId: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="请选择技师" />
                    </SelectTrigger>
                    <SelectContent>
                      {staffData.map((staff) => (
                        <SelectItem key={staff.id} value={staff.id.toString()}>
                          <div className="flex items-center gap-2">
                            <span>{staff.avatar}</span>
                            <div>
                              <span>{staff.name}</span>
                              <span className="text-sm text-gray-500 ml-2">{staff.position}</span>
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>备注</Label>
                  <Textarea 
                    placeholder="请输入特殊要求或备注信息" 
                    value={bookingForm.notes}
                    onChange={(e) => setBookingForm({...bookingForm, notes: e.target.value})}
                  />
                </div>

                <div className="flex gap-2 pt-4">
                  <Button variant="outline" onClick={() => setBookingDialogOpen(false)} className="flex-1">
                    取消
                  </Button>
                  <Button onClick={handleBookingSubmit} className="flex-1">
                    确认预约
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* 皮肤分析报告对话框 */}
        <Dialog open={reportDialogOpen} onOpenChange={setReportDialogOpen}>
          <DialogContent 
            className="max-w-md max-h-[80vh] overflow-y-auto"
            aria-describedby="skin-analysis-report-description"
          >
            <DialogHeader>
              <DialogTitle>专业肌肤分析完整报告</DialogTitle>
              <DialogDescription id="skin-analysis-report-description">
                基于AI深度学习算法的专业肌肤分析
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {/* 肌肤评分 */}
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600 mb-1">78分</div>
                    <p className="text-sm text-gray-600">肌肤综合评分</p>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{width: '78%'}}></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 详细分析 */}
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-sm">肌肤类型</span>
                  <span className="text-sm font-medium">混合性肌肤</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-sm">水油平衡</span>
                  <span className="text-sm font-medium text-orange-600">T区偏油，两颊偏干</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-sm">肌肤年龄</span>
                  <span className="text-sm font-medium text-green-600">比实际年龄年轻2-3岁</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-sm">主要问题</span>
                  <span className="text-sm font-medium text-red-600">毛孔粗大、色素沉着</span>
                </div>
              </div>

              {/* 推荐方案 */}
              <div>
                <h4 className="font-medium mb-3">推荐护理方案</h4>
                <div className="space-y-2">
                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="text-sm font-medium">深层清洁护理</h5>
                        <p className="text-xs text-gray-500 mt-1">专业毛孔清洁，收敛毛孔</p>
                      </div>
                      <span className="text-sm font-bold text-red-600">¥298</span>
                    </div>
                  </div>
                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="text-sm font-medium">美白焕肤护理</h5>
                        <p className="text-xs text-gray-500 mt-1">淡化色斑，提亮肤色</p>
                      </div>
                      <span className="text-sm font-bold text-red-600">¥588</span>
                    </div>
                  </div>
                </div>
              </div>

              <Button className="w-full" onClick={() => setReportDialogOpen(false)}>
                关闭报告
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}