import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { useCampaigns, type TencentAdConfig } from '../App';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from './ui/dialog';
import { Switch } from './ui/switch';
import { Checkbox } from './ui/checkbox';
import { Slider } from './ui/slider';
import { MiniProgramPreview } from './MiniProgramPreview';
import { 
  Plus, 
  Target, 
  Users, 
  DollarSign, 
  Calendar,
  Play,
  Pause,
  Edit,
  Trash2,
  Eye,
  BarChart3,
  Smartphone,
  Send,
  Settings,
  Image,
  Clock,
  Share2,
  Bell,
  Sparkles,
  TrendingUp,
  Star,
  Zap,
  Brain,
  CheckCircle,
  MapPin,
  MousePointer,
  CreditCard,
  Megaphone,
  Video,
  MessageCircle,
  Radio,
  Globe,
  Heart,
  ShoppingBag,
  Coffee,
  Dumbbell,
  Music,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

const strategyTemplates = [
  {
    name: '新客获取',
    description: '通过优惠活动吸引新客户首次体验',
    targetGroup: '潜在客户',
    expectedROI: '150%',
    duration: '1-2个月',
  },
  {
    name: '客户留存',
    description: '针对现有客户的忠诚度提升策略',
    targetGroup: '稳定客户',
    expectedROI: '200%',
    duration: '持续执行',
  },
  {
    name: '价值提升',
    description: '引导客户尝试更高价值的服务项目',
    targetGroup: '中等消费客户',
    expectedROI: '180%',
    duration: '2-3个月',
  },
  {
    name: '流失挽回',
    description: '重新激活长期未到店的客户',
    targetGroup: '流失风险客户',
    expectedROI: '120%',
    duration: '1个月',
  },
];

// 智能推荐活动数据
const recommendedCampaigns = [
  {
    id: 'rec-1',
    name: '春季敏感肌修护套餐',
    type: '个性化推荐',
    description: '针对您店内35%的敏感肌客户群体，推出温和修护专项服务',
    targetGroup: '敏感肌客户',
    reasonTitle: '推荐理由',
    reasons: [
      '店内有42%客户为敏感性肌肤',
      '春季是敏感肌问题高发期',
      '该客群平均消费额高于店内均值20%'
    ],
    expectedResults: {
      targetCustomers: 128,
      expectedConversion: '28%',
      projectedRevenue: '¥85,600',
      roi: '245%'
    },
    confidence: 92,
    urgency: '高',
    tags: ['AI推荐', '季节性', '高ROI'],
    aiInsights: '基于客户画像分析，敏感肌客群在春季的服务需求增长38%，建议立即启动',
  },
  {
    id: 'rec-2', 
    name: '高端客户专享抗衰项目',
    type: '价值提升推荐',
    description: '为您的VIP客户群体定制的高端抗衰老护理套餐',
    targetGroup: 'VIP客户',
    reasonTitle: '数据驱动推荐',
    reasons: [
      '15位VIP客户询问过抗衰服务',
      '该客群消费能力强，接受度高',
      '竞对已推出类似服务，存在流失风险'
    ],
    expectedResults: {
      targetCustomers: 45,
      expectedConversion: '65%',
      projectedRevenue: '¥156,000',
      roi: '380%'
    },
    confidence: 88,
    urgency: '中',
    tags: ['VIP专享', '抗衰老', '竞争优势'],
    aiInsights: 'VIP客户群体对新项目接受度高，建议结合会员积分体系推出',
  },
  {
    id: 'rec-3',
    name: '学生党美肌入门体验',
    type: '新客获取推荐', 
    description: '针对周边高校学生群体的入门级护肤体验活动',
    targetGroup: '学生群体',
    reasonTitle: '市场机会分析',
    reasons: [
      '周边3所高校，潜在客户5000+',
      '学生群体消费习惯正在养成',
      '口碑传播效应强，获客成本低'
    ],
    expectedResults: {
      targetCustomers: 200,
      expectedConversion: '15%',
      projectedRevenue: '¥24,000',
      roi: '160%'
    },
    confidence: 75,
    urgency: '中',
    tags: ['新客获取', '学生市场', '口碑营销'],
    aiInsights: '建议结合社交媒体推广，利用学生群体的社交网络实现裂变传播',
  }
];

// 腾讯广告渠道配置
const tencentAdChannels = [
  {
    id: 'moments',
    name: '朋友圈广告',
    icon: Heart,
    description: '在用户朋友圈信息流中展示',
    minBudget: 500,
    avgCpm: 15,
    features: ['图片/视频', '原生体验', '高转化']
  },
  {
    id: 'video',
    name: '视频号广告',
    icon: Video,
    description: '在微信视频号信息流中投放',
    minBudget: 300,
    avgCpm: 12,
    features: ['短视频', '全屏展示', '强互动']
  },
  {
    id: 'wechat',
    name: '公众号广告',
    icon: MessageCircle,
    description: '在公众号文章中插入广告',
    minBudget: 200,
    avgCpm: 8,
    features: ['图文混排', '精准定向', '阅读转化']
  },
  {
    id: 'miniprogram',
    name: '小程序广告',
    icon: Smartphone,
    description: '在小程序应用内投放',
    minBudget: 300,
    avgCpm: 10,
    features: ['原生广告', '场景融入', '直接转化']
  },
  {
    id: 'search',
    name: '搜索广告',
    icon: Globe,
    description: '微信搜索结果页广告',
    minBudget: 400,
    avgCpm: 18,
    features: ['关键词触发', '意图明确', '高转化率']
  }
];

// 用户兴趣标签
const interestTags = [
  { id: 'beauty', name: '美容护肤', icon: Sparkles },
  { id: 'fashion', name: '时尚生活', icon: Heart },
  { id: 'health', name: '健康养生', icon: Dumbbell },
  { id: 'shopping', name: '购物消费', icon: ShoppingBag },
  { id: 'food', name: '美食餐饮', icon: Coffee },
  { id: 'travel', name: '旅游出行', icon: MapPin },
  { id: 'entertainment', name: '娱乐休闲', icon: Music },
  { id: 'education', name: '教育培训', icon: Target }
];

export function MarketingStrategy() {
  const { campaigns, publishedCampaigns, addCampaign, updateCampaign, publishToMiniProgram, publishToTencentAd } = useCampaigns();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [adPromotionOpen, setAdPromotionOpen] = useState(false);
  const [selectedCampaignId, setSelectedCampaignId] = useState<number | string | null>(null);
  const [enableSchedule, setEnableSchedule] = useState(false);
  const [enableNotification, setEnableNotification] = useState(true);
  const [selectedChannels, setSelectedChannels] = useState<string[]>(['miniprogram']);
  const [selectedRecommendation, setSelectedRecommendation] = useState<string | null>(null);
  const [miniProgramPreviewOpen, setMiniProgramPreviewOpen] = useState(false);
  const [aiRecommendationOpen, setAiRecommendationOpen] = useState(false);
  const [templateLibraryOpen, setTemplateLibraryOpen] = useState(false);
  
  // 表单状态
  const [formData, setFormData] = useState({
    name: '',
    type: '',
    targetGroup: '',
    budget: '',
    startDate: '',
    endDate: '',
    description: '',
    currentPrice: '',
    originalPrice: '',
    tag: ''
  });

  // 腾讯广告表单状态
  const [tencentAdData, setTencentAdData] = useState<Partial<TencentAdConfig>>({
    enabled: false,
    targetAudience: [],
    radiusKm: 5,
    channels: ['moments'],
    budget: 1000,
    bidStrategy: 'CPC',
    ageRange: { min: 18, max: 65 },
    gender: '不限',
    interests: ['beauty'],
    schedule: {
      startTime: '09:00',
      endTime: '22:00',
      days: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    }
  });

  const handleChannelToggle = (channel: string) => {
    setSelectedChannels(prev => 
      prev.includes(channel) 
        ? prev.filter(c => c !== channel)
        : [...prev, channel]
    );
  };

  const handleTencentAdChannelToggle = (channelId: string) => {
    setTencentAdData(prev => ({
      ...prev,
      channels: prev.channels?.includes(channelId) 
        ? prev.channels.filter(c => c !== channelId)
        : [...(prev.channels || []), channelId]
    }));
  };

  const handleInterestToggle = (interestId: string) => {
    setTencentAdData(prev => ({
      ...prev,
      interests: prev.interests?.includes(interestId) 
        ? prev.interests.filter(i => i !== interestId)
        : [...(prev.interests || []), interestId]
    }));
  };

  const calculateAdCost = () => {
    const selectedChannelConfigs = tencentAdChannels.filter(ch => 
      tencentAdData.channels?.includes(ch.id)
    );
    
    // Always return an object with consistent structure
    if (selectedChannelConfigs.length === 0 || !tencentAdData.budget) {
      return {
        estimatedImpressions: 0,
        estimatedClicks: 0,
        avgCpm: 0
      };
    }
    
    const avgCpm = selectedChannelConfigs.reduce((sum, ch) => sum + ch.avgCpm, 0) / selectedChannelConfigs.length;
    const estimatedImpressions = (tencentAdData.budget || 0) / avgCpm * 1000;
    
    return {
      estimatedImpressions: Math.round(estimatedImpressions),
      estimatedClicks: Math.round(estimatedImpressions * 0.02),
      avgCpm: parseFloat(avgCpm.toFixed(2))
    };
  };

  const handleCreateCampaign = () => {
    if (!formData.name || !formData.type) return;
    
    const newCampaign = {
      id: Date.now(),
      name: formData.name,
      type: formData.type,
      status: '进行中',
      targetGroup: formData.targetGroup,
      startDate: formData.startDate,
      endDate: formData.endDate,
      budget: parseInt(formData.budget) || 0,
      spent: 0,
      reach: 0,
      conversion: 0,
      revenue: 0,
      publishedToMiniProgram: selectedChannels.includes('miniprogram'),
      description: formData.description,
      currentPrice: parseInt(formData.currentPrice) || undefined,
      originalPrice: parseInt(formData.originalPrice) || undefined,
      tag: formData.tag
    };
    
    addCampaign(newCampaign);
    setDialogOpen(false);
    
    // 重置表单
    setFormData({
      name: '',
      type: '',
      targetGroup: '',
      budget: '',
      startDate: '',
      endDate: '',
      description: '',
      currentPrice: '',
      originalPrice: '',
      tag: ''
    });
  };

  const handlePromotionClick = (campaignId: number | string) => {
    setSelectedCampaignId(campaignId);
    const campaign = campaigns.find(c => c.id === campaignId);
    if (campaign?.tencentAd) {
      setTencentAdData(campaign.tencentAd);
    } else {
      // 重置为默认值
      setTencentAdData({
        enabled: false,
        targetAudience: [],
        radiusKm: 5,
        channels: ['moments'],
        budget: 1000,
        bidStrategy: 'CPC',
        ageRange: { min: 18, max: 65 },
        gender: '不限',
        interests: ['beauty'],
        schedule: {
          startTime: '09:00',
          endTime: '22:00',
          days: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
        }
      });
    }
    setAdPromotionOpen(true);
  };

  const handleSaveTencentAd = () => {
    if (selectedCampaignId && tencentAdData.enabled) {
      const adConfig: TencentAdConfig = {
        ...tencentAdData,
        enabled: true,
        status: 'pending',
        spend: tencentAdData.spend || 0,
        impressions: tencentAdData.impressions || 0,
        clicks: tencentAdData.clicks || 0,
        ctr: tencentAdData.ctr || 0
      } as TencentAdConfig;
      
      publishToTencentAd(selectedCampaignId, adConfig);
    }
    setAdPromotionOpen(false);
    setSelectedCampaignId(null);
  };

  const handlePublishRecommendation = (recommendationId: string) => {
    const recommendation = recommendedCampaigns.find(r => r.id === recommendationId);
    if (recommendation) {
      setFormData({
        name: recommendation.name,
        type: recommendation.type,
        targetGroup: recommendation.targetGroup,
        budget: recommendation.expectedResults.projectedRevenue.replace('¥', '').replace(',', ''),
        startDate: '',
        endDate: '',
        description: recommendation.description,
        currentPrice: '',
        originalPrice: '',
        tag: recommendation.tags[0] || ''
      });
      setDialogOpen(true);
    }
  };

  const handleViewRecommendationDetails = (recommendationId: string) => {
    setSelectedRecommendation(recommendationId);
  };

  // 获取当前选中的活动
  const selectedCampaign = campaigns.find(c => c.id === selectedCampaignId);

  const CreateCampaignForm = () => (
    <Tabs defaultValue="basic" className="space-y-4">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="basic">基础信息</TabsTrigger>
        <TabsTrigger value="publish">发布设置</TabsTrigger>
        <TabsTrigger value="advanced">高级选项</TabsTrigger>
      </TabsList>

      <TabsContent value="basic" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="campaign-name">活动名称</Label>
            <Input 
              id="campaign-name" 
              placeholder="请输入活动名称"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="campaign-type">活动类型</Label>
            <Select 
              value={formData.type}
              onValueChange={(value) => setFormData({...formData, type: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="选择活动类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="促销活动">促销活动</SelectItem>
                <SelectItem value="获客活动">获客活动</SelectItem>
                <SelectItem value="留存活动">留存活动</SelectItem>
                <SelectItem value="挽回活动">挽回活动</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="target-group">目标群体</Label>
            <Select 
              value={formData.targetGroup}
              onValueChange={(value) => setFormData({...formData, targetGroup: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="选择目标群体" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="高价值客户">高价值客户</SelectItem>
                <SelectItem value="潜在客户">潜在客户</SelectItem>
                <SelectItem value="稳定客户">稳定客户</SelectItem>
                <SelectItem value="流失风险客户">流失风险客户</SelectItem>
                <SelectItem value="新客户">新客户</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="budget">预算金额</Label>
            <Input 
              id="budget" 
              type="number" 
              placeholder="请输入预算金额"
              value={formData.budget}
              onChange={(e) => setFormData({...formData, budget: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="start-date">开始日期</Label>
            <Input 
              id="start-date" 
              type="date"
              value={formData.startDate}
              onChange={(e) => setFormData({...formData, startDate: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="end-date">结束日期</Label>
            <Input 
              id="end-date" 
              type="date"
              value={formData.endDate}
              onChange={(e) => setFormData({...formData, endDate: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="current-price">活动价格</Label>
            <Input 
              id="current-price" 
              type="number" 
              placeholder="请输入活动价格"
              value={formData.currentPrice}
              onChange={(e) => setFormData({...formData, currentPrice: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="original-price">原价(可选)</Label>
            <Input 
              id="original-price" 
              type="number" 
              placeholder="请输入原价"
              value={formData.originalPrice}
              onChange={(e) => setFormData({...formData, originalPrice: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="tag">活动标签</Label>
            <Select 
              value={formData.tag}
              onValueChange={(value) => setFormData({...formData, tag: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="选择活动标签" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="限时">限时</SelectItem>
                <SelectItem value="热门">热门</SelectItem>
                <SelectItem value="新品">新品</SelectItem>
                <SelectItem value="特惠">特惠</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2 space-y-2">
            <Label htmlFor="description">活动描述</Label>
            <Textarea 
              id="description" 
              placeholder="请输入活动描述和具体内容" 
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>
        </div>
      </TabsContent>

      <TabsContent value="publish" className="space-y-6">
        <div className="space-y-4">
          <Label className="flex items-center gap-2">
            <Share2 className="w-4 h-4" />
            发布渠道
          </Label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center space-x-3 p-3 border rounded-lg">
              <Checkbox 
                checked={selectedChannels.includes('miniprogram')}
                onCheckedChange={() => handleChannelToggle('miniprogram')}
              />
              <Smartphone className="w-5 h-5 text-blue-600" />
              <div className="flex-1">
                <p className="font-medium">微信小程序</p>
                <p className="text-sm text-muted-foreground">在小程序首页展示活动</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 border rounded-lg">
              <Checkbox 
                checked={selectedChannels.includes('wechat')}
                onCheckedChange={() => handleChannelToggle('wechat')}
              />
              <Send className="w-5 h-5 text-green-600" />
              <div className="flex-1">
                <p className="font-medium">微信推送</p>
                <p className="text-sm text-muted-foreground">发送活动消息给客户</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 border rounded-lg">
              <Checkbox 
                checked={selectedChannels.includes('sms')}
                onCheckedChange={() => handleChannelToggle('sms')}
              />
              <Bell className="w-5 h-5 text-orange-600" />
              <div className="flex-1">
                <p className="font-medium">短信通知</p>
                <p className="text-sm text-muted-foreground">发送短信提醒客户</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 border rounded-lg">
              <Checkbox 
                checked={selectedChannels.includes('store')}
                onCheckedChange={() => handleChannelToggle('store')}
              />
              <Target className="w-5 h-5 text-purple-600" />
              <div className="flex-1">
                <p className="font-medium">门店展示</p>
                <p className="text-sm text-muted-foreground">在门店内展示活动信息</p>
              </div>
            </div>
          </div>
        </div>

        {selectedChannels.includes('miniprogram') && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                小程序发布设置
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>活动封面图</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Image className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-600">点击上传活动封面图</p>
                    <p className="text-xs text-gray-400">建议尺寸：750x400px</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>显示位置</Label>
                    <Select defaultValue="banner">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="banner">首页轮播图</SelectItem>
                        <SelectItem value="card">活动专区</SelectItem>
                        <SelectItem value="popup">弹窗推广</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>优先级</Label>
                    <Select defaultValue="normal">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">高优先级</SelectItem>
                        <SelectItem value="normal">普通</SelectItem>
                        <SelectItem value="low">低优先级</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </TabsContent>

      <TabsContent value="advanced" className="space-y-6">
        {/* 定时发布 */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <Label>定时发布</Label>
            </div>
            <Switch 
              checked={enableSchedule} 
              onCheckedChange={setEnableSchedule}
            />
          </div>
          
          {enableSchedule && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
              <div className="space-y-2">
                <Label>发布日期</Label>
                <Input type="date" />
              </div>
              <div className="space-y-2">
                <Label>发布时间</Label>
                <Input type="time" defaultValue="09:00" />
              </div>
            </div>
          )}
        </div>

        {/* 自动通知设置 */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4" />
              <Label>自动通知客户</Label>
            </div>
            <Switch 
              checked={enableNotification} 
              onCheckedChange={setEnableNotification}
            />
          </div>
          
          {enableNotification && (
            <div className="space-y-4 p-4 bg-muted rounded-lg">
              <div className="space-y-2">
                <Label>通知时间设置</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox defaultChecked />
                    <span className="text-sm">活动开始时立即通知</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox />
                    <span className="text-sm">活动开始前1天提醒</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox />
                    <span className="text-sm">活动结束前3天提醒</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>通知内容模板</Label>
                <Textarea 
                  placeholder="亲爱的客户，您关注的活动即将开始..."
                  rows={3}
                />
              </div>
            </div>
          )}
        </div>

        {/* 数据追踪设置 */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            <Label>数据追踪设置</Label>
          </div>
          
          <div className="space-y-2 p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-2">
              <Checkbox defaultChecked />
              <span className="text-sm">追踪点击量</span>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox defaultChecked />
              <span className="text-sm">追踪转化率</span>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox defaultChecked />
              <span className="text-sm">追踪客户来源</span>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox />
              <span className="text-sm">启用A/B测试</span>
            </div>
          </div>
        </div>
      </TabsContent>

      <div className="flex justify-end gap-2 mt-6">
        <Button variant="outline" onClick={() => setDialogOpen(false)}>
          取消
        </Button>
        <Button variant="outline">
          保存草稿
        </Button>
        <Button onClick={handleCreateCampaign}>
          {selectedChannels.includes('miniprogram') 
            ? '创建并发布到小程序' 
            : '创建活动'
          }
        </Button>
      </div>
    </Tabs>
  );

  // 腾讯广告投放设置对话框
  const TencentAdPromotionDialog = () => {
    const adCostData = calculateAdCost();
    
    return (
      <Dialog open={adPromotionOpen} onOpenChange={setAdPromotionOpen}>
        <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-red-600" />
              腾讯广告投放设置 - {selectedCampaign?.name}
            </DialogTitle>
            <DialogDescription>
              配置腾讯广告投放参数，包括目标受众、投放渠道、预算设置等，精准推广您的营销活动
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* 投放开关 */}
            <div className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-3">
                <Megaphone className="w-6 h-6 text-red-600" />
                <div>
                  <h3 className="font-medium text-red-900">启用腾讯广告投放</h3>
                  <p className="text-sm text-red-700">通过腾讯广告平台精准推广您的活动</p>
                </div>
              </div>
              <Switch 
                checked={tencentAdData.enabled} 
                onCheckedChange={(enabled) => setTencentAdData(prev => ({ ...prev, enabled }))}
              />
            </div>

            {tencentAdData.enabled && (
              <>
                {/* 投放渠道选择 */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Radio className="w-5 h-5" />
                      投放渠道选择
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {tencentAdChannels.map((channel) => (
                        <div 
                          key={channel.id}
                          className={`border rounded-lg p-4 cursor-pointer transition-all ${
                            tencentAdData.channels?.includes(channel.id) 
                              ? 'border-red-500 bg-red-50' 
                              : 'border-gray-200 hover:border-red-300'
                          }`}
                          onClick={() => handleTencentAdChannelToggle(channel.id)}
                        >
                          <div className="flex items-center gap-3 mb-3">
                            <div className={`p-2 rounded-lg ${
                              tencentAdData.channels?.includes(channel.id) 
                                ? 'bg-red-100' 
                                : 'bg-gray-100'
                            }`}>
                              <channel.icon className={`w-5 h-5 ${
                                tencentAdData.channels?.includes(channel.id) 
                                  ? 'text-red-600' 
                                  : 'text-gray-600'
                              }`} />
                            </div>
                            <div>
                              <h4 className="font-medium">{channel.name}</h4>
                              <p className="text-xs text-gray-500">最低预算：¥{channel.minBudget}</p>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{channel.description}</p>
                          <div className="flex flex-wrap gap-1">
                            {channel.features.map((feature, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                          </div>
                          <div className="mt-3 text-xs text-gray-500">
                            平均CPM: ¥{channel.avgCpm}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* 目标受众设置 */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="w-5 h-5" />
                      目标受众设置
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* 地理位置 */}
                    <div className="space-y-3">
                      <Label className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        投放范围
                      </Label>
                      <div className="space-y-3">
                        <div className="flex items-center gap-4">
                          <span className="text-sm">以门店为中心</span>
                          <span className="font-medium">{tencentAdData.radiusKm}公里</span>
                        </div>
                        <Slider
                          value={[tencentAdData.radiusKm || 5]}
                          onValueChange={(value) => setTencentAdData(prev => ({ ...prev, radiusKm: value[0] }))}
                          max={50}
                          min={1}
                          step={1}
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>1公里</span>
                          <span>50公里</span>
                        </div>
                      </div>
                    </div>

                    {/* 年龄范围 */}
                    <div className="space-y-3">
                      <Label>年龄范围</Label>
                      <div className="space-y-3">
                        <div className="flex items-center gap-4">
                          <span className="font-medium">
                            {tencentAdData.ageRange?.min}岁 - {tencentAdData.ageRange?.max}岁
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label className="text-sm">最小年龄</Label>
                            <Slider
                              value={[tencentAdData.ageRange?.min || 18]}
                              onValueChange={(value) => setTencentAdData(prev => ({ 
                                ...prev, 
                                ageRange: { ...prev.ageRange!, min: value[0] }
                              }))}
                              max={65}
                              min={18}
                              step={1}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-sm">最大年龄</Label>
                            <Slider
                              value={[tencentAdData.ageRange?.max || 65]}
                              onValueChange={(value) => setTencentAdData(prev => ({ 
                                ...prev, 
                                ageRange: { ...prev.ageRange!, max: value[0] }
                              }))}
                              max={65}
                              min={18}
                              step={1}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* 性别 */}
                    <div className="space-y-3">
                      <Label>性别</Label>
                      <Select 
                        value={tencentAdData.gender}
                        onValueChange={(value) => setTencentAdData(prev => ({ ...prev, gender: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="不限">不限</SelectItem>
                          <SelectItem value="男性">男性</SelectItem>
                          <SelectItem value="女性">女性</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* 兴趣标签 */}
                    <div className="space-y-3">
                      <Label>兴趣标签</Label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {interestTags.map((interest) => (
                          <div 
                            key={interest.id}
                            className={`flex items-center gap-2 p-3 border rounded-lg cursor-pointer transition-all ${
                              tencentAdData.interests?.includes(interest.id) 
                                ? 'border-red-500 bg-red-50' 
                                : 'border-gray-200 hover:border-red-300'
                            }`}
                            onClick={() => handleInterestToggle(interest.id)}
                          >
                            <interest.icon className={`w-4 h-4 ${
                              tencentAdData.interests?.includes(interest.id) 
                                ? 'text-red-600' 
                                : 'text-gray-600'
                            }`} />
                            <span className="text-sm">{interest.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* 预算设置 */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="w-5 h-5" />
                      预算与出价
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <Label>投放预算</Label>
                        <div className="space-y-2">
                          <Input
                            type="number"
                            placeholder="请输入投放预算"
                            value={tencentAdData.budget}
                            onChange={(e) => setTencentAdData(prev => ({ 
                              ...prev, 
                              budget: parseInt(e.target.value) || 0 
                            }))}
                          />
                          <p className="text-xs text-gray-500">建议最低预算：¥1000</p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <Label>出价策略</Label>
                        <Select 
                          value={tencentAdData.bidStrategy}
                          onValueChange={(value) => setTencentAdData(prev => ({ ...prev, bidStrategy: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="CPC">CPC - 按点击付费</SelectItem>
                            <SelectItem value="CPM">CPM - 按展示付费</SelectItem>
                            <SelectItem value="CPA">CPA - 按转化付费</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* 预估效果 */}
                    {tencentAdData.channels && tencentAdData.channels.length > 0 && tencentAdData.budget && tencentAdData.budget > 0 && (
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 className="font-medium text-blue-900 mb-3">预估投放效果</h4>
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div>
                            <p className="text-lg font-bold text-blue-600">
                              {adCostData.estimatedImpressions.toLocaleString()}
                            </p>
                            <p className="text-xs text-blue-700">预估展示量</p>
                          </div>
                          <div>
                            <p className="text-lg font-bold text-blue-600">
                              {adCostData.estimatedClicks.toLocaleString()}
                            </p>
                            <p className="text-xs text-blue-700">预估点击量</p>
                          </div>
                          <div>
                            <p className="text-lg font-bold text-blue-600">
                              ¥{adCostData.avgCpm.toFixed(2)}
                            </p>
                            <p className="text-xs text-blue-700">平均CPM</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* 投放时间 */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="w-5 h-5" />
                      投放时间设置
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>开始时间</Label>
                        <Input
                          type="time"
                          value={tencentAdData.schedule?.startTime}
                          onChange={(e) => setTencentAdData(prev => ({
                            ...prev,
                            schedule: { ...prev.schedule!, startTime: e.target.value }
                          }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>结束时间</Label>
                        <Input
                          type="time"
                          value={tencentAdData.schedule?.endTime}
                          onChange={(e) => setTencentAdData(prev => ({
                            ...prev,
                            schedule: { ...prev.schedule!, endTime: e.target.value }
                          }))}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>投放日期</Label>
                      <div className="grid grid-cols-7 gap-2">
                        {['周一', '周二', '周三', '周四', '周五', '周六', '周日'].map((day) => (
                          <div 
                            key={day}
                            className={`text-center p-2 border rounded cursor-pointer transition-all ${
                              tencentAdData.schedule?.days?.includes(day) 
                                ? 'border-red-500 bg-red-50 text-red-600' 
                                : 'border-gray-200 hover:border-red-300'
                            }`}
                            onClick={() => {
                              const currentDays = tencentAdData.schedule?.days || [];
                              const newDays = currentDays.includes(day)
                                ? currentDays.filter(d => d !== day)
                                : [...currentDays, day];
                              setTencentAdData(prev => ({
                                ...prev,
                                schedule: { ...prev.schedule!, days: newDays }
                              }));
                            }}
                          >
                            <span className="text-xs">{day}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={() => setAdPromotionOpen(false)}>
              取消
            </Button>
            <Button 
              onClick={handleSaveTencentAd}
              disabled={!tencentAdData.enabled}
              className="bg-red-600 hover:bg-red-700"
            >
              {tencentAdData.enabled ? `开始投放 (¥${tencentAdData.budget || 0})` : '保存设置'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );

  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-medium mb-2">营销策略</h1>
          <p className="text-muted-foreground">
            基于用户画像制定精准营销策略，提升转化效果
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              创建活动
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-5xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>创建营销活动</DialogTitle>
              <DialogDescription>
                创建新的营销活动，包括活动信息、目标客群、预算设置等，一键发布到小程序和腾讯广告平台
              </DialogDescription>
            </DialogHeader>
            <CreateCampaignForm />
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="active" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">活动管理</TabsTrigger>
          <TabsTrigger value="templates">策略模板</TabsTrigger>
          <TabsTrigger value="analysis">效果分析</TabsTrigger>
        </TabsList>

        {/* 活动管理 */}
        <TabsContent value="active" className="space-y-4">
          {/* 发布统计 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Smartphone className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-blue-900">小程序活动状态</h4>
                      <p className="text-sm text-blue-700">
                        当前有 <span className="font-bold">{publishedCampaigns.length}</span> 个活动正在小程序展示
                      </p>
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setMiniProgramPreviewOpen(true)}
                    className="text-blue-600 border-blue-200 hover:bg-blue-50"
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    预览小程序
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-red-100 rounded-lg">
                      <Megaphone className="w-5 h-5 text-red-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-red-900">腾讯广告投放</h4>
                      <p className="text-sm text-red-700">
                        当前有 <span className="font-bold">
                          {campaigns.filter(c => c.tencentAd?.enabled).length}
                        </span> 个活动正在投放广告
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-red-700">总花费</p>
                    <p className="font-bold text-red-900">
                      ¥{campaigns.reduce((sum, c) => sum + (c.tencentAd?.spend || 0), 0).toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {campaigns.map((campaign) => (
              <Card key={campaign.id}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <CardTitle className="text-lg">{campaign.name}</CardTitle>
                        {campaign.tencentAd?.enabled && (
                          <Badge variant="outline" className="text-xs border-red-500 text-red-600">
                            广告投放
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {campaign.type}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge variant={
                        campaign.status === '进行中' ? 'default' :
                        campaign.status === '已完成' ? 'secondary' : 'outline'
                      }>
                        {campaign.status}
                      </Badge>
                      <div className="flex gap-1">
                        {campaign.publishedToMiniProgram && (
                          <Badge variant="outline" className="text-xs">
                            <Smartphone className="w-3 h-3 mr-1" />
                            小程序
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">目标群体</p>
                      <p className="font-medium">{campaign.targetGroup}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">活动周期</p>
                      <p className="font-medium">
                        {campaign.startDate} - {campaign.endDate}
                      </p>
                    </div>
                  </div>

                  {/* 预算进度 */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>预算使用</span>
                      <span>¥{campaign.spent.toLocaleString()} / ¥{campaign.budget.toLocaleString()}</span>
                    </div>
                    <Progress value={(campaign.spent / campaign.budget) * 100} className="h-2" />
                  </div>

                  {/* 关键指标 */}
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <p className="text-lg font-bold">{campaign.reach}</p>
                      <p className="text-xs text-muted-foreground">触达人数</p>
                    </div>
                    <div>
                      <p className="text-lg font-bold">{campaign.conversion}%</p>
                      <p className="text-xs text-muted-foreground">转化率</p>
                    </div>
                    <div>
                      <p className="text-lg font-bold">¥{campaign.revenue.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">收入</p>
                    </div>
                  </div>

                  {/* 腾讯广告数据 */}
                  {campaign.tencentAd?.enabled && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-red-800">腾讯广告数据</h5>
                        <Badge variant={
                          campaign.tencentAd.status === 'running' ? 'default' :
                          campaign.tencentAd.status === 'pending' ? 'secondary' :
                          campaign.tencentAd.status === 'paused' ? 'outline' : 'destructive'
                        } className="text-xs">
                          {campaign.tencentAd.status === 'running' ? '投放中' :
                           campaign.tencentAd.status === 'pending' ? '审核中' :
                           campaign.tencentAd.status === 'paused' ? '已暂停' : '已完成'}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-4 gap-2 text-center">
                        <div>
                          <p className="text-sm font-bold text-red-600">
                            ¥{(campaign.tencentAd.spend || 0).toLocaleString()}
                          </p>
                          <p className="text-xs text-red-700">已花费</p>
                        </div>
                        <div>
                          <p className="text-sm font-bold text-red-600">
                            {(campaign.tencentAd.impressions || 0).toLocaleString()}
                          </p>
                          <p className="text-xs text-red-700">展示量</p>
                        </div>
                        <div>
                          <p className="text-sm font-bold text-red-600">
                            {(campaign.tencentAd.clicks || 0).toLocaleString()}
                          </p>
                          <p className="text-xs text-red-700">点击量</p>
                        </div>
                        <div>
                          <p className="text-sm font-bold text-red-600">
                            {(campaign.tencentAd.ctr || 0).toFixed(2)}%
                          </p>
                          <p className="text-xs text-red-700">点击率</p>
                        </div>
                      </div>
                      <div className="mt-2 text-xs text-red-600">
                        投放渠道: {campaign.tencentAd.channels?.join(', ')} | 
                        覆盖范围: {campaign.tencentAd.radiusKm}公里
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => setMiniProgramPreviewOpen(true)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      查看
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Edit className="w-4 h-4 mr-1" />
                      编辑
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 text-red-600 border-red-300 hover:bg-red-50"
                      onClick={() => handlePromotionClick(campaign.id)}
                    >
                      <Megaphone className="w-4 h-4 mr-1" />
                      推广
                    </Button>
                    {campaign.status === '进行中' ? (
                      <Button variant="outline" size="sm">
                        <Pause className="w-4 h-4" />
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm">
                        <Play className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  {/* 发布状态 */}
                  {campaign.publishedToMiniProgram ? (
                    <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Smartphone className="w-4 h-4 text-blue-600" />
                          <span className="text-sm text-blue-700">已发布到小程序</span>
                        </div>
                        <Button variant="ghost" size="sm" className="text-blue-600">
                          <Settings className="w-3 h-3 mr-1" />
                          设置
                        </Button>
                      </div>
                    </div>
                  ) : (
                    campaign.status === '进行中' && (
                      <div className="p-2 bg-gray-50 border border-gray-200 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Smartphone className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-700">未发布到小程序</span>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-blue-600 border-blue-200 hover:bg-blue-50"
                            onClick={() => publishToMiniProgram(campaign.id)}
                          >
                            发布
                          </Button>
                        </div>
                      </div>
                    )
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* 智能推荐活动 */}
          <div className="mt-8">
            <div className="flex items-center gap-2 mb-4">
              <Brain className="w-5 h-5 text-purple-600" />
              <h3 className="text-lg font-medium text-purple-800">推荐活动</h3>
              <Badge variant="outline" className="text-purple-600 border-purple-200">
                <Sparkles className="w-3 h-3 mr-1" />
                AI智能推荐
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-6">
              基于您的客户画像数据和市场趋势分析，为您智能推荐最适合的营销活动
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {recommendedCampaigns.map((recommendation) => (
                <Card key={recommendation.id} className="relative overflow-hidden">
                  <div className="absolute top-4 right-4">
                    <div className="flex items-center gap-1 bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                      <Star className="w-3 h-3" />
                      {recommendation.confidence}%
                    </div>
                  </div>

                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <Zap className="w-4 h-4 text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-base mb-1">{recommendation.name}</CardTitle>
                        <p className="text-sm text-muted-foreground mb-2">
                          {recommendation.description}
                        </p>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {recommendation.type}
                          </Badge>
                          <Badge variant={
                            recommendation.urgency === '高' ? 'destructive' : 
                            recommendation.urgency === '中' ? 'default' : 'secondary'
                          } className="text-xs">
                            {recommendation.urgency}优先级
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div>
                      <h5 className="text-sm font-medium mb-2 flex items-center gap-1">
                        <Target className="w-4 h-4" />
                        {recommendation.reasonTitle}
                      </h5>
                      <ul className="space-y-1">
                        {recommendation.reasons.map((reason, index) => (
                          <li key={index} className="text-xs text-muted-foreground flex items-start gap-1">
                            <CheckCircle className="w-3 h-3 mt-0.5 text-green-500 shrink-0" />
                            {reason}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-center">
                      <div className="bg-blue-50 p-2 rounded">
                        <p className="text-lg font-bold text-blue-600">
                          {recommendation.expectedResults.targetCustomers}
                        </p>
                        <p className="text-xs text-blue-700">目标客户</p>
                      </div>
                      <div className="bg-green-50 p-2 rounded">
                        <p className="text-lg font-bold text-green-600">
                          {recommendation.expectedResults.expectedConversion}
                        </p>
                        <p className="text-xs text-green-700">预期转化</p>
                      </div>
                      <div className="bg-orange-50 p-2 rounded">
                        <p className="text-lg font-bold text-orange-600">
                          {recommendation.expectedResults.projectedRevenue}
                        </p>
                        <p className="text-xs text-orange-700">预期收入</p>
                      </div>
                      <div className="bg-purple-50 p-2 rounded">
                        <p className="text-lg font-bold text-purple-600">
                          {recommendation.expectedResults.roi}
                        </p>
                        <p className="text-xs text-purple-700">ROI</p>
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-3 rounded-lg border border-purple-200">
                      <div className="flex items-start gap-2">
                        <Brain className="w-4 h-4 text-purple-600 mt-0.5 shrink-0" />
                        <div>
                          <h6 className="text-xs font-medium text-purple-800 mb-1">AI洞察</h6>
                          <p className="text-xs text-purple-700">{recommendation.aiInsights}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        onClick={() => handleViewRecommendationDetails(recommendation.id)}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        详情
                      </Button>
                      <Button 
                        size="sm" 
                        className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                        onClick={() => handlePublishRecommendation(recommendation.id)}
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        启动活动
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* 策略模板 */}
        <TabsContent value="templates" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {strategyTemplates.map((template, index) => (
              <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">{template.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {template.description}
                  </p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">目标群体:</span>
                      <span>{template.targetGroup}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">预期ROI:</span>
                      <span className="text-green-600 font-medium">{template.expectedROI}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">执行周期:</span>
                      <span>{template.duration}</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full" size="sm">
                    使用模板
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 效果分析 */}
        <TabsContent value="analysis" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">总触达人数</p>
                    <p className="text-2xl font-bold">2,856</p>
                  </div>
                  <Users className="w-8 h-8 text-blue-600" />
                </div>
                <div className="flex items-center mt-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                  <span className="text-green-600">+12.5%</span>
                  <span className="text-muted-foreground ml-1">vs 上月</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">平均转化率</p>
                    <p className="text-2xl font-bold">21.3%</p>
                  </div>
                  <Target className="w-8 h-8 text-green-600" />
                </div>
                <div className="flex items-center mt-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                  <span className="text-green-600">+3.2%</span>
                  <span className="text-muted-foreground ml-1">vs 上月</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">总营收</p>
                    <p className="text-2xl font-bold">¥58,020</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-orange-600" />
                </div>
                <div className="flex items-center mt-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                  <span className="text-green-600">+8.7%</span>
                  <span className="text-muted-foreground ml-1">vs 上月</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">广告ROI</p>
                    <p className="text-2xl font-bold">245%</p>
                  </div>
                  <Megaphone className="w-8 h-8 text-red-600" />
                </div>
                <div className="flex items-center mt-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                  <span className="text-green-600">+18.4%</span>
                  <span className="text-muted-foreground ml-1">vs 上月</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <MiniProgramPreview 
        open={miniProgramPreviewOpen} 
        onOpenChange={setMiniProgramPreviewOpen}
      />

      <TencentAdPromotionDialog />
    </div>
  );
}