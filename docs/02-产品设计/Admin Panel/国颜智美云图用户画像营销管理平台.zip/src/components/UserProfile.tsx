import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Users, 
  TrendingUp, 
  ShoppingBag, 
  Clock,
  Heart,
  Star,
  MapPin,
  Calendar,
  Droplets,
  Sun,
  Shield,
  AlertTriangle,
  Sparkles
} from 'lucide-react';

const customerSegments = [
  {
    name: '高价值客户',
    count: 342,
    percentage: 12,
    avgSpending: 8500,
    totalSpending: 2907000,
    totalSpendingPercentage: 34,
    features: ['消费频次高', '客单价高', '忠诚度高'],
    color: 'bg-green-500',
    aiRecommendation: {
      campaignName: 'VIP专享护理套餐',
      reason: '基于高消费能力和忠诚度，推荐高端定制服务',
      score: 95
    }
  },
  {
    name: '潜在价值客户',
    count: 756,
    percentage: 27,
    avgSpending: 3200,
    totalSpending: 2419200,
    totalSpendingPercentage: 28,
    features: ['年轻群体', '消费潜力大', '价格敏感'],
    color: 'bg-blue-500',
    aiRecommendation: {
      campaignName: '青春焕颜体验计划',
      reason: '针对年轻群体推出性价比高的护肤体验',
      score: 88
    }
  },
  {
    name: '稳定客户',
    count: 1089,
    percentage: 38,
    avgSpending: 2100,
    totalSpending: 2286900,
    totalSpendingPercentage: 27,
    features: ['定期消费', '服务满意', '推荐意愿强'],
    color: 'bg-purple-500',
    aiRecommendation: {
      campaignName: '老友回馈感恩节',
      reason: '利用高推荐意愿，开展口碑传播活动',
      score: 92
    }
  },
  {
    name: '流失风险客户',
    count: 456,
    percentage: 16,
    avgSpending: 1800,
    totalSpending: 820800,
    totalSpendingPercentage: 9,
    features: ['消费下降', '到店频次低', '满意度下降'],
    color: 'bg-red-500',
    aiRecommendation: {
      campaignName: '挽回专属优惠',
      reason: '通过个性化服务和优惠重新激活客户',
      score: 78
    }
  },
  {
    name: '新客户',
    count: 204,
    percentage: 7,
    avgSpending: 800,
    totalSpending: 163200,
    totalSpendingPercentage: 2,
    features: ['首次消费', '了解需求', '体验为主'],
    color: 'bg-yellow-500',
    aiRecommendation: {
      campaignName: '新客专享试用礼',
      reason: '低门槛体验活动提升转化和留存',
      score: 85
    }
  },
];

const demographicData = [
  { category: '年龄分布', data: [
    { label: '18-25岁', value: 25, count: 712 },
    { label: '26-35岁', value: 35, count: 998 },
    { label: '36-45岁', value: 28, count: 798 },
    { label: '46-55岁', value: 12, count: 342 },
  ]},
  { category: '消费水平', data: [
    { label: '高消费', value: 15, count: 427 },
    { label: '中高消费', value: 32, count: 912 },
    { label: '中等消费', value: 38, count: 1083 },
    { label: '低消费', value: 15, count: 428 },
  ]},
  { category: '到店频次', data: [
    { label: '每周1次以上', value: 8, count: 228 },
    { label: '每月2-3次', value: 25, count: 713 },
    { label: '每月1次', value: 45, count: 1284 },
    { label: '不定期', value: 22, count: 627 },
  ]},
];

const behaviorPatterns = [
  {
    title: '服务偏好',
    data: [
      { name: '面部护理', percentage: 85, trend: '+5%' },
      { name: '美甲美睫', percentage: 62, trend: '+12%' },
      { name: '身体护理', percentage: 45, trend: '+8%' },
      { name: '头发护理', percentage: 38, trend: '-2%' },
      { name: '美容咨询', percentage: 28, trend: '+15%' },
    ]
  },
  {
    title: '时间偏好',
    data: [
      { name: '工作日下午', percentage: 42, trend: '+3%' },
      { name: '周末全天', percentage: 68, trend: '+7%' },
      { name: '工作日晚上', percentage: 35, trend: '+10%' },
      { name: '节假日', percentage: 58, trend: '+5%' },
      { name: '工作日上午', percentage: 25, trend: '-1%' },
    ]
  }
];

// 肤质画像数据
const skinTypeSegments = [
  {
    name: '干性肌肤',
    count: 798,
    percentage: 28,
    avgAge: 32,
    characteristics: ['缺水紧绷', '细纹明显', '易敏感'],
    preferredServices: ['深层补水', '抗衰护理', '温和修复'],
    avgSpending: 3200,
    totalSpending: 2553600,
    totalSpendingPercentage: 32,
    color: 'bg-orange-500',
    icon: Sun,
    improvement: '+12%',
    aiRecommendation: {
      campaignName: '水润保湿护理季',
      reason: '针对干性肌肤缺水问题，推出深度补水护理方案',
      score: 93
    }
  },
  {
    name: '油性肌肤',
    count: 624,
    percentage: 22,
    avgAge: 26,
    characteristics: ['出油旺盛', '毛孔粗大', '易生痘痘'],
    preferredServices: ['深层清洁', '控油护理', '毛孔收缩'],
    avgSpending: 2800,
    totalSpending: 1747200,
    totalSpendingPercentage: 22,
    color: 'bg-yellow-500',
    icon: Droplets,
    improvement: '+8%',
    aiRecommendation: {
      campaignName: '清爽控油焕肤计划',
      reason: '年轻油性肌肤群体，推出性价比高的控油清洁套餐',
      score: 87
    }
  },
  {
    name: '混合性肌肤',
    count: 912,
    percentage: 32,
    avgAge: 29,
    characteristics: ['T区出油', '两颊偏干', '护理复杂'],
    preferredServices: ['分区护理', '平衡调理', '定制方案'],
    avgSpending: 3500,
    totalSpending: 3192000,
    totalSpendingPercentage: 40,
    color: 'bg-blue-500',
    icon: TrendingUp,
    improvement: '+15%',
    aiRecommendation: {
      campaignName: '定制分区护理专案',
      reason: '混合性肌肤需求复杂，推出个性化定制护理服务',
      score: 91
    }
  },
  {
    name: '敏感性肌肤',
    count: 456,
    percentage: 16,
    avgAge: 34,
    characteristics: ['易过敏', '屏障受损', '需温和护理'],
    preferredServices: ['舒敏修复', '屏障重建', '医学护肤'],
    avgSpending: 4200,
    totalSpending: 1915200,
    totalSpendingPercentage: 24,
    color: 'bg-red-500',
    icon: Shield,
    improvement: '+20%',
    aiRecommendation: {
      campaignName: '温和修护专业疗程',
      reason: '敏感肌高消费能力，推出高端温和修护项目',
      score: 95
    }
  },
  {
    name: '中性肌肤',
    count: 60,
    percentage: 2,
    avgAge: 25,
    characteristics: ['水油平衡', '状态稳定', '护理简单'],
    preferredServices: ['基础护理', '预防保养', '定期维护'],
    avgSpending: 2400,
    totalSpending: 144000,
    totalSpendingPercentage: 2,
    color: 'bg-green-500',
    icon: Sparkles,
    improvement: '+5%',
    aiRecommendation: {
      campaignName: '青春维稳护理套餐',
      reason: '年轻中性肌肤，推出预防性护理维稳方案',
      score: 82
    }
  }
];

// 肤质分析数据
const skinAnalysisData = [
  {
    category: '肤质问题分布',
    data: [
      { label: '毛孔粗大', value: 45, count: 1282, severity: 'medium' },
      { label: '干燥缺水', value: 38, count: 1083, severity: 'high' },
      { label: '色素沉着', value: 32, count: 912, severity: 'medium' },
      { label: '敏感泛红', value: 28, count: 798, severity: 'high' },
      { label: '细纹皱纹', value: 25, count: 713, severity: 'low' },
      { label: '痘痘粉刺', value: 22, count: 627, severity: 'medium' }
    ]
  }
];

// 护理效果追踪
const skinCareEffectiveness = [
  {
    treatment: '深层补水护理',
    targetSkinTypes: ['干性肌肤', '敏感性肌肤'],
    satisfaction: 92,
    improvement: 88,
    repeatRate: 85,
    avgSessions: 6
  },
  {
    treatment: '控油清洁护理',
    targetSkinTypes: ['油性肌肤', '混合性肌肤'],
    satisfaction: 89,
    improvement: 82,
    repeatRate: 78,
    avgSessions: 4
  },
  {
    treatment: '抗衰老护理',
    targetSkinTypes: ['干性肌肤', '混合性肌肤'],
    satisfaction: 94,
    improvement: 90,
    repeatRate: 92,
    avgSessions: 8
  },
  {
    treatment: '敏感肌修复',
    targetSkinTypes: ['敏感性肌肤'],
    satisfaction: 96,
    improvement: 93,
    repeatRate: 95,
    avgSessions: 10
  }
];

interface UserProfileProps {
  onNavigateToStrategy?: () => void;
}

export function UserProfile({ onNavigateToStrategy }: UserProfileProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-medium mb-2">用户画像</h1>
        <p className="text-muted-foreground">
          基于数据分析构建精准客户画像，洞察客户需求和行为模式
        </p>
      </div>

      <Tabs defaultValue="segments" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="segments">客户细分</TabsTrigger>
          <TabsTrigger value="skin-profile">肤质画像</TabsTrigger>
          <TabsTrigger value="demographics">人群特征</TabsTrigger>
          <TabsTrigger value="behavior">行为模式</TabsTrigger>
        </TabsList>

        {/* 客户细分 */}
        <TabsContent value="segments" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {customerSegments.map((segment) => (
              <Card key={segment.name}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{segment.name}</CardTitle>
                    <div className={`w-3 h-3 rounded-full ${segment.color}`} />
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-2xl font-bold">{segment.count}</p>
                      <p className="text-sm text-muted-foreground">客户数量</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{segment.percentage}%</p>
                      <p className="text-sm text-muted-foreground">占比</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-lg font-medium text-primary">
                        ¥{segment.avgSpending.toLocaleString()}
                      </p>
                      <p className="text-sm text-muted-foreground">平均消费</p>
                    </div>
                    <div>
                      <p className="text-lg font-medium text-primary">
                        ¥{(segment.totalSpending / 10000).toFixed(1)}万
                      </p>
                      <p className="text-sm text-muted-foreground">消费总额</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-orange-600">
                      {segment.totalSpendingPercentage}%
                    </p>
                    <p className="text-sm text-muted-foreground">消费总额占比</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">特征标签：</p>
                    <div className="flex flex-wrap gap-1">
                      {segment.features.map((feature) => (
                        <Badge key={feature} variant="secondary" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-3 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-600" />
                      <p className="text-sm font-medium text-purple-700">AI营销推荐</p>
                      <Badge variant="outline" className="text-xs bg-purple-100 text-purple-700 border-purple-300">
                        推荐值: {segment.aiRecommendation.score}%
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <p className="font-medium text-purple-900">{segment.aiRecommendation.campaignName}</p>
                      <p className="text-xs text-purple-700 leading-relaxed">
                        {segment.aiRecommendation.reason}
                      </p>
                    </div>
                    <Button 
                      size="sm" 
                      className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                      onClick={onNavigateToStrategy}
                    >
                      立即制定营销策略
                    </Button>
                  </div>
                  <Button className="w-full" variant="outline">
                    查看详情
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 肤质画像 */}
        <TabsContent value="skin-profile" className="space-y-6">
          {/* 肤质类型分布 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {skinTypeSegments.map((skinType) => {
              const IconComponent = skinType.icon;
              return (
                <Card key={skinType.name}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <IconComponent className="w-5 h-5" />
                        {skinType.name}
                      </CardTitle>
                      <div className={`w-3 h-3 rounded-full ${skinType.color}`} />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-2xl font-bold">{skinType.count}</p>
                        <p className="text-sm text-muted-foreground">客户数量</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{skinType.percentage}%</p>
                        <p className="text-sm text-muted-foreground">占比</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-lg font-medium text-primary">
                          ¥{skinType.avgSpending.toLocaleString()}
                        </p>
                        <p className="text-sm text-muted-foreground">平均消费</p>
                      </div>
                      <div>
                        <p className="text-lg font-medium">{skinType.avgAge}岁</p>
                        <p className="text-sm text-muted-foreground">平均年龄</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-lg font-medium text-primary">
                          ¥{(skinType.totalSpending / 10000).toFixed(1)}万
                        </p>
                        <p className="text-sm text-muted-foreground">消费总额</p>
                      </div>
                      <div>
                        <p className="text-lg font-medium text-orange-600">
                          {skinType.totalSpendingPercentage}%
                        </p>
                        <p className="text-sm text-muted-foreground">消费总额占比</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium">肤质特征：</p>
                      <div className="flex flex-wrap gap-1">
                        {skinType.characteristics.map((characteristic) => (
                          <Badge key={characteristic} variant="secondary" className="text-xs">
                            {characteristic}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium">偏好服务：</p>
                      <div className="flex flex-wrap gap-1">
                        {skinType.preferredServices.map((service) => (
                          <Badge key={service} variant="outline" className="text-xs">
                            {service}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-3 p-3 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-blue-600" />
                        <p className="text-sm font-medium text-blue-700">AI肤质营销推荐</p>
                        <Badge variant="outline" className="text-xs bg-blue-100 text-blue-700 border-blue-300">
                          推荐值: {skinType.aiRecommendation.score}%
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <p className="font-medium text-blue-900">{skinType.aiRecommendation.campaignName}</p>
                        <p className="text-xs text-blue-700 leading-relaxed">
                          {skinType.aiRecommendation.reason}
                        </p>
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                        onClick={onNavigateToStrategy}
                      >
                        制定肤质专属营销策略
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">增长趋势</span>
                      <Badge 
                        variant={skinType.improvement.startsWith('+') ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {skinType.improvement}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* 肤质问题分析 */}
          <Card>
            <CardHeader>
              <CardTitle>肤质问题分布</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {skinAnalysisData[0].data.map((problem) => {
                const getSeverityColor = (severity: string) => {
                  switch (severity) {
                    case 'high': return 'text-red-600';
                    case 'medium': return 'text-orange-600';
                    case 'low': return 'text-green-600';
                    default: return 'text-gray-600';
                  }
                };

                const getSeverityBg = (severity: string) => {
                  switch (severity) {
                    case 'high': return 'bg-red-500';
                    case 'medium': return 'bg-orange-500';
                    case 'low': return 'bg-green-500';
                    default: return 'bg-gray-500';
                  }
                };

                return (
                  <div key={problem.label} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">{problem.label}</span>
                      <div className="text-right">
                        <span className={`text-sm font-bold ${getSeverityColor(problem.severity)}`}>
                          {problem.value}%
                        </span>
                        <p className="text-xs text-muted-foreground">
                          {problem.count} 人
                        </p>
                      </div>
                    </div>
                    <div className="relative">
                      <Progress value={problem.value} className="h-2" />
                      <div 
                        className={`absolute top-0 left-0 h-2 rounded-full ${getSeverityBg(problem.severity)}`}
                        style={{ width: `${problem.value}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* 护理效果追踪 */}
          <Card>
            <CardHeader>
              <CardTitle>护理效果追踪</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {skinCareEffectiveness.map((treatment) => (
                  <div key={treatment.treatment} className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{treatment.treatment}</h4>
                      <Badge variant="outline" className="text-xs">
                        {treatment.avgSessions}次疗程
                      </Badge>
                    </div>
                    
                    <div className="text-xs text-muted-foreground">
                      适用肤质：{treatment.targetSkinTypes.join('、')}
                    </div>

                    <div className="space-y-3">
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>满意度</span>
                          <span className="font-medium">{treatment.satisfaction}%</span>
                        </div>
                        <Progress value={treatment.satisfaction} className="h-2" />
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>改善效果</span>
                          <span className="font-medium">{treatment.improvement}%</span>
                        </div>
                        <Progress value={treatment.improvement} className="h-2" />
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>复购率</span>
                          <span className="font-medium">{treatment.repeatRate}%</span>
                        </div>
                        <Progress value={treatment.repeatRate} className="h-2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 人群特征 */}
        <TabsContent value="demographics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {demographicData.map((category) => (
              <Card key={category.category}>
                <CardHeader>
                  <CardTitle>{category.category}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {category.data.map((item) => (
                    <div key={item.label} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{item.label}</span>
                        <div className="text-right">
                          <span className="text-sm font-bold">{item.value}%</span>
                          <p className="text-xs text-muted-foreground">
                            {item.count} 人
                          </p>
                        </div>
                      </div>
                      <Progress value={item.value} className="h-2" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 行为模式 */}
        <TabsContent value="behavior" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {behaviorPatterns.map((pattern) => (
              <Card key={pattern.title}>
                <CardHeader>
                  <CardTitle>{pattern.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {pattern.data.map((item) => (
                    <div key={item.name} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{item.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold">{item.percentage}%</span>
                          <Badge 
                            variant={item.trend.startsWith('+') ? 'secondary' : 'outline'}
                            className="text-xs"
                          >
                            {item.trend}
                          </Badge>
                        </div>
                      </div>
                      <Progress value={item.percentage} className="h-2" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* 行为洞察 */}
          <Card>
            <CardHeader>
              <CardTitle>行为洞察</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                  <Heart className="w-8 h-8 text-red-500" />
                  <div>
                    <p className="font-medium">客户忠诚度</p>
                    <p className="text-2xl font-bold">78%</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                  <Star className="w-8 h-8 text-yellow-500" />
                  <div>
                    <p className="font-medium">满意度评分</p>
                    <p className="text-2xl font-bold">4.6</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                  <Clock className="w-8 h-8 text-blue-500" />
                  <div>
                    <p className="font-medium">平均停留时间</p>
                    <p className="text-2xl font-bold">95分钟</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                  <TrendingUp className="w-8 h-8 text-green-500" />
                  <div>
                    <p className="font-medium">复购率</p>
                    <p className="text-2xl font-bold">65%</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}