import { useState } from 'react';
import skinAnalysisImage from 'figma:asset/5e9922a7e933eea9cca626d1072b1904af823e80.png';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from './ui/dialog';
import { 
  Plus, 
  Search, 
  Filter,
  Download,
  Upload,
  Eye,
  Edit,
  Trash2,
  ShoppingBag,
  Heart,
  Zap,
  Calendar,
  CreditCard,
  TrendingUp,
  BarChart3,
  Activity,
  Stethoscope,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

const mockCustomers = [
  {
    id: 1,
    name: '张美丽',
    phone: '138****8888',
    age: 28,
    gender: '女',
    lastVisit: '2024-01-15',
    services: ['面部护理', '美甲'],
    totalSpent: 3680,
    source: '朋友介绍',
    visitFrequency: '月2-3次',
    avgSpending: 420,
    skinType: '混合性',
    concerns: ['毛孔粗大', '暗沉'],
    createdAt: '2024-01-10',
  },
  {
    id: 2,
    name: '李雅静',
    phone: '139****9999',
    age: 35,
    gender: '女',
    lastVisit: '2024-01-20',
    services: ['头发护理', '面部护理'],
    totalSpent: 5240,
    source: '网络广告',
    visitFrequency: '月1次',
    avgSpending: 650,
    skinType: '干性',
    concerns: ['细纹', '缺水'],
    createdAt: '2024-01-12',
  },
  {
    id: 3,
    name: '王优雅',
    phone: '136****6666',
    age: 42,
    gender: '女',
    lastVisit: '2024-01-18',
    services: ['身体护理', '面部护理'],
    totalSpent: 8900,
    source: '老客户',
    visitFrequency: '月4-5次',
    avgSpending: 890,
    skinType: '敏感性',
    concerns: ['敏感泛红', '松弛'],
    createdAt: '2023-12-15',
  },
];

// 数据采集方式
const dataCollectionMethods = [
  {
    name: '会员注册',
    description: '会员注册时收集完整个人资料',
    total: '623',
    recent14Days: '+32',
    status: '活跃',
    icon: 'Users'
  },
  {
    name: '门店登记',
    description: '客户到店时收集详细信息',
    total: '856', 
    recent14Days: '+47',
    status: '活跃',
    icon: 'Store'
  },
  {
    name: '支付记录',
    description: '客户支付交易数据统计分析',
    total: '432',
    recent14Days: '+18',
    status: '活跃',
    icon: 'CreditCard'
  },
  {
    name: '肌肤检测',
    description: 'AI肌肤检测收集肌肤数据',
    total: '289',
    recent14Days: '+23',
    status: '活跃',
    icon: 'Stethoscope'
  },
  {
    name: '第三方接口',
    description: '通过第三方API获取数据',
    total: '157',
    recent14Days: '+9',
    status: '活跃',
    icon: 'Zap'
  }
];

// 消费记录数据
const consumptionRecords = [
  {
    id: 1,
    customerName: '张美丽',
    consumptionType: '服务',
    consumptionContent: '面部护理',
    amount: 3680,
    consumptionTime: '2024-01-15',
    paymentMethod: '现金',
    relatedCampaign: '春季护肤套餐',
    isFirstVisit: false
  },
  {
    id: 2,
    customerName: '李雅静',
    consumptionType: '产品',
    consumptionContent: '头部护理套装',
    amount: 5240,
    consumptionTime: '2024-01-20',
    paymentMethod: '线上',
    relatedCampaign: '网络专享',
    isFirstVisit: true
  },
  {
    id: 3,
    customerName: '王优雅',
    consumptionType: '服务',
    consumptionContent: '身体护理',
    amount: 8900,
    consumptionTime: '2024-01-18',
    paymentMethod: 'POS机',
    relatedCampaign: '会员专享活动',
    isFirstVisit: false
  },
  {
    id: 4,
    customerName: '陈思思',
    consumptionType: '其他',
    consumptionContent: '美容工具',
    amount: 1200,
    consumptionTime: '2024-01-22',
    paymentMethod: '充值卡',
    relatedCampaign: '新春特惠',
    isFirstVisit: true
  },
  {
    id: 5,
    customerName: '刘小花',
    consumptionType: '产品',
    consumptionContent: '护肤套装',
    amount: 2800,
    consumptionTime: '2024-01-25',
    paymentMethod: '现金',
    relatedCampaign: '春季护肤套餐',
    isFirstVisit: false
  }
];

// 消费行为画像数据
const consumptionBehaviors = [
  {
    id: 1,
    name: '张美丽',
    level: '中等消费',
    frequency: '月2-3次',
    avgAmount: 420,
    preferredServices: ['面部护理', '美甲'],
    timePattern: '周末下午',
    promotionSensitive: '高',
    repurchaseRate: 85,
    loyaltyScore: 78,
    seasonalTrend: '春季增长',
  },
  {
    id: 2,
    name: '李雅静',
    level: '高消费',
    frequency: '月1次',
    avgAmount: 650,
    preferredServices: ['面部护理', '身体SPA'],
    timePattern: '工作日晚上',
    promotionSensitive: '中',
    repurchaseRate: 92,
    loyaltyScore: 88,
    seasonalTrend: '全年稳定',
  },
  {
    id: 3,
    name: '王优雅',
    level: '超高消费',
    frequency: '月4-5次',
    avgAmount: 890,
    preferredServices: ['抗衰护理', '身体护理'],
    timePattern: '工作日上午',
    promotionSensitive: '低',
    repurchaseRate: 96,
    loyaltyScore: 95,
    seasonalTrend: '夏季高峰',
  },
];

// 肌肤与健康画像数据
const skinHealthProfiles = [
  {
    id: 1,
    name: '张美丽',
    skinType: '混合性',
    skinTone: '中性',
    concerns: ['毛孔粗大', '黑头', 'T区出油'],
    sensitivity: '低敏',
    allergies: ['无'],
    previousTreatments: ['基础清洁', '补水面膜'],
    recommendedServices: ['深层清洁', '收毛孔护理'],
    skinCondition: '良好',
    improvementGoals: ['细化毛孔', '控油平衡'],
    contraindications: ['无'],
    lastSkinTest: '2024-01-10',
    skinTestSource: 'AI肌肤检测',
  },
  {
    id: 2,
    name: '李雅静',
    skinType: '干性',
    skinTone: '偏白',
    concerns: ['细纹', '缺水', '暗沉'],
    sensitivity: '中敏',
    allergies: ['酒精类'],
    previousTreatments: ['补水护理', '抗衰项目'],
    recommendedServices: ['深度补水', '抗氧化护理'],
    skinCondition: '需改善',
    improvementGoals: ['提升水润度', '减少细纹'],
    contraindications: ['避免酒精成分'],
    lastSkinTest: '2024-01-18',
    skinTestSource: '肌肤检测仪',
  },
  {
    id: 3,
    name: '王优雅',
    skinType: '敏感性',
    skinTone: '偏黄',
    concerns: ['敏感泛红', '松弛', '色斑'],
    sensitivity: '高敏',
    allergies: ['香精', '防腐剂'],
    previousTreatments: ['舒敏护理', '紧致提升'],
    recommendedServices: ['温和修复', '抗衰定制'],
    skinCondition: '需专业护理',
    improvementGoals: ['改善敏感', '提升紧致度'],
    contraindications: ['避免刺激性成分', '谨慎使用新产品'],
    lastSkinTest: '2024-01-15',
    skinTestSource: 'AI肌肤检测',
  },
  {
    id: 4,
    name: '赵雪莲',
    skinType: '油性',
    skinTone: '偏白',
    concerns: ['痘痘', '黑头', '毛孔粗大', '出油严重'],
    sensitivity: '低敏',
    allergies: ['无'],
    previousTreatments: ['祛痘护理', '控油清洁'],
    recommendedServices: ['深层清洁', '祛痘护理', '控油护理'],
    skinCondition: '需改善',
    improvementGoals: ['控制出油', '改善痘痘', '收缩毛孔'],
    contraindications: ['无'],
    lastSkinTest: '2024-01-20',
    skinTestSource: '肌肤检测仪',
  },
  {
    id: 5,
    name: '陈思雨',
    skinType: '中性',
    skinTone: '中性',
    concerns: ['轻微暗沉'],
    sensitivity: '低敏',
    allergies: ['无'],
    previousTreatments: ['基础护理'],
    recommendedServices: ['亮肤护理', '基础保养'],
    skinCondition: '良好',
    improvementGoals: ['保持水润', '预防老化'],
    contraindications: ['无'],
    lastSkinTest: '2024-01-12',
    skinTestSource: 'AI肌肤检测',
  },
  {
    id: 6,
    name: '孙晓芳',
    skinType: '干性',
    skinTone: '偏黄',
    concerns: ['干燥脱皮', '细纹', '暗黄'],
    sensitivity: '中敏',
    allergies: ['果酸', '水杨酸'],
    previousTreatments: ['补水面膜', '滋润护理'],
    recommendedServices: ['深度保湿', '抗衰护理', '亮肤护理'],
    skinCondition: '需专业护理',
    improvementGoals: ['深度补水', '提亮肤色', '抗衰老'],
    contraindications: ['避免酸类成分'],
    lastSkinTest: '2024-01-08',
    skinTestSource: '肌肤检测仪',
  },
];

export function DataCollection() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('basic');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [customerDetailOpen, setCustomerDetailOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<typeof mockCustomers[0] | null>(null);
  const [recordDetailOpen, setRecordDetailOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<typeof consumptionRecords[0] | null>(null);
  
  // 消费记录筛选状态
  const [timeFilter, setTimeFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [campaignFilter, setCampaignFilter] = useState('all');
  const [paymentFilter, setPaymentFilter] = useState('all');
  const [firstVisitFilter, setFirstVisitFilter] = useState('all');

  // 肌肤健康画像筛选状态
  const [skinSearchTerm, setSkinSearchTerm] = useState('');
  const [skinTypeFilter, setSkinTypeFilter] = useState('all');
  const [sensitivityFilter, setSensitivityFilter] = useState('all');
  const [conditionFilter, setConditionFilter] = useState('all');
  const [testSourceFilter, setTestSourceFilter] = useState('all');

  const handleViewCustomer = (customer: typeof mockCustomers[0]) => {
    setSelectedCustomer(customer);
    setCustomerDetailOpen(true);
  };

  const handleViewRecord = (record: typeof consumptionRecords[0]) => {
    setSelectedRecord(record);
    setRecordDetailOpen(true);
  };

  // 筛选消费记录
  const filteredRecords = consumptionRecords.filter(record => {
    if (searchTerm && !record.customerName.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    if (typeFilter && typeFilter !== 'all' && record.consumptionType !== typeFilter) {
      return false;
    }
    if (campaignFilter && campaignFilter !== 'all' && record.relatedCampaign !== campaignFilter) {
      return false;
    }
    if (paymentFilter && paymentFilter !== 'all' && record.paymentMethod !== paymentFilter) {
      return false;
    }
    if (firstVisitFilter && firstVisitFilter !== 'all') {
      if (firstVisitFilter === '是' && !record.isFirstVisit) return false;
      if (firstVisitFilter === '否' && record.isFirstVisit) return false;
    }
    return true;
  });

  // 筛选肌肤健康画像
  const filteredSkinProfiles = skinHealthProfiles.filter(profile => {
    if (skinSearchTerm && !profile.name.toLowerCase().includes(skinSearchTerm.toLowerCase())) {
      return false;
    }
    if (skinTypeFilter && skinTypeFilter !== 'all' && profile.skinType !== skinTypeFilter) {
      return false;
    }
    if (sensitivityFilter && sensitivityFilter !== 'all' && profile.sensitivity !== sensitivityFilter) {
      return false;
    }
    if (conditionFilter && conditionFilter !== 'all' && profile.skinCondition !== conditionFilter) {
      return false;
    }
    if (testSourceFilter && testSourceFilter !== 'all' && profile.skinTestSource !== testSourceFilter) {
      return false;
    }
    return true;
  });

  // 重置筛选
  const resetFilters = () => {
    setTimeFilter('all');
    setTypeFilter('all');
    setCampaignFilter('all');
    setPaymentFilter('all');
    setFirstVisitFilter('all');
  };

  // 重置肌肤画像筛选
  const resetSkinFilters = () => {
    setSkinSearchTerm('');
    setSkinTypeFilter('all');
    setSensitivityFilter('all');
    setConditionFilter('all');
    setTestSourceFilter('all');
    setSearchTerm('');
  };

  const AddCustomerForm = () => (
    <Tabs defaultValue="basic" className="space-y-4">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="basic-info">基础信息</TabsTrigger>
        <TabsTrigger value="consumption-info">消费偏好</TabsTrigger>
        <TabsTrigger value="skin-info">肌肤档案</TabsTrigger>
      </TabsList>

      <TabsContent value="basic-info">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">姓名</Label>
            <Input id="name" placeholder="请输入客户姓名" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">手机号</Label>
            <Input id="phone" placeholder="请输入手机号" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="age">年龄</Label>
            <Input id="age" type="number" placeholder="请输入年龄" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="gender">性别</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="选择性别" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="female">女</SelectItem>
                <SelectItem value="male">男</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="source">客户来源</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="选择��户来源" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="referral">朋友介绍</SelectItem>
                <SelectItem value="online">网络广告</SelectItem>
                <SelectItem value="walk-in">路过进店</SelectItem>
                <SelectItem value="repeat">老客户</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="services">感兴趣的服务</Label>
            <Input id="services" placeholder="请输入服务项目" />
          </div>
        </div>
      </TabsContent>

      <TabsContent value="consumption-info">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="budget">预算范围</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="选择预算范围" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">300-500元</SelectItem>
                <SelectItem value="medium">500-1000元</SelectItem>
                <SelectItem value="high">1000-2000元</SelectItem>
                <SelectItem value="premium">2000元以上</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="frequency">到店频次</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="选择到店频次" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="weekly">每周1次</SelectItem>
                <SelectItem value="biweekly">两周1次</SelectItem>
                <SelectItem value="monthly">每月1次</SelectItem>
                <SelectItem value="irregular">不定期</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="time-preference">偏好时段</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="选择偏好时段" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="morning">上午</SelectItem>
                <SelectItem value="afternoon">下午</SelectItem>
                <SelectItem value="evening">晚上</SelectItem>
                <SelectItem value="weekend">周末</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="promotion-sensitive">促销敏感度</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="选择促销敏感度" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="high">高敏感</SelectItem>
                <SelectItem value="medium">中等</SelectItem>
                <SelectItem value="low">不敏感</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </TabsContent>

      <TabsContent value="skin-info">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="skin-type">肌肤类型</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="选择肌肤类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="oily">油性</SelectItem>
                <SelectItem value="dry">干性</SelectItem>
                <SelectItem value="combination">混合性</SelectItem>
                <SelectItem value="sensitive">敏感性</SelectItem>
                <SelectItem value="normal">中性</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="skin-concerns">主要困扰</Label>
            <Input id="skin-concerns" placeholder="如：毛孔粗大、暗沉等" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="allergies">过敏史</Label>
            <Input id="allergies" placeholder="请输入已知过敏源" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sensitivity">敏感程度</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="选择敏感程度" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">低敏</SelectItem>
                <SelectItem value="medium">中敏</SelectItem>
                <SelectItem value="high">高敏</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2 space-y-2">
            <Label htmlFor="skin-goals">护理目标</Label>
            <Textarea id="skin-goals" placeholder="请描述希望改善的肌肤问题和护理目标" />
          </div>
        </div>
      </TabsContent>

      <div className="flex justify-end gap-2 mt-6">
        <Button variant="outline" onClick={() => setDialogOpen(false)}>
          取消
        </Button>
        <Button onClick={() => setDialogOpen(false)}>
          保存客户档案
        </Button>
      </div>
    </Tabs>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-medium mb-2">数据采集</h1>
          <p className="text-muted-foreground">
            全方位客户数据采集与画像构建，支撑精准营销与专业服务
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              添加客户
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>添加新客户档案</DialogTitle>
              <DialogDescription>
                创建新的客户档案，包括基础信息、消费偏好和肌肤档案，为精准服务提供数据支撑
              </DialogDescription>
            </DialogHeader>
            <AddCustomerForm />
          </DialogContent>
        </Dialog>
      </div>

      {/* 数据采集渠道概览 */}
      <Card>
        <CardHeader>
          <CardTitle>数据采集渠道</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {dataCollectionMethods.map((method) => (
              <div key={method.name} className="bg-muted rounded-lg px-[6px] py-[8px]">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium">{method.name}</h3>
                  <Badge variant="secondary">{method.status}</Badge>
                </div>
                <div className="flex justify-between items-baseline mb-1">
                  <div className="text-2xl font-bold text-primary">
                    {method.total}
                  </div>
                  <p className="text-xs text-muted-foreground">总数</p>
                </div>
                <p className="text-xs text-green-600 font-medium">最近14天新增 {method.recent14Days}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 客户画像数据管理 */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>客户画像数据管理</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                批量导入
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                数据导出
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="basic">基础信息</TabsTrigger>
              <TabsTrigger value="consumption-records">消费记录</TabsTrigger>
              <TabsTrigger value="consumption">消费行为画像</TabsTrigger>
              <TabsTrigger value="skin-health">肌肤健康画像</TabsTrigger>
            </TabsList>

            {/* 基础信息管理 */}
            <TabsContent value="basic" className="space-y-4">
              {/* 搜索和筛选 */}
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                  <Input
                    placeholder="搜索客户姓名或手机号..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  筛选
                </Button>
              </div>

              {/* 客户列表 */}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>姓名</TableHead>
                    <TableHead>手机号</TableHead>
                    <TableHead>年龄</TableHead>
                    <TableHead>最后到店</TableHead>
                    <TableHead>创建时间</TableHead>
                    <TableHead>服务项目</TableHead>
                    <TableHead>消费总额</TableHead>
                    <TableHead>来源</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockCustomers.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell className="font-medium">{customer.name}</TableCell>
                      <TableCell>{customer.phone}</TableCell>
                      <TableCell>{customer.age}岁</TableCell>
                      <TableCell>{customer.lastVisit}</TableCell>
                      <TableCell className="text-muted-foreground">{customer.createdAt}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {customer.services.map((service) => (
                            <Badge key={service} variant="outline" className="text-xs">
                              {service}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>¥{customer.totalSpent.toLocaleString()}</TableCell>
                      <TableCell>{customer.source}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm" onClick={() => handleViewCustomer(customer)}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            {/* 消费记录 */}
            <TabsContent value="consumption-records" className="space-y-4">
              <div className="mb-4">
                <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  消费记录
                </h3>
                <p className="text-sm text-muted-foreground">
                  详细记录客户每次消费的类型、内容、金额和支付方式，支撑精准的消费画像分析
                </p>
              </div>

              {/* 搜索和筛选 */}
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-1 relative">
                    <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                    <Input
                      placeholder="搜索客户姓名..."
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Button variant="outline" onClick={resetFilters}>
                    <Filter className="w-4 h-4 mr-2" />
                    重置筛选
                  </Button>
                </div>

                {/* 筛选条件 */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs">消费类型</Label>
                    <Select value={typeFilter} onValueChange={setTypeFilter}>
                      <SelectTrigger>
                        <SelectValue placeholder="全部类型" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部类型</SelectItem>
                        <SelectItem value="服务">服务</SelectItem>
                        <SelectItem value="产品">产品</SelectItem>
                        <SelectItem value="其他">其他</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">关联营销活动</Label>
                    <Select value={campaignFilter} onValueChange={setCampaignFilter}>
                      <SelectTrigger>
                        <SelectValue placeholder="全部活动" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部活动</SelectItem>
                        <SelectItem value="春季护肤套餐">春季护肤套餐</SelectItem>
                        <SelectItem value="网络专享">网络专享</SelectItem>
                        <SelectItem value="会员专享活动">会员专享活动</SelectItem>
                        <SelectItem value="新春特惠">新春特惠</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">支付方式</Label>
                    <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                      <SelectTrigger>
                        <SelectValue placeholder="全部方式" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部方式</SelectItem>
                        <SelectItem value="现金">现金</SelectItem>
                        <SelectItem value="线上">线上</SelectItem>
                        <SelectItem value="POS机">POS机</SelectItem>
                        <SelectItem value="充值卡">充值卡</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">是否首次到店</Label>
                    <Select value={firstVisitFilter} onValueChange={setFirstVisitFilter}>
                      <SelectTrigger>
                        <SelectValue placeholder="全部" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部</SelectItem>
                        <SelectItem value="是">是</SelectItem>
                        <SelectItem value="否">否</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">消费时间</Label>
                    <Select value={timeFilter} onValueChange={setTimeFilter}>
                      <SelectTrigger>
                        <SelectValue placeholder="全部时间" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部时间</SelectItem>
                        <SelectItem value="today">今天</SelectItem>
                        <SelectItem value="week">本周</SelectItem>
                        <SelectItem value="month">本月</SelectItem>
                        <SelectItem value="quarter">本季度</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* 消费记录列表 */}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>用户名称</TableHead>
                    <TableHead>消费类型</TableHead>
                    <TableHead>消费内容</TableHead>
                    <TableHead>消费金额</TableHead>
                    <TableHead>消费时间</TableHead>
                    <TableHead>支付方式</TableHead>
                    <TableHead>关联营销活动</TableHead>
                    <TableHead>是否首次到店</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">{record.customerName}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {record.consumptionType}
                        </Badge>
                      </TableCell>
                      <TableCell>{record.consumptionContent}</TableCell>
                      <TableCell>¥{record.amount.toLocaleString()}</TableCell>
                      <TableCell>{record.consumptionTime}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="text-xs">
                          {record.paymentMethod}
                        </Badge>
                      </TableCell>
                      <TableCell>{record.relatedCampaign}</TableCell>
                      <TableCell>
                        <Badge 
                          variant={record.isFirstVisit ? "destructive" : "default"}
                          className="text-xs"
                        >
                          {record.isFirstVisit ? '是' : '否'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" onClick={() => handleViewRecord(record)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            {/* 消费行为画像 */}
            <TabsContent value="consumption" className="space-y-4">
              <div className="mb-4">
                <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  消费行为画像
                </h3>
                <p className="text-sm text-muted-foreground">
                  基于消费数据分析客户的消费习惯、偏好和价值，提供个性化服务策略
                </p>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>客户姓名</TableHead>
                    <TableHead>消费等级</TableHead>
                    <TableHead>到店频次</TableHead>
                    <TableHead>平均消费</TableHead>
                    <TableHead>偏好服务</TableHead>
                    <TableHead>时间偏好</TableHead>
                    <TableHead>促销敏感度</TableHead>
                    <TableHead>复购率</TableHead>
                    <TableHead>忠诚度</TableHead>
                    <TableHead>季节趋势</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {consumptionBehaviors.map((behavior) => (
                    <TableRow key={behavior.id}>
                      <TableCell className="font-medium">{behavior.name}</TableCell>
                      <TableCell>
                        <Badge 
                          variant={behavior.level === '超高消费' ? 'default' : 
                                  behavior.level === '高消费' ? 'secondary' : 'outline'}
                          className="text-xs"
                        >
                          {behavior.level}
                        </Badge>
                      </TableCell>
                      <TableCell>{behavior.frequency}</TableCell>
                      <TableCell>¥{behavior.avgAmount}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {behavior.preferredServices.map((service) => (
                            <Badge key={service} variant="outline" className="text-xs">
                              {service}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>{behavior.timePattern}</TableCell>
                      <TableCell>
                        <Badge 
                          variant={behavior.promotionSensitive === '高' ? 'destructive' : 
                                  behavior.promotionSensitive === '中' ? 'secondary' : 'outline'}
                          className="text-xs"
                        >
                          {behavior.promotionSensitive}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={behavior.repurchaseRate} className="w-16" />
                          <span className="text-xs">{behavior.repurchaseRate}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={behavior.loyaltyScore} className="w-16" />
                          <span className="text-xs">{behavior.loyaltyScore}%</span>
                        </div>
                      </TableCell>
                      <TableCell>{behavior.seasonalTrend}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            {/* 肌肤健康画像 */}
            <TabsContent value="skin-health" className="space-y-4">
              <div className="mb-4">
                <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                  <Stethoscope className="w-5 h-5" />
                  肌肤健康画像
                </h3>
                <p className="text-sm text-muted-foreground">
                  详细记录客户肌肤状态、护理历史和改善目标，制定专业护理方案
                </p>
              </div>

              {/* 筛选控件 */}
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="搜索客户姓名..."
                      value={skinSearchTerm}
                      onChange={(e) => setSkinSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Select value={skinTypeFilter} onValueChange={setSkinTypeFilter}>
                    <SelectTrigger className="w-[120px]">
                      <SelectValue placeholder="肤质类型" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部肤质</SelectItem>
                      <SelectItem value="干性">干性</SelectItem>
                      <SelectItem value="油性">油性</SelectItem>
                      <SelectItem value="混合性">混合性</SelectItem>
                      <SelectItem value="敏感性">敏感性</SelectItem>
                      <SelectItem value="中性">中性</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={sensitivityFilter} onValueChange={setSensitivityFilter}>
                    <SelectTrigger className="w-[120px]">
                      <SelectValue placeholder="敏感程度" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部敏感度</SelectItem>
                      <SelectItem value="高敏">高敏</SelectItem>
                      <SelectItem value="中敏">中敏</SelectItem>
                      <SelectItem value="低敏">低敏</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={conditionFilter} onValueChange={setConditionFilter}>
                    <SelectTrigger className="w-[120px]">
                      <SelectValue placeholder="肌肤状态" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部状态</SelectItem>
                      <SelectItem value="良好">良好</SelectItem>
                      <SelectItem value="需改善">需改善</SelectItem>
                      <SelectItem value="需专业护理">需专业护理</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={testSourceFilter} onValueChange={setTestSourceFilter}>
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="检测来源" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部来源</SelectItem>
                      <SelectItem value="AI肌肤检测">AI肌肤检测</SelectItem>
                      <SelectItem value="肌肤检测仪">肌肤检测仪</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={resetSkinFilters}
                    className="whitespace-nowrap"
                  >
                    <Filter className="w-4 h-4 mr-2" />
                    重置筛选
                  </Button>
                </div>
              </div>

              {/* 列表显示 */}
              <div className="space-y-4">
                {filteredSkinProfiles.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">没有找到符合条件的客户画像</p>
                  </div>
                ) : (
                  filteredSkinProfiles.map((profile) => (
                    <Card key={profile.id} className="p-4">
                      <div className="flex flex-col lg:flex-row gap-4">
                        {/* 基本信息 */}
                        <div className="flex items-start gap-4 lg:w-1/4">
                          <div className="relative w-12 h-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                            <img 
                              src={skinAnalysisImage} 
                              alt="肌肤检测"
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-lg">{profile.name}</h4>
                            <div className="flex flex-wrap gap-1 mt-1">
                              <Badge variant="outline" className="text-xs">
                                {profile.skinType}肌肤
                              </Badge>
                              <Badge 
                                variant={profile.sensitivity === '高敏' ? 'destructive' : 
                                        profile.sensitivity === '中敏' ? 'secondary' : 'outline'}
                                className="text-xs"
                              >
                                {profile.sensitivity}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">色调: {profile.skinTone}</p>
                          </div>
                        </div>

                        {/* 详细信息 */}
                        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          <div>
                            <Label className="text-xs text-muted-foreground">主要困扰</Label>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {profile.concerns.slice(0, 3).map((concern) => (
                                <Badge key={concern} variant="secondary" className="text-xs">
                                  {concern}
                                </Badge>
                              ))}
                              {profile.concerns.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{profile.concerns.length - 3}
                                </Badge>
                              )}
                            </div>
                          </div>

                          <div>
                            <Label className="text-xs text-muted-foreground">肌肤状态</Label>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge 
                                variant={profile.skinCondition === '良好' ? 'default' : 'secondary'}
                                className="text-xs"
                              >
                                {profile.skinCondition}
                              </Badge>
                              {profile.skinCondition !== '良好' && (
                                <AlertTriangle className="w-4 h-4 text-yellow-500" />
                              )}
                            </div>
                          </div>

                          <div>
                            <Label className="text-xs text-muted-foreground">推荐护理</Label>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {profile.recommendedServices.slice(0, 2).map((service) => (
                                <Badge key={service} variant="default" className="text-xs">
                                  {service}
                                </Badge>
                              ))}
                              {profile.recommendedServices.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{profile.recommendedServices.length - 2}
                                </Badge>
                              )}
                            </div>
                          </div>

                          <div>
                            <Label className="text-xs text-muted-foreground">过敏史</Label>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {profile.allergies.slice(0, 2).map((allergy) => (
                                <Badge key={allergy} variant="outline" className="text-xs">
                                  {allergy}
                                </Badge>
                              ))}
                              {profile.allergies.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{profile.allergies.length - 2}
                                </Badge>
                              )}
                            </div>
                          </div>

                          <div>
                            <Label className="text-xs text-muted-foreground">改善目标</Label>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {profile.improvementGoals.slice(0, 2).map((goal) => (
                                <Badge key={goal} variant="outline" className="text-xs">
                                  {goal}
                                </Badge>
                              ))}
                              {profile.improvementGoals.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{profile.improvementGoals.length - 2}
                                </Badge>
                              )}
                            </div>
                          </div>

                          <div>
                            <Label className="text-xs text-muted-foreground">最近检测</Label>
                            <p className="text-sm">{profile.lastSkinTest}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge 
                                variant={profile.skinTestSource === 'AI肌肤检测' ? 'default' : 'secondary'} 
                                className="text-xs"
                              >
                                {profile.skinTestSource || 'AI肌肤检测'}
                              </Badge>
                            </div>
                          </div>
                        </div>

                        {/* 操作按钮 */}
                        <div className="lg:w-auto flex lg:flex-col gap-2">
                          <Button variant="outline" size="sm" className="flex-1 lg:flex-none">
                            <Eye className="w-4 h-4 mr-2" />
                            查看详情
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1 lg:flex-none">
                            <Edit className="w-4 h-4 mr-2" />
                            编辑
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* 客户详情弹窗 */}
      <Dialog open={customerDetailOpen} onOpenChange={setCustomerDetailOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>客户详情</DialogTitle>
            <DialogDescription>
              查看客户的完整档案信息，包括基础信息、消费记录和肌肤档案
            </DialogDescription>
          </DialogHeader>
          {selectedCustomer && (
            <div className="space-y-6">
              {/* 基础信息 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">基础信息</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>姓名</Label>
                      <p className="text-sm font-medium">{selectedCustomer.name}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>手机号</Label>
                      <p className="text-sm font-medium">{selectedCustomer.phone}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>年龄</Label>
                      <p className="text-sm font-medium">{selectedCustomer.age}岁</p>
                    </div>
                    <div className="space-y-2">
                      <Label>性别</Label>
                      <p className="text-sm font-medium">{selectedCustomer.gender}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>最后到店</Label>
                      <p className="text-sm font-medium">{selectedCustomer.lastVisit}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>创建时间</Label>
                      <p className="text-sm font-medium text-muted-foreground">{selectedCustomer.createdAt}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>消费总额</Label>
                      <p className="text-sm font-medium text-green-600">¥{selectedCustomer.totalSpent.toLocaleString()}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>客户来源</Label>
                      <p className="text-sm font-medium">{selectedCustomer.source}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>服务项目</Label>
                      <div className="flex gap-1">
                        {selectedCustomer.services.map((service) => (
                          <Badge key={service} variant="outline" className="text-xs">
                            {service}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 消费分析 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">消费分析</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label>到店频次</Label>
                      <p className="text-sm font-medium">{selectedCustomer.visitFrequency}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>平均消费</Label>
                      <p className="text-sm font-medium">¥{selectedCustomer.avgSpending}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>肌肤类型</Label>
                      <p className="text-sm font-medium">{selectedCustomer.skinType}</p>
                    </div>
                    <div className="space-y-2">
                      <Label>主要困扰</Label>
                      <div className="flex flex-wrap gap-1">
                        {selectedCustomer.concerns.map((concern) => (
                          <Badge key={concern} variant="secondary" className="text-xs">
                            {concern}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* 消费记录详情弹窗 */}
      <Dialog open={recordDetailOpen} onOpenChange={setRecordDetailOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>消费记录详情</DialogTitle>
            <DialogDescription>
              查看客户的单次消费详细信息
            </DialogDescription>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>客户姓名</Label>
                  <p className="text-sm font-medium">{selectedRecord.customerName}</p>
                </div>
                <div className="space-y-2">
                  <Label>消费类型</Label>
                  <Badge variant="outline" className="text-xs">
                    {selectedRecord.consumptionType}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <Label>消费内容</Label>
                  <p className="text-sm font-medium">{selectedRecord.consumptionContent}</p>
                </div>
                <div className="space-y-2">
                  <Label>消费金额</Label>
                  <p className="text-sm font-medium text-green-600">¥{selectedRecord.amount.toLocaleString()}</p>
                </div>
                <div className="space-y-2">
                  <Label>消费时间</Label>
                  <p className="text-sm font-medium">{selectedRecord.consumptionTime}</p>
                </div>
                <div className="space-y-2">
                  <Label>支付方式</Label>
                  <Badge variant="secondary" className="text-xs">
                    {selectedRecord.paymentMethod}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <Label>关联营销活动</Label>
                  <p className="text-sm font-medium">{selectedRecord.relatedCampaign}</p>
                </div>
                <div className="space-y-2">
                  <Label>是否首次到店</Label>
                  <Badge 
                    variant={selectedRecord.isFirstVisit ? "destructive" : "default"}
                    className="text-xs"
                  >
                    {selectedRecord.isFirstVisit ? '是' : '否'}
                  </Badge>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}