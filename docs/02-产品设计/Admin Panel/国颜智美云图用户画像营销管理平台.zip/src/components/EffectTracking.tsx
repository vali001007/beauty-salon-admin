import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Target, 
  Calendar,
  Download,
  RefreshCw,
  BarChart3,
  PieChart,
  LineChart
} from 'lucide-react';
import { 
  LineChart as RechartsLineChart, 
  Line,
  BarChart,
  Bar,
  Area,
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

const performanceMetrics = [
  {
    title: '营销ROI',
    value: '267%',
    change: '+15.3%',
    trend: 'up',
    description: '每投入1元获得2.67元回报',
  },
  {
    title: '客户获取成本',
    value: '¥156',
    change: '-8.2%',
    trend: 'up',
    description: '获得一个新客户的平均成本',
  },
  {
    title: '客户生命周期价值',
    value: '¥4,280',
    change: '+12.5%',
    trend: 'up',
    description: '单个客户的预期总价值',
  },
  {
    title: '活动转化率',
    value: '21.2%',
    change: '+3.5%',
    trend: 'up',
    description: '营销活动的平均转化率',
  },
];

const campaignPerformance = [
  {
    name: '春季护肤套餐',
    status: '进行中',
    budget: 15000,
    spent: 8500,
    revenue: 45680,
    roi: 437,
    conversions: 156,
    conversionRate: 24.5,
    cpa: 54,
  },
  {
    name: '新客体验优惠',
    status: '进行中',
    budget: 8000,
    spent: 3200,
    revenue: 12340,
    roi: 286,
    conversions: 78,
    conversionRate: 18.2,
    cpa: 41,
  },
  {
    name: '会员专享活动',
    status: '已完成',
    budget: 12000,
    spent: 11500,
    revenue: 28900,
    roi: 151,
    conversions: 92,
    conversionRate: 15.8,
    cpa: 125,
  },
];

const channelPerformance = [
  { name: '微信小程序', cost: 12500, conversions: 245, revenue: 56780, roi: 354 },
  { name: '朋友圈广告', cost: 8900, conversions: 156, revenue: 34560, roi: 288 },
  { name: '线下推广', cost: 6700, conversions: 89, revenue: 23400, roi: 249 },
  { name: '短信营销', cost: 3200, conversions: 67, revenue: 15680, roi: 390 },
  { name: '邮件营销', cost: 1800, conversions: 34, revenue: 8900, roi: 394 },
];

const customerJourney = [
  { stage: '认知', visitors: 5230, rate: 100, color: 'bg-blue-500' },
  { stage: '兴趣', visitors: 2845, rate: 54, color: 'bg-green-500' },
  { stage: '考虑', visitors: 1567, rate: 30, color: 'bg-yellow-500' },
  { stage: '购买', visitors: 684, rate: 13, color: 'bg-purple-500' },
  { stage: '复购', visitors: 289, rate: 6, color: 'bg-red-500' },
];

export function EffectTracking() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-medium mb-2">效果追踪</h1>
          <p className="text-muted-foreground">
            实时监控营销活动效果，优化投放策略
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            刷新数据
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            导出报告
          </Button>
        </div>
      </div>

      {/* 关键指标 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {performanceMetrics.map((metric) => {
          const TrendIcon = metric.trend === 'up' ? TrendingUp : TrendingDown;
          return (
            <Card key={metric.title}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">{metric.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-1">{metric.value}</div>
                <div className="flex items-center text-xs mb-2">
                  <TrendIcon className={`h-3 w-3 mr-1 ${
                    metric.trend === 'up' ? 'text-green-500' : 'text-red-500'
                  }`} />
                  <span className={
                    metric.trend === 'up' ? 'text-green-500' : 'text-red-500'
                  }>
                    {metric.change}
                  </span>
                  <span className="ml-1 text-muted-foreground">较上月</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {metric.description}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="campaigns" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="campaigns">活动效果</TabsTrigger>
          <TabsTrigger value="channels">渠道分析</TabsTrigger>
          <TabsTrigger value="journey">客户旅程</TabsTrigger>
          <TabsTrigger value="trends">趋势分析</TabsTrigger>
        </TabsList>

        {/* 活动效果 */}
        <TabsContent value="campaigns" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>活动效果对比</CardTitle>
                <Select defaultValue="all">
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部活动</SelectItem>
                    <SelectItem value="active">进行中</SelectItem>
                    <SelectItem value="completed">已完成</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {campaignPerformance.map((campaign, index) => {
                  // 根据索引选择不同的渐变背景
                  const gradients = [
                    'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 border border-blue-200/50',
                    'bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 border border-emerald-200/50',
                    'bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 border border-orange-200/50',
                    'bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 border border-pink-200/50',
                  ];
                  const labelColors = [
                    'text-indigo-700',
                    'text-teal-700',
                    'text-amber-700',
                    'text-rose-700',
                  ];
                  const gradient = gradients[index % gradients.length];
                  const labelColor = labelColors[index % labelColors.length];
                  
                  return (
                    <div key={campaign.name} className={`p-4 rounded-lg ${gradient}`}>
                      <div className="flex justify-between items-center mb-3">
                        <div>
                          <h3 className="font-medium">{campaign.name}</h3>
                          <Badge variant={campaign.status === '进行中' ? 'default' : 'secondary'}>
                            {campaign.status}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-green-600">
                            ROI: {campaign.roi}%
                          </p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className={labelColor}>预算使用</p>
                          <p className="font-medium">
                            ¥{campaign.spent.toLocaleString()} / ¥{campaign.budget.toLocaleString()}
                          </p>
                          <Progress 
                            value={(campaign.spent / campaign.budget) * 100} 
                            className="h-1 mt-1" 
                          />
                        </div>
                        <div>
                          <p className={labelColor}>转化数</p>
                          <p className="font-medium">{campaign.conversions}</p>
                          <p className="text-xs text-green-600">
                            转化率: {campaign.conversionRate}%
                          </p>
                        </div>
                        <div>
                          <p className={labelColor}>获客成本</p>
                          <p className="font-medium">¥{campaign.cpa}</p>
                        </div>
                        <div>
                          <p className={labelColor}>营收</p>
                          <p className="font-medium">¥{campaign.revenue.toLocaleString()}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 渠道分析 */}
        <TabsContent value="channels" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>渠道表现分析</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {channelPerformance.map((channel) => (
                  <div key={channel.name} className="p-4 bg-muted rounded-lg">
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="font-medium">{channel.name}</h3>
                      <Badge variant="outline">ROI: {channel.roi}%</Badge>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">投入成本</p>
                        <p className="font-medium">¥{channel.cost.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">转化数</p>
                        <p className="font-medium">{channel.conversions}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">营收</p>
                        <p className="font-medium">¥{channel.revenue.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">每转化成本</p>
                        <p className="font-medium">¥{Math.round(channel.cost / channel.conversions)}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 客户旅程 */}
        <TabsContent value="journey" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>客户转化漏斗</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {customerJourney.map((stage, index) => (
                  <div key={stage.stage} className="relative">
                    <div className="flex items-center gap-4">
                      <div className="w-16 text-center">
                        <div className={`w-3 h-3 rounded-full ${stage.color} mx-auto mb-1`} />
                        <p className="text-xs font-medium">{stage.stage}</p>
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-medium">{stage.visitors.toLocaleString()} 人</span>
                          <span className="text-sm text-muted-foreground">{stage.rate}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${stage.color}`}
                            style={{ width: `${stage.rate}%` }}
                          />
                        </div>
                      </div>
                    </div>
                    {index < customerJourney.length - 1 && (
                      <div className="absolute left-7 top-8 w-px h-4 bg-gray-300" />
                    )}
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-medium mb-2">转化洞察</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">总体转化率</p>
                    <p className="font-bold text-lg">13.1%</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">最大流失阶段</p>
                    <p className="font-bold text-lg">认知→兴趣</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">复购率</p>
                    <p className="font-bold text-lg">42.3%</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 趋势分析 */}
        <TabsContent value="trends" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="w-5 h-5" />
                  ROI趋势
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl border border-blue-100">
                    <div className="mb-4">
                      <h4 className="text-sm text-blue-900">ROI趋势</h4>
                      <p className="text-xs text-blue-700">最近6个月的投资回报率变化</p>
                    </div>
                    <ResponsiveContainer width="100%" height={200}>
                      <RechartsLineChart data={[
                        { month: '8月', roi: 2.3 },
                        { month: '9月', roi: 2.8 },
                        { month: '10月', roi: 3.2 },
                        { month: '11月', roi: 2.9 },
                        { month: '12月', roi: 3.5 },
                        { month: '1月', roi: 4.2 },
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0f2fe" />
                        <XAxis 
                          dataKey="month" 
                          stroke="#0c4a6e"
                          fontSize={12}
                          tickLine={false}
                        />
                        <YAxis 
                          stroke="#0c4a6e"
                          fontSize={12}
                          tickFormatter={(value) => `${value}x`}
                          tickLine={false}
                        />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: '#ffffff',
                            border: '1px solid #0ea5e9',
                            borderRadius: '8px',
                            boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                          }}
                          formatter={(value: number) => [`${value}x`, 'ROI']}
                        />
                        <defs>
                          <linearGradient id="colorRoi" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <Area 
                          type="monotone" 
                          dataKey="roi" 
                          stroke="#0ea5e9" 
                          fill="url(#colorRoi)" 
                          strokeWidth={3}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="roi" 
                          stroke="#0ea5e9" 
                          strokeWidth={3}
                          dot={{ fill: '#0ea5e9', strokeWidth: 2, stroke: '#ffffff', r: 5 }}
                          activeDot={{ r: 7, fill: '#0284c7', stroke: '#ffffff', strokeWidth: 2 }}
                        />
                      </RechartsLineChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-sm">
                    <div>
                      <p className="text-blue-700">本月</p>
                      <p className="font-bold text-blue-900">267%</p>
                    </div>
                    <div>
                      <p className="text-blue-700">上月</p>
                      <p className="font-bold text-blue-900">234%</p>
                    </div>
                    <div>
                      <p className="text-blue-700">平均</p>
                      <p className="font-bold text-blue-900">245%</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  转化率趋势
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border border-purple-100">
                    <div className="mb-4">
                      <h4 className="text-sm text-purple-900">转化率对比</h4>
                      <p className="text-xs text-purple-700">各渠道转化率表现</p>
                    </div>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={[
                        { channel: '小程序', rate: 24.5, fill: '#8b5cf6' },
                        { channel: '朋友圈', rate: 18.2, fill: '#ec4899' },
                        { channel: '公众号', rate: 15.8, fill: '#f59e0b' },
                        { channel: '视频号', rate: 12.3, fill: '#10b981' },
                        { channel: '线下', rate: 32.6, fill: '#6366f1' },
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#fae8ff" />
                        <XAxis 
                          dataKey="channel" 
                          stroke="#581c87"
                          fontSize={12}
                          tickLine={false}
                        />
                        <YAxis 
                          stroke="#581c87"
                          fontSize={12}
                          tickFormatter={(value) => `${value}%`}
                          tickLine={false}
                        />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: '#ffffff',
                            border: '1px solid #a855f7',
                            borderRadius: '8px',
                            boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                          }}
                          formatter={(value: number) => [`${value}%`, '转化率']}
                        />
                        <Bar 
                          dataKey="rate" 
                          radius={[6, 6, 0, 0]}
                        >
                          {[
                            { channel: '小程序', rate: 24.5, fill: '#8b5cf6' },
                            { channel: '朋友圈', rate: 18.2, fill: '#ec4899' },
                            { channel: '公众号', rate: 15.8, fill: '#f59e0b' },
                            { channel: '视频号', rate: 12.3, fill: '#10b981' },
                            { channel: '线下', rate: 32.6, fill: '#6366f1' },
                          ].map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-purple-900">微信小程序</span>
                      <span className="text-green-600">↑ 2.3%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-purple-900">朋友圈广告</span>
                      <span className="text-green-600">↑ 1.8%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-purple-900">线下推广</span>
                      <span className="text-red-600">↓ 0.5%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>数据洞察与建议</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <h4 className="font-medium text-green-800 mb-2">📈 优势渠道</h4>
                  <p className="text-sm text-green-700">
                    微信小程序和短信营销表现优异，建议加大投入。ROI超过350%，转化成本低于行业平均水平。
                  </p>
                </div>
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h4 className="font-medium text-yellow-800 mb-2">⚠️ 需要优化</h4>
                  <p className="text-sm text-yellow-700">
                    线下推广转化率有所下降，建议优化推广内容和目标客群定位，或考虑调整推广时间和地点。
                  </p>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="font-medium text-blue-800 mb-2">💡 策略建议</h4>
                  <p className="text-sm text-blue-700">
                    客户在"认知"到"兴趣"阶段流失最多，建议优化首次接触体验，增加个性化内容推荐。
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}