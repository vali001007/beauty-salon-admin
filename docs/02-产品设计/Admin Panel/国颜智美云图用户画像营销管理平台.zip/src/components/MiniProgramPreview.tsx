import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { useCampaigns } from '../App';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Eye, 
  Edit, 
  Play, 
  Pause, 
  Smartphone, 
  Settings, 
  X,
  Wifi,
  Battery,
  Signal,
  MoreHorizontal,
  Share2
} from 'lucide-react';

interface MiniProgramPreviewProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MiniProgramPreview({ open, onOpenChange }: MiniProgramPreviewProps) {
  const { publishedCampaigns } = useCampaigns();
  const getCurrentTime = () => {
    const now = new Date();
    return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="max-w-none p-0 bg-transparent border-none shadow-none"
        aria-describedby="miniprogram-preview-description"
      >
        <DialogHeader className="sr-only">
          <DialogTitle>小程序活动预览</DialogTitle>
          <DialogDescription id="miniprogram-preview-description">
            预览营销活动在微信小程序中的显示效果
          </DialogDescription>
        </DialogHeader>
        
        {/* iPhone 16 尺寸容器 - 比例约为 9:19.5 */}
        <div className="relative mx-auto bg-black rounded-[2.5rem] p-2 shadow-2xl" style={{ width: '375px', height: '812px' }}>
          {/* 手机外壳装饰 */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-32 h-6 bg-black rounded-b-2xl"></div>
          
          {/* 手机屏幕 */}
          <div className="w-full h-full bg-white rounded-[2rem] overflow-hidden flex flex-col">
            {/* 状态栏 */}
            <div className="bg-black text-white px-6 py-2 flex justify-between items-center text-sm font-medium">
              <div className="flex items-center gap-1">
                <Signal className="w-4 h-4" />
                <Wifi className="w-4 h-4" />
              </div>
              <div className="text-center flex-1 font-semibold">{getCurrentTime()}</div>
              <div className="flex items-center gap-1">
                <span>100%</span>
                <Battery className="w-4 h-4 fill-white" />
              </div>
            </div>

            {/* 微信小程序导航栏 */}
            <div className="bg-white border-b px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-lg">✨</span>
                </div>
                <div>
                  <h3 className="text-base font-medium text-gray-900">雅敏美容沙龙</h3>
                  <p className="text-sm text-gray-500">专业美容护肤</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 rounded-full"
                  onClick={() => onOpenChange(false)}
                  aria-label="关闭预览"
                >
                  <X className="w-4 h-4 text-gray-400" />
                </Button>
              </div>
            </div>

            {/* 小程序内容区域 - 可滚动 */}
            <div className="flex-1 bg-gray-50 overflow-y-auto">
              {/* 功能按钮区域 */}
              <div className="p-4">
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="bg-white rounded-2xl p-4 shadow-sm text-center">
                    <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-2">
                      <Eye className="w-6 h-6 text-purple-600" />
                    </div>
                    <span className="text-sm font-medium text-gray-700">皮肤检测</span>
                  </div>
                  <div className="bg-white rounded-2xl p-4 shadow-sm text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-2">
                      <Settings className="w-6 h-6 text-blue-600" />
                    </div>
                    <span className="text-sm font-medium text-gray-700">护肤知识</span>
                  </div>
                  <div className="bg-white rounded-2xl p-4 shadow-sm text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-2">
                      <Smartphone className="w-6 h-6 text-green-600" />
                    </div>
                    <span className="text-sm font-medium text-gray-700">服务咨询</span>
                  </div>
                </div>
              </div>

              {/* AI皮肤检测卡片 */}
              <div className="px-4 mb-6">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold mb-1">AI皮肤检测</h3>
                      <p className="text-sm opacity-90">上传照片，获得专业肌肤分析报告</p>
                    </div>
                    <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30 rounded-full px-6">
                      上传
                    </Button>
                  </div>
                </div>
              </div>

              {/* 活动列表 */}
              <div className="px-4 space-y-4">
                <h4 className="text-lg font-semibold text-gray-900 mb-3">精选活动</h4>
                
                {publishedCampaigns.map((campaign) => (
                  <div key={campaign.id} className="bg-white rounded-3xl shadow-sm overflow-hidden">
                    {/* 活动图片区域 */}
                    <div className="h-40 bg-gradient-to-br from-purple-100 via-pink-50 to-blue-100 relative">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <div className="text-4xl mb-2">✨</div>
                          <p className="text-lg font-medium text-gray-700">{campaign.name}</p>
                        </div>
                      </div>
                      <div className="absolute top-4 right-4">
                        <Badge 
                          variant={campaign.tag === '限时' ? 'destructive' : 'default'} 
                          className="text-xs font-medium"
                        >
                          {campaign.tag || campaign.status}
                        </Badge>
                      </div>
                      {campaign.originalPrice && campaign.currentPrice && (
                        <div className="absolute bottom-4 left-4">
                          <div className="bg-white/90 backdrop-blur-sm rounded-xl px-3 py-2">
                            <div className="flex items-center gap-2">
                              <span className="text-xl font-bold text-red-500">¥{campaign.currentPrice}</span>
                              <span className="text-sm text-gray-500 line-through">¥{campaign.originalPrice}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* 活动信息 */}
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        <h5 className="text-lg font-semibold text-gray-900">{campaign.name}</h5>
                        <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded-full">{campaign.type}</span>
                      </div>

                      <p className="text-sm text-gray-600 mb-4 line-clamp-2">{campaign.description}</p>

                      {/* 活动数据 */}
                      <div className="grid grid-cols-3 gap-3 mb-4">
                        <div className="text-center">
                          <p className="text-lg font-bold text-blue-600">{campaign.reach}</p>
                          <p className="text-xs text-gray-500">已参与</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg font-bold text-green-600">{campaign.conversion}%</p>
                          <p className="text-xs text-gray-500">满意度</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg font-bold text-orange-600">
                            {campaign.endDate ? `${Math.ceil((new Date(campaign.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}天` : '长期'}
                          </p>
                          <p className="text-xs text-gray-500">剩余时间</p>
                        </div>
                      </div>

                      {/* 参与按钮 */}
                      <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-2xl h-12 text-base font-medium">
                        立即预约体验
                      </Button>
                    </div>
                  </div>
                ))}

                {/* 如果没有发布到小程序的活动 */}
                {publishedCampaigns.length === 0 && (
                  <div className="bg-white rounded-3xl p-8 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Smartphone className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-gray-500 font-medium mb-1">暂无活动</p>
                    <p className="text-gray-400 text-sm">敬请期待更多精彩活动</p>
                  </div>
                )}
              </div>

              {/* 底部间距 */}
              <div className="h-20"></div>
            </div>

            {/* 小程序底部导航栏 */}
            <div className="bg-white border-t border-gray-100 safe-area-bottom">
              <div className="grid grid-cols-4">
                <div className="text-center py-2">
                  <div className="w-6 h-6 bg-purple-600 rounded-lg mx-auto mb-1 flex items-center justify-center">
                    <div className="w-3 h-3 bg-white rounded-sm"></div>
                  </div>
                  <span className="text-xs text-purple-600 font-medium">首页</span>
                </div>
                <div className="text-center py-2">
                  <div className="w-6 h-6 bg-gray-200 rounded-lg mx-auto mb-1 flex items-center justify-center">
                    <div className="w-3 h-3 bg-gray-500 rounded-sm"></div>
                  </div>
                  <span className="text-xs text-gray-500">预约</span>
                </div>
                <div className="text-center py-2">
                  <div className="w-6 h-6 bg-gray-200 rounded-lg mx-auto mb-1 flex items-center justify-center">
                    <div className="w-3 h-3 bg-gray-500 rounded-sm"></div>
                  </div>
                  <span className="text-xs text-gray-500">AI助理</span>
                </div>
                <div className="text-center py-2">
                  <div className="w-6 h-6 bg-gray-200 rounded-lg mx-auto mb-1 flex items-center justify-center">
                    <div className="w-3 h-3 bg-gray-500 rounded-sm"></div>
                  </div>
                  <span className="text-xs text-gray-500">我的</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}