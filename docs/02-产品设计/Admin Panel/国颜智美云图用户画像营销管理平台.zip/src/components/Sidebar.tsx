import { 
  BarChart3, 
  Database, 
  Users, 
  Target, 
  TrendingUp,
  Sparkles,
  PenTool,
  Store,
  FolderOpen
} from 'lucide-react';
import { cn } from './ui/utils';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const menuItems = [
  {
    id: 'dashboard',
    label: '仪表板',
    icon: BarChart3,
  },
  {
    id: 'data-collection',
    label: '数据采集',
    icon: Database,
  },
  {
    id: 'user-profile',
    label: '用户画像',
    icon: Users,
  },
  {
    id: 'marketing-strategy',
    label: '营销策略',
    icon: Target,
  },
  {
    id: 'marketing-copywriter',
    label: '文案生成',
    icon: PenTool,
  },
  {
    id: 'effect-tracking',
    label: '效果追踪',
    icon: TrendingUp,
  },
  {
    id: 'store-configuration',
    label: '网店配置',
    icon: Store,
  },
  {
    id: 'marketing-materials',
    label: '营销材料',
    icon: FolderOpen,
  },
];

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <div className="w-64 bg-card border-r border-border">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <Sparkles className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-lg font-medium">智美云图</h1>
            <p className="text-sm text-muted-foreground">用户画像营销管理平台</p>
          </div>
        </div>
        
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors",
                  activeTab === item.id
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-accent text-foreground"
                )}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}