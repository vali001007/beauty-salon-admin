import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Users, 
  Target, 
  TrendingUp, 
  Heart,
  Handshake,
  Zap,
  Database,
  Gift,
  Phone,
  Globe,
  DollarSign,
  Settings,
  Lightbulb,
  Building2,
  Smartphone,
  Cloud,
  Brain,
  PieChart,
  Calculator,
  ArrowRight,
  CheckCircle,
  Star,
  Megaphone,
  Shield,
  Sparkles
} from 'lucide-react';

export function BusinessCanvas() {
  const [activeView, setActiveView] = useState('canvas');

  // 商业画布的9个构建块
  const canvasBlocks = {
    keyPartnerships: {
      title: '关键合作伙伴',
      icon: Handshake,
      color: 'bg-blue-50 border-blue-200',
      items: [
        {
          category: '技术合作伙伴',
          partners: [
            '腾讯云 - 云计算基础设施',
            '腾讯广告 - 广告投放平台',
            '微信生态 - 小程序发布',
            'OpenAI - AI技术服务'
          ]
        },
        {
          category: '行业合作伙伴',
          partners: [
            '美容院协会 - 行业资源',
            '化妆品供应商 - 产品合作',
            '美容设备厂商 - 设备集成',
            '培训机构 - 人才培养'
          ]
        },
        {
          category: '渠道合作伙伴',
          partners: [
            '系统集成商 - 实施服务',
            '代理商 - 销售渠道',
            '咨询公司 - 解决方案'
          ]
        }
      ]
    },
    keyActivities: {
      title: '关键活动',
      icon: Zap,
      color: 'bg-green-50 border-green-200',
      items: [
        {
          category: '产品开发',
          activities: [
            'AI算法研发和优化',
            '平台功能迭代升级',
            '用户体验设计优化',
            '数据安全和隐私保护'
          ]
        },
        {
          category: '运营服务',
          activities: [
            '客户成功服务',
            '技术支持和维护',
            '培训和咨询服务',
            '数据分析和洞察'
          ]
        },
        {
          category: '市场推广',
          activities: [
            '品牌建设和推广',
            '行业会议和展览',
            '内容营销和教育',
            '合作伙伴关系维护'
          ]
        }
      ]
    },
    keyResources: {
      title: '关键资源',
      icon: Database,
      color: 'bg-purple-50 border-purple-200',
      items: [
        {
          category: '技术资源',
          resources: [
            'AI算法和模型库',
            '大数据处理平台',
            '云计算基础设施',
            '安全防护体系'
          ]
        },
        {
          category: '人力资源',
          resources: [
            'AI算法工程师团队',
            '产品设计和开发团队',
            '数据科学家团队',
            '客户成功团队'
          ]
        },
        {
          category: '数据资源',
          resources: [
            '美容行业数据库',
            '用户行为数据',
            '营销效果数据',
            '市场趋势数据'
          ]
        },
        {
          category: '知识产权',
          resources: [
            '核心算法专利',
            '软件著作权',
            '商标和品牌',
            '技术标准和规范'
          ]
        }
      ]
    },
    valuePropositions: {
      title: '价值主张',
      icon: Gift,
      color: 'bg-orange-50 border-orange-200',
      items: [
        {
          category: '核心价值',
          values: [
            '数据驱动的精准营销',
            'AI智能化客户画像',
            '全链路营销闭环',
            '显著提升ROI'
          ]
        },
        {
          category: '差异化优势',
          values: [
            '美容行业专业化',
            '小程序无缝集成',
            '腾讯生态深度融合',
            'SaaS化部署简单'
          ]
        },
        {
          category: '客户收益',
          values: [
            '降低营销成本30%+',
            '提升客户转化率50%+',
            '增加客户生命价值',
            '优化运营效率'
          ]
        }
      ]
    },
    customerRelationships: {
      title: '客户关系',
      icon: Heart,
      color: 'bg-pink-50 border-pink-200',
      items: [
        {
          category: '获客阶段',
          relationships: [
            '免费试用体验',
            '产品演示和咨询',
            '行业案例分享',
            '技术交流会议'
          ]
        },
        {
          category: '服务阶段',
          relationships: [
            '专属客户成功经理',
            '7×24小时技术支持',
            '定期业务回顾',
            '最佳实践培训'
          ]
        },
        {
          category: '发展阶段',
          relationships: [
            '产品功能定制',
            '行业解决方案',
            '战略合作伙伴',
            '用户社区建设'
          ]
        }
      ]
    },
    channels: {
      title: '渠道通路',
      icon: Megaphone,
      color: 'bg-teal-50 border-teal-200',
      items: [
        {
          category: '直接渠道',
          channels: [
            '官方网站和在线平台',
            '销售团队直销',
            '客户推荐和转介',
            '行业展会和活动'
          ]
        },
        {
          category: '间接渠道',
          channels: [
            '合作伙伴代理销售',
            '系统集成商推荐',
            '行业协会合作',
            '第三方平台入驻'
          ]
        },
        {
          category: '数字渠道',
          channels: [
            '搜索引擎营销',
            '社交媒体推广',
            '内容营销平台',
            '在线广告投放'
          ]
        }
      ]
    },
    customerSegments: {
      title: '客户细分',
      icon: Users,
      color: 'bg-indigo-50 border-indigo-200',
      items: [
        {
          category: '按规模分类',
          segments: [
            '大型连锁美容院 (20+门店)',
            '中型美容院 (5-20门店)',
            '小型独立美容院 (1-5门店)',
            '个人工作室'
          ]
        },
        {
          category: '按需求分类',
          segments: [
            '数字化转型驱动型',
            '营销效果提升型',
            '客户管理优化型',
            '成本控制导向型'
          ]
        },
        {
          category: '按地域分类',
          segments: [
            '一线城市高端市场',
            '二三线城市成长市场',
            '下沉市场潜力客户',
            '海外市场拓展'
          ]
        }
      ]
    },
    costStructure: {
      title: '成本结构',
      icon: Calculator,
      color: 'bg-red-50 border-red-200',
      items: [
        {
          category: '研发成本 (40%)',
          costs: [
            'AI算法研发投入',
            '产品开发人员薪酬',
            '技术基础设施建设',
            '数据采购和处理'
          ]
        },
        {
          category: '销售成本 (25%)',
          costs: [
            '销售团队薪酬提成',
            '市场推广和广告',
            '渠道合作伙伴费用',
            '客户获取成本'
          ]
        },
        {
          category: '运营成本 (20%)',
          costs: [
            '云服务和基础设施',
            '客服和技术支持',
            '办公和管理费用',
            '法务和合规成本'
          ]
        },
        {
          category: '其他成本 (15%)',
          costs: [
            '财务和税务成本',
            '保险和风险管理',
            '培训和人才发展',
            '战略投资和并购'
          ]
        }
      ]
    },
    revenueStreams: {
      title: '收入来源',
      icon: DollarSign,
      color: 'bg-yellow-50 border-yellow-200',
      items: [
        {
          category: '订阅收入 (60%)',
          revenue: [
            '基础版月度订阅 ¥999/月',
            '专业版月度订阅 ¥2999/月',
            '企业版年度订阅 ¥59999/年',
            '定制版按需报价'
          ]
        },
        {
          category: '增值服务 (25%)',
          revenue: [
            '数据分析咨询服务',
            '营销策略制定服务',
            '员工培训服务',
            '系统集成实施服务'
          ]
        },
        {
          category: '交易佣金 (10%)',
          revenue: [
            '广告投放平台佣金',
            '第三方服务佣金',
            '产品销售分成',
            '会员卡销售提成'
          ]
        },
        {
          category: '其他收入 (5%)',
          revenue: [
            '数据授权许可费',
            '技术输出许可费',
            '行业报告销售',
            '认证培训收费'
          ]
        }
      ]
    }
  };

  // SWOT分析
  const swotAnalysis = {
    strengths: [
      { text: 'AI技术领先优势', icon: Brain },
      { text: '美容行业深度理解', icon: Heart },
      { text: '腾讯生态深度集成', icon: Cloud },
      { text: '全链路解决方案', icon: Zap },
      { text: '数据驱动决策能力', icon: TrendingUp },
      { text: '快速迭代开发能力', icon: Settings }
    ],
    weaknesses: [
      { text: '品牌知名度有待提升', icon: Megaphone },
      { text: '客户教育成本较高', icon: Lightbulb },
      { text: '依赖第三方平台风险', icon: Shield },
      { text: '行业监管政策变化', icon: Building2 }
    ],
    opportunities: [
      { text: '美容行业数字化转型', icon: Smartphone },
      { text: '消费升级推动需求', icon: TrendingUp },
      { text: 'AI技术成本持续下降', icon: Calculator },
      { text: '政策支持数字经济', icon: CheckCircle },
      { text: '下沉市场潜力巨大', icon: Globe },
      { text: '国际市场拓展机会', icon: Star }
    ],
    threats: [
      { text: '大厂技术平台竞争', icon: Building2 },
      { text: '传统软件商转型', icon: Settings },
      { text: '数据安全和隐私监管', icon: Shield },
      { text: '经济周期影响投入', icon: DollarSign }
    ]
  };

  // 商业模式创新点
  const innovations = [
    {
      title: 'AI驱动的用户画像',
      description: '基于多维度数据构建精准的客户画像，实现个性化营销',
      impact: '营销转化率提升50%+',
      icon: Brain,
      color: 'text-purple-600'
    },
    {
      title: '全链路营销闭环',
      description: '从数据采集到效果追踪的完整营销链条，形成业务闭环',
      impact: 'ROI提升30%+',
      icon: Target,
      color: 'text-blue-600'
    },
    {
      title: '小程序无缝集成',
      description: '一键发布到微信小程序，连接线上线下业务场景',
      impact: '客户触达率提升200%+',
      icon: Smartphone,
      color: 'text-green-600'
    },
    {
      title: 'SaaS化轻量部署',
      description: '云原生架构，快速部署，降低客户使用门槛',
      impact: '部署时间缩短90%+',
      icon: Cloud,
      color: 'text-orange-600'
    }
  ];

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <PieChart className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold">智美云图商业画布</h1>
        </div>
        <p className="text-muted-foreground">
          完整的商业模式分析，包含价值主张、客户细分、收入模式和核心资源配置
        </p>
      </div>

      {/* 视图切换 */}
      <Tabs value={activeView} onValueChange={setActiveView} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="canvas">商业画布</TabsTrigger>
          <TabsTrigger value="swot">SWOT分析</TabsTrigger>
          <TabsTrigger value="innovation">创新亮点</TabsTrigger>
          <TabsTrigger value="metrics">关键指标</TabsTrigger>
        </TabsList>

        {/* 商业画布视图 */}
        <TabsContent value="canvas" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="w-5 h-5" />
                商业模式画布 - 9要素分析
              </CardTitle>
              <p className="text-muted-foreground">
                基于Business Model Canvas框架的完整商业模式分析
              </p>
            </CardHeader>
            <CardContent>
              {/* 画布布局 - 3x3网格 */}
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 h-auto lg:h-[800px]">
                {/* 第一行 */}
                <div className="lg:col-span-1 space-y-4">
                  <CanvasBlock 
                    {...canvasBlocks.keyPartnerships} 
                    className="h-full"
                  />
                </div>
                <div className="lg:col-span-1 space-y-4">
                  <div className="h-1/2">
                    <CanvasBlock 
                      {...canvasBlocks.keyActivities} 
                      className="h-full"
                    />
                  </div>
                  <div className="h-1/2">
                    <CanvasBlock 
                      {...canvasBlocks.keyResources} 
                      className="h-full"
                    />
                  </div>
                </div>
                <div className="lg:col-span-1">
                  <CanvasBlock 
                    {...canvasBlocks.valuePropositions} 
                    className="h-full"
                  />
                </div>
                <div className="lg:col-span-1 space-y-4">
                  <div className="h-1/2">
                    <CanvasBlock 
                      {...canvasBlocks.customerRelationships} 
                      className="h-full"
                    />
                  </div>
                  <div className="h-1/2">
                    <CanvasBlock 
                      {...canvasBlocks.channels} 
                      className="h-full"
                    />
                  </div>
                </div>
                <div className="lg:col-span-1">
                  <CanvasBlock 
                    {...canvasBlocks.customerSegments} 
                    className="h-full"
                  />
                </div>

                {/* 第二行 - 成本结构和收入来源 */}
                <div className="lg:col-span-5 grid grid-cols-1 lg:grid-cols-2 gap-4 mt-4">
                  <CanvasBlock 
                    {...canvasBlocks.costStructure} 
                    className="h-full"
                  />
                  <CanvasBlock 
                    {...canvasBlocks.revenueStreams} 
                    className="h-full"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SWOT分析视图 */}
        <TabsContent value="swot" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                SWOT战略分析
              </CardTitle>
              <p className="text-muted-foreground">
                内部优劣势和外部机遇威胁的全面分析
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {/* 优势 */}
                <div className="space-y-3">
                  <h3 className="flex items-center gap-2 font-medium text-green-700">
                    <CheckCircle className="w-4 h-4" />
                    优势 (Strengths)
                  </h3>
                  <div className="space-y-2">
                    {swotAnalysis.strengths.map((item, index) => {
                      const Icon = item.icon;
                      return (
                        <div key={index} className="flex items-center gap-2 p-2 bg-green-50 rounded-lg">
                          <Icon className="w-4 h-4 text-green-600" />
                          <span className="text-sm">{item.text}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 劣势 */}
                <div className="space-y-3">
                  <h3 className="flex items-center gap-2 font-medium text-red-700">
                    <Target className="w-4 h-4" />
                    劣势 (Weaknesses)
                  </h3>
                  <div className="space-y-2">
                    {swotAnalysis.weaknesses.map((item, index) => {
                      const Icon = item.icon;
                      return (
                        <div key={index} className="flex items-center gap-2 p-2 bg-red-50 rounded-lg">
                          <Icon className="w-4 h-4 text-red-600" />
                          <span className="text-sm">{item.text}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 机会 */}
                <div className="space-y-3">
                  <h3 className="flex items-center gap-2 font-medium text-blue-700">
                    <Lightbulb className="w-4 h-4" />
                    机会 (Opportunities)
                  </h3>
                  <div className="space-y-2">
                    {swotAnalysis.opportunities.map((item, index) => {
                      const Icon = item.icon;
                      return (
                        <div key={index} className="flex items-center gap-2 p-2 bg-blue-50 rounded-lg">
                          <Icon className="w-4 h-4 text-blue-600" />
                          <span className="text-sm">{item.text}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 威胁 */}
                <div className="space-y-3">
                  <h3 className="flex items-center gap-2 font-medium text-orange-700">
                    <Shield className="w-4 h-4" />
                    威胁 (Threats)
                  </h3>
                  <div className="space-y-2">
                    {swotAnalysis.threats.map((item, index) => {
                      const Icon = item.icon;
                      return (
                        <div key={index} className="flex items-center gap-2 p-2 bg-orange-50 rounded-lg">
                          <Icon className="w-4 h-4 text-orange-600" />
                          <span className="text-sm">{item.text}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 创新亮点视图 */}
        <TabsContent value="innovation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                商业模式创新亮点
              </CardTitle>
              <p className="text-muted-foreground">
                核心创新点和竞争优势分析
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {innovations.map((innovation, index) => {
                  const Icon = innovation.icon;
                  return (
                    <div key={index} className="p-6 rounded-lg border bg-card">
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center`}>
                          <Icon className={`w-6 h-6 ${innovation.color}`} />
                        </div>
                        <div className="flex-1 space-y-3">
                          <h3 className="font-medium">{innovation.title}</h3>
                          <p className="text-muted-foreground">{innovation.description}</p>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="font-medium">
                              {innovation.impact}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 关键指标视图 */}
        <TabsContent value="metrics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                关键业务指标
              </CardTitle>
              <p className="text-muted-foreground">
                重要的KPI指标和目标设定
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {/* 财务指标 */}
                <div className="space-y-4">
                  <h3 className="font-medium flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-green-600" />
                    财务指标
                  </h3>
                  <div className="space-y-3">
                    <MetricCard 
                      label="年度经常性收入 (ARR)" 
                      value="¥5000万+" 
                      target="2025年目标" 
                    />
                    <MetricCard 
                      label="客户生命价值 (LTV)" 
                      value="¥15万" 
                      target="平均单客户" 
                    />
                    <MetricCard 
                      label="获客成本 (CAC)" 
                      value="¥8000" 
                      target="LTV/CAC = 18.75" 
                    />
                    <MetricCard 
                      label="毛利率" 
                      value="75%+" 
                      target="SaaS标准" 
                    />
                  </div>
                </div>

                {/* 运营指标 */}
                <div className="space-y-4">
                  <h3 className="font-medium flex items-center gap-2">
                    <Settings className="w-4 h-4 text-blue-600" />
                    运营指标
                  </h3>
                  <div className="space-y-3">
                    <MetricCard 
                      label="月活跃用户" 
                      value="10000+" 
                      target="2025年目标" 
                    />
                    <MetricCard 
                      label="客户留存率" 
                      value="90%+" 
                      target="年留存率" 
                    />
                    <MetricCard 
                      label="产品使用率" 
                      value="85%+" 
                      target="核心功能" 
                    />
                    <MetricCard 
                      label="客户满意度" 
                      value="4.5/5" 
                      target="NPS > 50" 
                    />
                  </div>
                </div>

                {/* 市场指标 */}
                <div className="space-y-4">
                  <h3 className="font-medium flex items-center gap-2">
                    <Target className="w-4 h-4 text-purple-600" />
                    市场指标
                  </h3>
                  <div className="space-y-3">
                    <MetricCard 
                      label="市场占有率" 
                      value="5%+" 
                      target="目标市场" 
                    />
                    <MetricCard 
                      label="品牌认知度" 
                      value="30%+" 
                      target="行业内" 
                    />
                    <MetricCard 
                      label="合作伙伴数量" 
                      value="100+" 
                      target="渠道伙伴" 
                    />
                    <MetricCard 
                      label="市场覆盖率" 
                      value="50城市" 
                      target="重点城市" 
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 总结卡片 */}
      
    </div>
  );
}

// 画布块组件
function CanvasBlock({ title, icon: Icon, color, items, className = "" }) {
  return (
    <div className={`p-4 rounded-lg border-2 ${color} ${className}`}>
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-4 h-4 text-primary" />
        <h3 className="font-medium text-sm">{title}</h3>
      </div>
      <div className="space-y-3">
        {items.map((item, index) => (
          <div key={index} className="space-y-1">
            <div className="font-medium text-xs text-muted-foreground">
              {item.category}
            </div>
            <div className="space-y-1">
              {(item.partners || item.activities || item.resources || item.values || 
                item.relationships || item.channels || item.segments || item.costs || 
                item.revenue || []).map((detail, detailIndex) => (
                <div key={detailIndex} className="text-xs bg-white/80 p-1 rounded">
                  {detail}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// 指标卡片组件
function MetricCard({ label, value, target }) {
  return (
    <div className="p-3 bg-card border rounded-lg">
      <div className="space-y-1">
        <div className="text-sm text-muted-foreground">{label}</div>
        <div className="font-medium">{value}</div>
        <div className="text-xs text-muted-foreground">{target}</div>
      </div>
    </div>
  );
}