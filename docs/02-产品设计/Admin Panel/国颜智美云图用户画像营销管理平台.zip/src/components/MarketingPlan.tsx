import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  Target, 
  TrendingUp, 
  Users, 
  DollarSign,
  Calendar,
  BarChart3,
  Zap,
  Shield,
  Star,
  CheckCircle,
  ArrowRight,
  Download,
  Phone,
  Mail,
  Award,
  Sparkles,
  Clock,
  Globe,
  Heart,
  MessageSquare,
  Camera,
  Palette,
  Database,
  ChevronRight,
  Lightbulb,
  Rocket,
  PieChart,
  FileText,
  Filter,
  Share2,
  Megaphone,
  Brain,
  Smartphone,
  Eye,
  MousePointer,
  Activity,
  Settings,
  Briefcase,
  LineChart,
  Map,
  Search
} from 'lucide-react';

interface MarketingPlanProps {
  onNavigateToApp?: () => void;
}

export function MarketingPlan({ onNavigateToApp }: MarketingPlanProps) {
  const [activeSection, setActiveSection] = useState('overview');

  // 市场细分数据
  const marketSegments = [
    {
      segment: '小型美容院',
      size: '约15万家',
      growth: '+8.5%',
      potential: '高',
      characteristics: ['1-2家门店', '年收入50-200万', '客户500-2000人', '数字化程度低'],
      painPoints: ['缺乏客户管理系统', '营销手段单一', '客户画像不清晰', '获客成本高'],
      targetProduct: '基础版',
      estimatedPrice: '¥999/月',
      conversionRate: '15%'
    },
    {
      segment: '中型连锁美容院',
      size: '约3万家',
      growth: '+12.3%',
      potential: '很高',
      characteristics: ['3-10家门店', '年收入200-1000万', '客户2000-10000人', '有初步数字化'],
      painPoints: ['多店数据孤岛', '营销效果难量化', '客户流失率高', '品牌推广困难'],
      targetProduct: '专业版',
      estimatedPrice: '¥2,999/月',
      conversionRate: '25%'
    },
    {
      segment: '大型美容连锁',
      size: '约0.5万家',
      growth: '+15.8%',
      potential: '中等',
      characteristics: ['10+家门店', '年收入1000万+', '客户10000+人', '已有数字化基础'],
      painPoints: ['系统集成复杂', '个性化需求高', '数据安全要求严', 'ROI要求明确'],
      targetProduct: '企业版',
      estimatedPrice: '¥59,999/年',
      conversionRate: '35%'
    }
  ];

  // 营销目标
  const marketingGoals = [
    {
      category: '品牌认知',
      goals: [
        { metric: '品牌知名度', current: '5%', target: '25%', timeline: '12个月' },
        { metric: '行业影响力', current: '低', target: '中等偏上', timeline: '18个月' },
        { metric: '媒体曝光次数', current: '10次/月', target: '50次/月', timeline: '6个月' }
      ]
    },
    {
      category: '客户获取',
      goals: [
        { metric: '新客户数量', current: '50家/月', target: '200家/月', timeline: '12个月' },
        { metric: '销售线索', current: '200个/月', target: '800个/月', timeline: '8个月' },
        { metric: '试用转化率', current: '15%', target: '25%', timeline: '6个月' }
      ]
    },
    {
      category: '收入增长',
      goals: [
        { metric: '月收入', current: '500万', target: '2000万', timeline: '12个月' },
        { metric: '客单价', current: '¥2000', target: '¥3500', timeline: '9个月' },
        { metric: '续费率', current: '75%', target: '90%', timeline: '12个月' }
      ]
    }
  ];

  // 营销策略
  const marketingStrategies = [
    {
      strategy: '内容营销战略',
      description: '通过高质量内容建立行业权威性和品牌信任度',
      channels: ['官方博客', '微信公众号', '抖音', '小红书', '知乎'],
      budget: '150万/年',
      kpis: ['阅读量10万+/月', '粉丝增长5000+/月', '转化率3%+'],
      timeline: 'Q1-Q4持续',
      tactics: [
        '每周发布2-3篇行业深度分析文章',
        '制作美容院数字化转型案例视频',
        '定期举办线上直播分享会',
        '与行业KOL合作产出专业内容',
        '建立美容院老板社群'
      ]
    },
    {
      strategy: '精准获客战略',
      description: '通过多渠道精准投放获取高质量销售线索',
      channels: ['百度SEM', '腾讯广告', '抖音广告', '线下展会'],
      budget: '300万/年',
      kpis: ['CPL≤200元', '转化率≥20%', 'ROI≥3:1'],
      timeline: 'Q1-Q4持续',
      tactics: [
        '搜索引擎关键词精准投放',
        '社交媒体定向广告投放',
        '参与行业重要展会活动',
        '建立渠道合作伙伴网络',
        '实施客户推荐激励计划'
      ]
    },
    {
      strategy: '产品体验战略',
      description: '通过免费试用和优质服务建立客户信任',
      channels: ['官网', '销售团队', '客服团队', '技术支持'],
      budget: '200万/年',
      kpis: ['试用申请率30%+', '试用转化率25%+', 'NPS评分8.5+'],
      timeline: 'Q1-Q4持续',
      tactics: [
        '提供30天免费试用服务',
        '安排专业顾问一对一演示',
        '建立快速响应技术支持体系',
        '制作详细的产品使用教程',
        '定期收集客户反馈并优化'
      ]
    }
  ];

  // 渠道策略
  const channelStrategies = [
    {
      channel: '数字营销渠道',
      allocation: 45,
      budget: '540万',
      channels: [
        { name: '搜索引擎营销', budget: '180万', roi: '4.2:1', focus: 'SEM + SEO' },
        { name: '社交媒体广告', budget: '150万', roi: '3.8:1', focus: '微信 + 抖音' },
        { name: '内容营销', budget: '120万', roi: '3.5:1', focus: '公众号 + 视频' },
        { name: '邮件营销', budget: '90万', roi: '5.1:1', focus: 'EDM + 自动化' }
      ]
    },
    {
      channel: '线下营销渠道',
      allocation: 25,
      budget: '300万',
      channels: [
        { name: '行业展会', budget: '120万', roi: '3.2:1', focus: '美博会 + 连锁展' },
        { name: '会议论坛', budget: '80万', roi: '2.8:1', focus: '行业峰会演讲' },
        { name: '区域路演', budget: '60万', roi: '2.5:1', focus: '城市巡回推广' },
        { name: '合作伙伴', budget: '40万', roi: '4.5:1', focus: '渠道代理商' }
      ]
    },
    {
      channel: '客户服务渠道',
      allocation: 20,
      budget: '240万',
      channels: [
        { name: '客户成功团队', budget: '100万', roi: '6.2:1', focus: '续费 + 增购' },
        { name: '技术支持', budget: '80万', roi: '4.8:1', focus: '服务满意度' },
        { name: '培训服务', budget: '60万', roi: '3.9:1', focus: '客户培训' }
      ]
    },
    {
      channel: '品牌建设渠道',
      allocation: 10,
      budget: '120万',
      channels: [
        { name: 'PR公关', budget: '60万', roi: '2.1:1', focus: '媒体报道' },
        { name: '品牌活动', budget: '40万', roi: '1.8:1', focus: '品牌曝光' },
        { name: 'Awards评奖', budget: '20万', roi: '2.5:1', focus: '行业认可' }
      ]
    }
  ];

  // 执行计划
  const executionPlan = [
    {
      quarter: 'Q1 2024',
      phase: '品牌启动期',
      focus: '基础建设 + 品牌认知',
      milestones: [
        '完善产品功能和用户体验',
        '建立完整的内容营销体系',
        '启动数字营销渠道投放',
        '参与春季美博会展示',
        '获得首批100家试用客户'
      ],
      budget: '280万',
      expectedResults: [
        '品牌知名度达到8%',
        '获客50家/月',
        '试用转化率达到18%',
        '建立500人微信群'
      ]
    },
    {
      quarter: 'Q2 2024',
      phase: '市场拓展期',
      focus: '获客加速 + 产品优化',
      milestones: [
        '推出客户推荐激励计划',
        '建立区域合作伙伴网络',
        '优化产品核心功能',
        '举办首次用户大会',
        '获得200家付费客户'
      ],
      budget: '320万',
      expectedResults: [
        '品牌知名度达到15%',
        '获客80家/月',
        '试用转化率达到22%',
        '客户续费率达到80%'
      ]
    },
    {
      quarter: 'Q3 2024',
      phase: '规模增长期',
      focus: '规模扩张 + 效率提升',
      milestones: [
        '扩大销售和市场团队',
        '推出企业版产品',
        '建立客户成功体系',
        '开展全国巡回路演',
        '达到500家付费客户'
      ],
      budget: '380万',
      expectedResults: [
        '品牌知名度达到20%',
        '获客120家/月',
        '试用转化率达到25%',
        '客户续费率达到85%'
      ]
    },
    {
      quarter: 'Q4 2024',
      phase: '市场领先期',
      focus: '行业领导 + 生态建设',
      milestones: [
        '发布行业白皮书',
        '建立合作伙伴生态',
        '推出AI增强功能',
        '获得行业重要奖项',
        '突破800家付费客户'
      ],
      budget: '420万',
      expectedResults: [
        '品牌知名度达到25%',
        '获客200家/月',
        '试用转化率保持25%',
        '客户续费率达到90%'
      ]
    }
  ];

  // 竞争分析
  const competitors = [
    {
      name: '美业管家',
      marketShare: '15%',
      strengths: ['进入市场早', '客户基础大', '功能相对完善'],
      weaknesses: ['UI/UX陈旧', 'AI能力弱', '价格较高'],
      position: '传统领导者',
      strategy: '差异化竞争，突出AI优势'
    },
    {
      name: '店掌柜',
      marketShare: '12%',
      strengths: ['价格便宜', '操作简单', '客服响应快'],
      weaknesses: ['功能简单', '缺乏高级分析', '扩展性差'],
      position: '低端市场',
      strategy: '价值竞争，强调功能完整性'
    },
    {
      name: '智慧美业',
      marketShare: '8%',
      strengths: ['技术先进', 'UI设计好', '创新功能多'],
      weaknesses: ['价格昂贵', '学习成本高', '稳定性待提升'],
      position: '高端创新者',
      strategy: '成本优势，平衡功能与易用性'
    }
  ];

  // 效果评估指标
  const kpiMetrics = [
    {
      category: '营销效果指标',
      metrics: [
        { name: '品牌知名度', target: '25%', measurement: '季度品牌调研', weight: '15%' },
        { name: '网站访问量', target: '50万UV/月', measurement: 'Google Analytics', weight: '10%' },
        { name: '销售线索数量', target: '800个/月', measurement: 'CRM系统', weight: '20%' },
        { name: '线索质量评分', target: '7.5分', measurement: '销售团队评分', weight: '15%' }
      ]
    },
    {
      category: '转化效果指标',
      metrics: [
        { name: '试用转化率', target: '25%', measurement: '产品使用数据', weight: '25%' },
        { name: '付费转化率', target: '20%', measurement: '销售数据', weight: '20%' },
        { name: '客单价', target: '¥3500', measurement: '财务数据', weight: '15%' },
        { name: '客户续费率', target: '90%', measurement: '客户管理系统', weight: '25%' }
      ]
    },
    {
      category: '投入产出指标',
      metrics: [
        { name: '营销ROI', target: '3.5:1', measurement: '收入/营销投入', weight: '30%' },
        { name: '获客成本CAC', target: '≤¥1500', measurement: '营销费用/新客数', weight: '25%' },
        { name: '客户生命周期价值LTV', target: '≥¥50000', measurement: 'LTV模型计算', weight: '25%' },
        { name: 'LTV/CAC比例', target: '≥30:1', measurement: 'LTV/CAC', weight: '20%' }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 头部导航 */}
      <div className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">智美云图·营销计划书</h1>
                <p className="text-muted-foreground">2024年度全面营销战略规划</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                下载PDF
              </Button>
              <Button variant="outline">
                <Share2 className="w-4 h-4 mr-2" />
                分享
              </Button>
              {onNavigateToApp && (
                <Button variant="outline" onClick={onNavigateToApp}>
                  <ArrowRight className="w-4 h-4 mr-2" />
                  进入产品
                </Button>
              )}
            </div>
          </div>

          {/* 导航标签 */}
          <div className="flex items-center gap-8 mt-6 border-b">
            {[
              { id: 'overview', label: '计划概览', icon: Eye },
              { id: 'market', label: '市场分析', icon: BarChart3 },
              { id: 'strategy', label: '营销策略', icon: Target },
              { id: 'execution', label: '执行计划', icon: Calendar },
              { id: 'budget', label: '预算分配', icon: DollarSign },
              { id: 'evaluation', label: '效果评估', icon: LineChart }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveSection(id)}
                className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors ${
                  activeSection === id 
                    ? 'border-primary text-primary' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 主内容区域 */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        
        {/* 计划概览 */}
        {activeSection === 'overview' && (
          <div className="space-y-8">
            {/* 执行摘要 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  执行摘要
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h3 className="font-bold text-lg">市场机会</h3>
                    <p className="text-muted-foreground">
                      中国美容行业市场规模超过5000亿元，其中美容院约18.5万家，
                      但数字化程度普遍较低，存在巨大的数字化转型需求。
                      智美云图定位于AI驱动的营销管理平台，
                      预计可获得约30%的市场份额，对应约5.5万家潜在客户。
                    </p>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>目标市场规模</span>
                        <span className="font-medium">18.5万家美容院</span>
                      </div>
                      <div className="flex justify-between">
                        <span>可获得市场份额</span>
                        <span className="font-medium">30% (5.5万家)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>预期市场增长率</span>
                        <span className="font-medium text-green-600">+12.5%/年</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="font-bold text-lg">营销目标</h3>
                    <p className="text-muted-foreground">
                      通过系统性的营销策略，在12个月内实现品牌知名度从5%提升至25%，
                      获客数量从50家/月增长到200家/月，
                      月收入从500万增长到2000万，确立行业领导地位。
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">25%</div>
                        <div className="text-sm text-muted-foreground">目标品牌知名度</div>
                      </div>
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">200</div>
                        <div className="text-sm text-muted-foreground">月获客数量(家)</div>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">2000万</div>
                        <div className="text-sm text-muted-foreground">目标月收入</div>
                      </div>
                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <div className="text-2xl font-bold text-orange-600">90%</div>
                        <div className="text-sm text-muted-foreground">客户续费率</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 关键策略 */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-blue-200 bg-blue-50/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-700">
                    <Brain className="w-5 h-5" />
                    内容营销战略
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    通过高质量专业内容建立行业权威性，
                    提升品牌信任度和知名度
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>预算分配</span>
                      <span className="font-medium">150万/年</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>目标ROI</span>
                      <span className="font-medium text-green-600">3.5:1</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>主要渠道</span>
                      <span className="font-medium">5个平台</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-green-200 bg-green-50/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-700">
                    <Target className="w-5 h-5" />
                    精准获客战略
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    多渠道精准投放获取高质量销售线索，
                    提升获客效率和转化率
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>预算分配</span>
                      <span className="font-medium">300万/年</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>目标CPL</span>
                      <span className="font-medium text-blue-600">≤200元</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>转化率目标</span>
                      <span className="font-medium text-green-600">≥20%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-200 bg-purple-50/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-700">
                    <Heart className="w-5 h-5" />
                    产品体验战略
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    通过免费试用和优质服务建立客户信任，
                    提升试用转化率
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>预算分配</span>
                      <span className="font-medium">200万/年</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>试用转化率</span>
                      <span className="font-medium text-purple-600">25%+</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>NPS评分</span>
                      <span className="font-medium text-green-600">8.5+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 年度里程碑 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Rocket className="w-5 h-5 text-primary" />
                  2024年度里程碑
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {executionPlan.map((quarter, index) => (
                    <div key={index} className="flex gap-6">
                      <div className="flex-shrink-0">
                        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-full flex items-center justify-center font-bold">
                          {quarter.quarter.replace(' 2024', '')}
                        </div>
                      </div>
                      <div className="flex-1 space-y-3">
                        <div>
                          <h3 className="font-bold text-lg">{quarter.phase}</h3>
                          <p className="text-muted-foreground">{quarter.focus}</p>
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h4 className="font-medium mb-2">关键里程碑</h4>
                            <ul className="space-y-1 text-sm text-muted-foreground">
                              {quarter.milestones.slice(0, 3).map((milestone, mIndex) => (
                                <li key={mIndex} className="flex items-center gap-2">
                                  <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
                                  {milestone}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-medium mb-2">预期成果</h4>
                            <ul className="space-y-1 text-sm text-muted-foreground">
                              {quarter.expectedResults.slice(0, 3).map((result, rIndex) => (
                                <li key={rIndex} className="flex items-center gap-2">
                                  <Star className="w-3 h-3 text-yellow-500 flex-shrink-0" />
                                  {result}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 市场分析 */}
        {activeSection === 'market' && (
          <div className="space-y-8">
            {/* 市场规模 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-primary" />
                  市场规模分析
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-8">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">5000亿+</div>
                    <div className="text-muted-foreground mb-4">中国美容行业市场规模</div>
                    <Progress value={85} className="h-2" />
                    <div className="text-sm text-muted-foreground mt-2">年增长率 +12.5%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">18.5万</div>
                    <div className="text-muted-foreground mb-4">全国美容院总数</div>
                    <Progress value={75} className="h-2" />
                    <div className="text-sm text-muted-foreground mt-2">数字化率仅 15%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">800亿</div>
                    <div className="text-muted-foreground mb-4">美容院SaaS市场潜力</div>
                    <Progress value={65} className="h-2" />
                    <div className="text-sm text-muted-foreground mt-2">渗透率增长中</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 市场细分 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Filter className="w-5 h-5 text-primary" />
                  目标客户细分
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {marketSegments.map((segment, index) => (
                    <div key={index} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                      <div className="grid md:grid-cols-4 gap-6">
                        <div>
                          <h3 className="font-bold text-lg mb-2">{segment.segment}</h3>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">市场规模:</span>
                              <span className="font-medium">{segment.size}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">增长率:</span>
                              <span className="font-medium text-green-600">{segment.growth}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">潜力:</span>
                              <Badge variant={segment.potential === '很高' ? 'default' : segment.potential === '高' ? 'secondary' : 'outline'}>
                                {segment.potential}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div>
                          <h4 className="font-medium mb-2">客户特征</h4>
                          <ul className="space-y-1 text-sm text-muted-foreground">
                            {segment.characteristics.map((char, cIndex) => (
                              <li key={cIndex}>• {char}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-medium mb-2">痛点需求</h4>
                          <ul className="space-y-1 text-sm text-muted-foreground">
                            {segment.painPoints.map((pain, pIndex) => (
                              <li key={pIndex}>• {pain}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-medium mb-2">目标产品</h4>
                          <div className="space-y-2">
                            <Badge variant="outline">{segment.targetProduct}</Badge>
                            <div className="text-sm">
                              <div className="font-medium">{segment.estimatedPrice}</div>
                              <div className="text-muted-foreground">预期转化率: {segment.conversionRate}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 竞争分析 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary" />
                  竞争格局分析
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="font-bold text-lg mb-4">市场份额分布</h3>
                    <div className="space-y-4">
                      {competitors.map((competitor, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">{competitor.name}</span>
                            <span className="text-sm text-muted-foreground">{competitor.marketShare}</span>
                          </div>
                          <Progress value={parseInt(competitor.marketShare)} className="h-2" />
                          <Badge variant="outline" className="text-xs">
                            {competitor.position}
                          </Badge>
                        </div>
                      ))}
                      <div className="space-y-2 border-t pt-4">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-primary">智美云图</span>
                          <span className="text-sm text-primary">0% → 30%</span>
                        </div>
                        <Progress value={30} className="h-2 bg-primary/20" />
                        <Badge variant="default" className="text-xs">
                          AI驱动创新者
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-4">竞争对手分析</h3>
                    <div className="space-y-4">
                      {competitors.map((competitor, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <h4 className="font-medium mb-3">{competitor.name}</h4>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <h5 className="font-medium text-green-600 mb-1">优势</h5>
                              <ul className="space-y-1 text-muted-foreground">
                                {competitor.strengths.map((strength, sIndex) => (
                                  <li key={sIndex}>+ {strength}</li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <h5 className="font-medium text-red-600 mb-1">劣势</h5>
                              <ul className="space-y-1 text-muted-foreground">
                                {competitor.weaknesses.map((weakness, wIndex) => (
                                  <li key={wIndex}>- {weakness}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                          <div className="mt-3 p-2 bg-blue-50 rounded text-sm">
                            <strong>应对策略:</strong> {competitor.strategy}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 营销策略 */}
        {activeSection === 'strategy' && (
          <div className="space-y-8">
            {/* 营销目标 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  营销目标设定
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {marketingGoals.map((category, index) => (
                    <div key={index}>
                      <h3 className="font-bold text-lg mb-4">{category.category}</h3>
                      <div className="grid md:grid-cols-3 gap-6">
                        {category.goals.map((goal, gIndex) => (
                          <Card key={gIndex} className="border-2">
                            <CardContent className="p-6">
                              <h4 className="font-medium mb-4">{goal.metric}</h4>
                              <div className="space-y-3">
                                <div className="flex justify-between text-sm">
                                  <span className="text-muted-foreground">当前值</span>
                                  <span className="font-medium">{goal.current}</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                  <span className="text-muted-foreground">目标值</span>
                                  <span className="font-bold text-primary">{goal.target}</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                  <span className="text-muted-foreground">完成时间</span>
                                  <Badge variant="outline">{goal.timeline}</Badge>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 核心策略 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-primary" />
                  核心营销策略
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {marketingStrategies.map((strategy, index) => (
                    <div key={index} className="border rounded-lg p-6 hover:shadow-lg transition-shadow">
                      <div className="grid md:grid-cols-3 gap-6">
                        <div className="col-span-1">
                          <h3 className="font-bold text-xl mb-3">{strategy.strategy}</h3>
                          <p className="text-muted-foreground mb-4">{strategy.description}</p>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <DollarSign className="w-4 h-4 text-green-600" />
                              <span className="text-sm font-medium">{strategy.budget}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-blue-600" />
                              <span className="text-sm font-medium">{strategy.timeline}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="col-span-1">
                          <h4 className="font-medium mb-3">营销渠道</h4>
                          <div className="space-y-2">
                            {strategy.channels.map((channel, cIndex) => (
                              <Badge key={cIndex} variant="secondary" className="mr-2 mb-2">
                                {channel}
                              </Badge>
                            ))}
                          </div>
                          
                          <h4 className="font-medium mb-3 mt-6">关键KPI</h4>
                          <ul className="space-y-1 text-sm">
                            {strategy.kpis.map((kpi, kIndex) => (
                              <li key={kIndex} className="flex items-center gap-2">
                                <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
                                {kpi}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div className="col-span-1">
                          <h4 className="font-medium mb-3">执行策略</h4>
                          <ul className="space-y-2 text-sm text-muted-foreground">
                            {strategy.tactics.map((tactic, tIndex) => (
                              <li key={tIndex} className="flex items-start gap-2">
                                <ChevronRight className="w-3 h-3 mt-1 text-primary flex-shrink-0" />
                                {tactic}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 执行计划 */}
        {activeSection === 'execution' && (
          <div className="space-y-8">
            {/* 年度执行计划 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  2024年度执行路线图
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {executionPlan.map((quarter, index) => (
                    <div key={index} className="relative">
                      {index < executionPlan.length - 1 && (
                        <div className="absolute left-6 top-16 w-0.5 h-32 bg-gradient-to-b from-primary/50 to-transparent"></div>
                      )}
                      
                      <div className="flex gap-6">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-full flex items-center justify-center font-bold">
                            Q{index + 1}
                          </div>
                        </div>
                        
                        <div className="flex-1">
                          <div className="grid md:grid-cols-3 gap-6">
                            <div className="col-span-2">
                              <div className="mb-4">
                                <h3 className="font-bold text-xl">{quarter.quarter}</h3>
                                <p className="text-lg text-primary font-medium">{quarter.phase}</p>
                                <p className="text-muted-foreground">{quarter.focus}</p>
                              </div>
                              
                              <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                  <h4 className="font-medium mb-3 flex items-center gap-2">
                                    <Rocket className="w-4 h-4 text-primary" />
                                    关键里程碑
                                  </h4>
                                  <ul className="space-y-2">
                                    {quarter.milestones.map((milestone, mIndex) => (
                                      <li key={mIndex} className="flex items-start gap-2 text-sm">
                                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                                        {milestone}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                                
                                <div>
                                  <h4 className="font-medium mb-3 flex items-center gap-2">
                                    <Star className="w-4 h-4 text-yellow-500" />
                                    预期成果
                                  </h4>
                                  <ul className="space-y-2">
                                    {quarter.expectedResults.map((result, rIndex) => (
                                      <li key={rIndex} className="flex items-start gap-2 text-sm">
                                        <TrendingUp className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                                        {result}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            </div>
                            
                            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6">
                              <h4 className="font-medium mb-4 flex items-center gap-2">
                                <DollarSign className="w-4 h-4 text-green-600" />
                                预算分配
                              </h4>
                              <div className="text-center">
                                <div className="text-2xl font-bold text-primary mb-2">{quarter.budget}</div>
                                <div className="text-sm text-muted-foreground">季度总预算</div>
                              </div>
                              
                              <div className="mt-6 space-y-3">
                                <div className="flex justify-between text-sm">
                                  <span>数字营销</span>
                                  <span className="font-medium">45%</span>
                                </div>
                                <Progress value={45} className="h-2" />
                                
                                <div className="flex justify-between text-sm">
                                  <span>线下活动</span>
                                  <span className="font-medium">25%</span>
                                </div>
                                <Progress value={25} className="h-2" />
                                
                                <div className="flex justify-between text-sm">
                                  <span>人员成本</span>
                                  <span className="font-medium">20%</span>
                                </div>
                                <Progress value={20} className="h-2" />
                                
                                <div className="flex justify-between text-sm">
                                  <span>其他费用</span>
                                  <span className="font-medium">10%</span>
                                </div>
                                <Progress value={10} className="h-2" />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 预算分配 */}
        {activeSection === 'budget' && (
          <div className="space-y-8">
            {/* 总体预算分配 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-primary" />
                  年度营销预算分配
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="font-bold text-lg mb-6">预算概览</h3>
                    <div className="text-center mb-8">
                      <div className="text-4xl font-bold text-primary mb-2">¥1,200万</div>
                      <div className="text-muted-foreground">2024年总营销预算</div>
                    </div>
                    
                    <div className="space-y-4">
                      {channelStrategies.map((category, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">{category.channel}</span>
                            <div className="text-right">
                              <div className="font-medium">{category.budget}</div>
                              <div className="text-sm text-muted-foreground">{category.allocation}%</div>
                            </div>
                          </div>
                          <Progress value={category.allocation} className="h-3" />
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <h3 className="font-bold text-lg">渠道ROI预期</h3>
                    {channelStrategies.map((category, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <h4 className="font-medium mb-3">{category.channel}</h4>
                        <div className="space-y-3">
                          {category.channels.map((channel, cIndex) => (
                            <div key={cIndex} className="flex justify-between items-center text-sm">
                              <span>{channel.name}</span>
                              <div className="text-right">
                                <div className="font-medium">{channel.budget}</div>
                                <Badge variant="outline" className="text-xs">
                                  ROI {channel.roi}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 季度预算分解 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5 text-primary" />
                  季度预算分解
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-6">
                  {executionPlan.map((quarter, index) => (
                    <Card key={index} className="border-2">
                      <CardHeader className="text-center">
                        <CardTitle className="text-lg">{quarter.quarter}</CardTitle>
                        <div className="text-2xl font-bold text-primary">{quarter.budget}</div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="text-center">
                          <Badge variant="secondary">{quarter.phase}</Badge>
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>数字营销</span>
                            <span>45%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>线下活动</span>
                            <span>25%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>人员培训</span>
                            <span>20%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>其他支出</span>
                            <span>10%</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 成本效益分析 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="w-5 h-5 text-primary" />
                  成本效益分析
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-8">
                  <div className="text-center">
                    <h3 className="font-bold text-lg mb-4">投入产出比</h3>
                    <div className="text-3xl font-bold text-green-600 mb-2">3.5:1</div>
                    <div className="text-muted-foreground mb-4">营销ROI目标</div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>预期收入</span>
                        <span className="font-medium">¥4,200万</span>
                      </div>
                      <div className="flex justify-between">
                        <span>营销投入</span>
                        <span className="font-medium">¥1,200万</span>
                      </div>
                      <div className="flex justify-between">
                        <span>净利润</span>
                        <span className="font-medium text-green-600">¥3,000万</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <h3 className="font-bold text-lg mb-4">获客成本</h3>
                    <div className="text-3xl font-bold text-blue-600 mb-2">¥1,500</div>
                    <div className="text-muted-foreground mb-4">平均CAC</div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>数字渠道CAC</span>
                        <span className="font-medium">¥1,200</span>
                      </div>
                      <div className="flex justify-between">
                        <span>线下渠道CAC</span>
                        <span className="font-medium">¥2,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span>转介绍CAC</span>
                        <span className="font-medium text-green-600">¥500</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <h3 className="font-bold text-lg mb-4">客户价值</h3>
                    <div className="text-3xl font-bold text-purple-600 mb-2">¥50,000</div>
                    <div className="text-muted-foreground mb-4">平均LTV</div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>LTV/CAC比例</span>
                        <span className="font-medium text-green-600">33:1</span>
                      </div>
                      <div className="flex justify-between">
                        <span>回本周期</span>
                        <span className="font-medium">3个月</span>
                      </div>
                      <div className="flex justify-between">
                        <span>客户续费率</span>
                        <span className="font-medium">90%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 效果评估 */}
        {activeSection === 'evaluation' && (
          <div className="space-y-8">
            {/* KPI指标体系 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-primary" />
                  KPI指标体系
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {kpiMetrics.map((category, index) => (
                    <div key={index}>
                      <h3 className="font-bold text-lg mb-6">{category.category}</h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        {category.metrics.map((metric, mIndex) => (
                          <Card key={mIndex} className="border-2">
                            <CardContent className="p-6">
                              <div className="flex justify-between items-start mb-4">
                                <h4 className="font-medium">{metric.name}</h4>
                                <Badge variant="outline">权重 {metric.weight}</Badge>
                              </div>
                              
                              <div className="space-y-3">
                                <div className="text-center">
                                  <div className="text-2xl font-bold text-primary">{metric.target}</div>
                                  <div className="text-sm text-muted-foreground">目标值</div>
                                </div>
                                
                                <div className="text-sm text-muted-foreground">
                                  <strong>测量方式:</strong> {metric.measurement}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 监控机制 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-primary" />
                  监控与调整机制
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-8">
                  <div>
                    <h3 className="font-bold text-lg mb-4">实时监控</h3>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span>每日数据仪表板监控</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span>关键指标异常预警</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span>竞争对手动态跟踪</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span>客户反馈收集分析</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-bold text-lg mb-4">定期评估</h3>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-blue-500" />
                        <span>周度营销效果回顾</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-blue-500" />
                        <span>月度KPI达成评估</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-blue-500" />
                        <span>季度策略调整会议</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-blue-500" />
                        <span>年度营销复盘总结</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-bold text-lg mb-4">优化调整</h3>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-3">
                        <TrendingUp className="w-5 h-5 text-purple-500" />
                        <span>A/B测试持续优化</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <TrendingUp className="w-5 h-5 text-purple-500" />
                        <span>渠道效果动态调整</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <TrendingUp className="w-5 h-5 text-purple-500" />
                        <span>预算分配实时优化</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <TrendingUp className="w-5 h-5 text-purple-500" />
                        <span>策略迭代快速响应</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 风险管理 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary" />
                  风险识别与应对
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <h3 className="font-bold text-lg mb-4 text-red-600">潜在风险</h3>
                      <div className="space-y-4">
                        <div className="border-l-4 border-red-500 pl-4">
                          <h4 className="font-medium">市场竞争加剧</h4>
                          <p className="text-sm text-muted-foreground">
                            大厂或资本进入，价格战，功能同质化
                          </p>
                        </div>
                        <div className="border-l-4 border-orange-500 pl-4">
                          <h4 className="font-medium">获客成本上升</h4>
                          <p className="text-sm text-muted-foreground">
                            广告竞价激烈，流量成本增加，转化率下降
                          </p>
                        </div>
                        <div className="border-l-4 border-yellow-500 pl-4">
                          <h4 className="font-medium">技术发展变化</h4>
                          <p className="text-sm text-muted-foreground">
                            AI技术快速迭代，用户需求变化，产品落后
                          </p>
                        </div>
                        <div className="border-l-4 border-blue-500 pl-4">
                          <h4 className="font-medium">宏观经济影响</h4>
                          <p className="text-sm text-muted-foreground">
                            经济下行，美容消费减少，客户预算收紧
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-bold text-lg mb-4 text-green-600">应对措施</h3>
                      <div className="space-y-4">
                        <div className="border-l-4 border-green-500 pl-4">
                          <h4 className="font-medium">差异化竞争</h4>
                          <p className="text-sm text-muted-foreground">
                            强化AI技术优势，深度行业定制，建立技术壁垒
                          </p>
                        </div>
                        <div className="border-l-4 border-blue-500 pl-4">
                          <h4 className="font-medium">多元化获客</h4>
                          <p className="text-sm text-muted-foreground">
                            发展转介绍渠道，建立合作生态，降低依赖风险
                          </p>
                        </div>
                        <div className="border-l-4 border-purple-500 pl-4">
                          <h4 className="font-medium">持续创新投入</h4>
                          <p className="text-sm text-muted-foreground">
                            保持研发投入，快速迭代产品，领先技术趋势
                          </p>
                        </div>
                        <div className="border-l-4 border-orange-500 pl-4">
                          <h4 className="font-medium">灵活预算机制</h4>
                          <p className="text-sm text-muted-foreground">
                            建立弹性预算，快速响应市场，调整营销策略
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}