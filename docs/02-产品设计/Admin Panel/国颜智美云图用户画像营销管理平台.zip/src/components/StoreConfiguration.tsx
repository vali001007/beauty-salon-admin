import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from './ui/dialog';
import { Switch } from './ui/switch';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { CompleteMiniprogramPreview } from './CompleteMiniprogramPreview';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Store, 
  Users, 
  Briefcase, 
  Package,
  Calendar,
  Clock,
  MapPin,
  Phone,
  Mail,
  Camera,
  Star,
  Eye,
  Smartphone,
  Settings,
  Upload,
  Save,
  Globe,
  ChevronRight,
  Palette,
  Zap,
  Shield,
  Image,
  FileText,
  Search,
  CheckCircle,
  Info,
  Gift,
  CreditCard,
  Wallet,
  TrendingUp,
  History,
  BarChart3,
  DollarSign,
  ShoppingCart,
  User,
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  MoreHorizontal,
  Copy,
  Home
} from 'lucide-react';

// 模拟数据
const salonInfo = {
  name: '雅致美容美发沙龙',
  description: '专业美容美发服务，为您提供专业的肌肤护理和时尚造型设计',
  address: '上海市徐汇区淮海中路123号',
  phone: '021-12345678',
  email: 'info@yazhi-salon.com',
  businessHours: '09:00-21:00',
  images: ['salon1.jpg', 'salon2.jpg', 'salon3.jpg'],
  tags: ['专业护肤', '时尚造型', '环境优雅'],
};

const staffData = [
  {
    id: 1,
    name: '张美美',
    position: '高级美容师',
    avatar: 'avatar1.jpg',
    experience: '8年',
    specialties: ['面部护理', '抗衰管理'],
    rating: 4.9,
    introduction: '拥有8年专业美容经验，擅长面部深层护理和抗衰老管理',
    available: true,
  },
  {
    id: 2,
    name: '李造型',
    position: '首席发型师',
    avatar: 'avatar2.jpg',
    experience: '10年',
    specialties: ['发型设计', '染烫护理'],
    rating: 4.8,
    introduction: '10年发型设计经验，精通各种时尚造型和护理技术',
    available: true,
  },
  {
    id: 3,
    name: '王护肤',
    position: '皮肤管理师',
    avatar: 'avatar3.jpg',
    experience: '6年',
    specialties: ['问题肌肤', '深层清洁'],
    rating: 4.7,
    introduction: '专注问题肌肤管理，擅长深层清洁和肌肤修复',
    available: false,
  },
];

const servicesData = [
  {
    id: 1,
    name: '深层清洁护理',
    category: '面部护理',
    duration: 90,
    price: 298,
    description: '深层清洁毛孔，去除黑头粉刺，改善肌肤质感',
    image: 'service1.jpg',
    popular: true,
    available: true,
  },
  {
    id: 2,
    name: '抗衰老精华护理',
    category: '抗衰管理',
    duration: 120,
    price: 588,
    description: '使用进口精华，深层滋养，延缓肌肤衰老',
    image: 'service2.jpg',
    popular: true,
    available: true,
  },
  {
    id: 3,
    name: '时尚造型设计',
    category: '发型服务',
    duration: 180,
    price: 688,
    description: '个性化发型设计，包含洗剪吹造型全套服务',
    image: 'service3.jpg',
    popular: false,
    available: true,
  },
];

const productsData = [
  {
    id: 1,
    name: '海蓝之谜精华面霜',
    category: '护肤品',
    price: 1580,
    originalPrice: 1680,
    stock: 25,
    description: '奢华抗衰老面霜，深层滋润，紧致肌肤',
    image: 'product1.jpg',
    brand: '海蓝之谜',
    onSale: true,
  },
  {
    id: 2,
    name: '雅诗兰黛小棕瓶',
    category: '精华液',
    price: 980,
    originalPrice: 980,
    stock: 18,
    description: '修护精华液，改善肌肤纹理，提升光泽',
    image: 'product2.jpg',
    brand: '雅诗兰黛',
    onSale: false,
  },
  {
    id: 3,
    name: '专业护发精油',
    category: '护发产品',
    price: 268,
    originalPrice: 298,
    stock: 32,
    description: '天然植物精油，深层滋养秀发，修复受损',
    image: 'product3.jpg',
    brand: '沙龙专用',
    onSale: true,
  },
];

// 会员卡服务项目类型
interface MembershipService {
  id: string;
  name: string;
  duration: number;
  category: '面部' | '身体';
  singlePrice: number;
  packagePrice: number;
  packageCount: number;
}

// 会员卡类型
interface MembershipCard {
  id: number;
  name: string;
  type: 'premium' | 'vip' | 'standard';
  status: 'active' | 'inactive' | 'archived';
  totalValue: number;
  description: string;
  services: MembershipService[];
  validityPeriod: number; // 有效期（月）
  purchaseLimit: number; // 每年限购数量
  benefits: string[];
  createdAt: string;
  salesCount: number;
}

// 会员卡消费记录类型
interface ConsumptionRecord {
  id: number;
  cardId: number;
  cardName: string;
  customerName: string;
  serviceName: string;
  consumptionAmount: number;
  consumptionDate: string;
  staff: string;
  remainingBalance?: number;
}

// 模拟会员卡数据
const membershipCardsData: MembershipCard[] = [
  {
    id: 1,
    name: '2991创始会员卡',
    type: 'premium',
    status: 'active',
    totalValue: 2991,
    description: '以下任选20组(每年限购一张)',
    validityPeriod: 12,
    purchaseLimit: 1,
    benefits: ['限时优惠', '专属服务', '优先预约'],
    createdAt: '2024-01-15',
    salesCount: 156,
    services: [
      {
        id: 'fc-1',
        name: '巨补水',
        duration: 60,
        category: '面部',
        singlePrice: 298,
        packagePrice: 2980,
        packageCount: 10
      },
      {
        id: 'bc-1',
        name: '肩颈经络通',
        duration: 40,
        category: '身体',
        singlePrice: 298,
        packagePrice: 2980,
        packageCount: 10
      }
    ]
  },
  {
    id: 2,
    name: '9999一卡通',
    type: 'vip',
    status: 'active',
    totalValue: 9999,
    description: '以下50组(送10次泡澡)',
    validityPeriod: 24,
    purchaseLimit: 2,
    benefits: ['全项目通用', '赠送泡澡', '无限次数'],
    createdAt: '2024-01-10',
    salesCount: 89,
    services: [
      {
        id: 'fc-2',
        name: '巨补水',
        duration: 60,
        category: '面部',
        singlePrice: 298,
        packagePrice: 2980,
        packageCount: 10
      }
    ]
  }
];

// 模拟消费记录数据
const consumptionRecordsData: ConsumptionRecord[] = [
  {
    id: 1,
    cardId: 1,
    cardName: '2991创始会员卡',
    customerName: '张小美',
    serviceName: '巨补水',
    consumptionAmount: 298,
    consumptionDate: '2024-12-20',
    staff: '张美美',
    remainingBalance: 2693
  }
];

// 消费统计数据类型
interface ConsumptionStats {
  date: string;
  cash: number; // 现金
  cardConsumption: number; // 卡项耗
  productConsumption: number; // 产品耗
  manual: number; // 手工
  cardDeduction: number; // 卡扣
  cardGift: number; // 卡扣(送)
  customerCount: number; // 人头
  serviceCount: number; // 人次
  itemCount: number; // 项次
  inventory: number; // 出入库
  debt: number; // 欠款
}

// 模拟消费统计数据
const consumptionStatsData: { [key: string]: ConsumptionStats } = {
  '2024-12-21': {
    date: '2024-12-21',
    cash: 1580,
    cardConsumption: 2960,
    productConsumption: 680,
    manual: 320,
    cardDeduction: 1200,
    cardGift: 400,
    customerCount: 15,
    serviceCount: 28,
    itemCount: 35,
    inventory: 5,
    debt: 0
  }
};

const monthlyStats = {
  '2024-12': {
    cash: 58420,
    cardConsumption: 125680,
    productConsumption: 23450,
    manual: 12340,
    cardDeduction: 45680,
    cardGift: 15230,
    customerCount: 456,
    serviceCount: 892,
    itemCount: 1150,
    inventory: 185,
    debt: 2340
  }
};

const weeklyStats = {
  '2024-W51': {
    cash: 14820,
    cardConsumption: 28960,
    productConsumption: 5420,
    manual: 2890,
    cardDeduction: 10560,
    cardGift: 3520,
    customerCount: 105,
    serviceCount: 198,
    itemCount: 245,
    inventory: 42,
    debt: 580
  }
};

// 排班管理相关数据类型
interface ScheduleSlot {
  time: string;
  staffSchedules: { [staffId: number]: 'available' | 'busy' | 'off' | null };
}

// 排班数据
const scheduleData: ScheduleSlot[] = [
  { time: '8:00', staffSchedules: { 1: 'available', 2: 'available', 3: 'off' } },
  { time: '8:30', staffSchedules: { 1: 'available', 2: 'available', 3: 'off' } },
  { time: '9:00', staffSchedules: { 1: 'busy', 2: 'available', 3: 'off' } },
  { time: '9:30', staffSchedules: { 1: 'busy', 2: 'available', 3: 'available' } },
  { time: '10:00', staffSchedules: { 1: 'available', 2: 'busy', 3: 'available' } },
  { time: '10:30', staffSchedules: { 1: 'available', 2: 'busy', 3: 'available' } },
  { time: '11:00', staffSchedules: { 1: 'available', 2: 'available', 3: 'busy' } },
  { time: '11:30', staffSchedules: { 1: 'available', 2: 'available', 3: 'busy' } },
  { time: '12:00', staffSchedules: { 1: 'busy', 2: 'available', 3: 'available' } },
  { time: '12:30', staffSchedules: { 1: 'busy', 2: 'available', 3: 'available' } },
  { time: '13:00', staffSchedules: { 1: 'available', 2: 'off', 3: 'available' } },
  { time: '13:30', staffSchedules: { 1: 'available', 2: 'off', 3: 'available' } },
  { time: '14:00', staffSchedules: { 1: 'available', 2: 'available', 3: 'busy' } },
  { time: '14:30', staffSchedules: { 1: 'available', 2: 'available', 3: 'busy' } },
  { time: '15:00', staffSchedules: { 1: 'busy', 2: 'available', 3: 'available' } },
  { time: '15:30', staffSchedules: { 1: 'busy', 2: 'available', 3: 'available' } },
  { time: '16:00', staffSchedules: { 1: 'available', 2: 'busy', 3: 'available' } },
  { time: '16:30', staffSchedules: { 1: 'available', 2: 'busy', 3: 'available' } },
  { time: '17:00', staffSchedules: { 1: 'available', 2: 'available', 3: 'off' } },
  { time: '17:30', staffSchedules: { 1: 'available', 2: 'available', 3: 'off' } },
  { time: '18:00', staffSchedules: { 1: 'busy', 2: 'available', 3: 'off' } },
  { time: '18:30', staffSchedules: { 1: 'busy', 2: 'available', 3: 'off' } },
  { time: '19:00', staffSchedules: { 1: 'available', 2: 'busy', 3: 'off' } },
  { time: '19:30', staffSchedules: { 1: 'available', 2: 'busy', 3: 'off' } },
  { time: '20:00', staffSchedules: { 1: 'available', 2: 'available', 3: 'off' } },
  { time: '20:30', staffSchedules: { 1: 'available', 2: 'available', 3: 'off' } },
  { time: '21:00', staffSchedules: { 1: 'off', 2: 'off', 3: 'off' } }
];

// 按周排班数据类型
interface WeeklySchedule {
  staffId: number;
  weekDays: {
    [day: string]: {
      workTime: string;
      status: 'working' | 'off' | 'half-day';
      appointments: number;
    };
  };
}

// 模拟按周排班数据
const weeklyScheduleData: WeeklySchedule[] = [
  {
    staffId: 1,
    weekDays: {
      '周一': { workTime: '9:00-21:00', status: 'working', appointments: 8 },
      '周二': { workTime: '9:00-21:00', status: 'working', appointments: 6 },
      '周三': { workTime: '9:00-18:00', status: 'half-day', appointments: 4 },
      '周四': { workTime: '9:00-21:00', status: 'working', appointments: 7 },
      '周五': { workTime: '9:00-21:00', status: 'working', appointments: 9 },
      '周六': { workTime: '9:00-21:00', status: 'working', appointments: 10 },
      '周日': { workTime: '休息', status: 'off', appointments: 0 }
    }
  },
  {
    staffId: 2,
    weekDays: {
      '周一': { workTime: '9:00-21:00', status: 'working', appointments: 5 },
      '周二': { workTime: '休息', status: 'off', appointments: 0 },
      '周三': { workTime: '9:00-21:00', status: 'working', appointments: 6 },
      '周四': { workTime: '9:00-21:00', status: 'working', appointments: 8 },
      '周五': { workTime: '9:00-18:00', status: 'half-day', appointments: 3 },
      '周六': { workTime: '9:00-21:00', status: 'working', appointments: 7 },
      '周日': { workTime: '9:00-21:00', status: 'working', appointments: 9 }
    }
  },
  {
    staffId: 3,
    weekDays: {
      '周一': { workTime: '13:00-21:00', status: 'half-day', appointments: 4 },
      '周二': { workTime: '9:00-21:00', status: 'working', appointments: 5 },
      '周三': { workTime: '9:00-21:00', status: 'working', appointments: 6 },
      '周四': { workTime: '休息', status: 'off', appointments: 0 },
      '周五': { workTime: '9:00-21:00', status: 'working', appointments: 7 },
      '周六': { workTime: '9:00-18:00', status: 'half-day', appointments: 3 },
      '周日': { workTime: '休息', status: 'off', appointments: 0 }
    }
  }
];

export function StoreConfiguration() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState<'staff' | 'service' | 'product' | 'membership' | null>(null);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [completePreviewOpen, setCompletePreviewOpen] = useState(false);
  const [publishDialogOpen, setPublishDialogOpen] = useState(false);
  const [membershipCards, setMembershipCards] = useState<MembershipCard[]>(membershipCardsData);
  const [consumptionRecords, setConsumptionRecords] = useState<ConsumptionRecord[]>(consumptionRecordsData);
  const [recordsDialogOpen, setRecordsDialogOpen] = useState(false);
  const [selectedCardForRecords, setSelectedCardForRecords] = useState<number | null>(null);
  
  // 消费统计状态
  const [statsViewType, setStatsViewType] = useState<'day' | 'week' | 'month'>('day');
  const [currentYear, setCurrentYear] = useState(2024);
  const [currentMonth, setCurrentMonth] = useState(12);
  const [currentDate, setCurrentDate] = useState('2024-12-21');
  
  // 排班管理状态
  const [scheduleViewType, setScheduleViewType] = useState<'day' | 'week'>('day');
  const [scheduleYear, setScheduleYear] = useState(2025);
  const [scheduleMonth, setScheduleMonth] = useState(9);
  const [scheduleDate, setScheduleDate] = useState('2025-09-10');

  const handleAdd = (type: 'staff' | 'service' | 'product' | 'membership') => {
    setDialogType(type);
    setEditingItem(null);
    setDialogOpen(true);
  };

  const handleEdit = (type: 'staff' | 'service' | 'product' | 'membership', item: any) => {
    setDialogType(type);
    setEditingItem(item);
    setDialogOpen(true);
  };

  const handleViewRecords = (cardId: number) => {
    setSelectedCardForRecords(cardId);
    setRecordsDialogOpen(true);
  };

  // 获取指定会员卡的消费记录
  const getRecordsForCard = (cardId: number) => {
    return consumptionRecords.filter(record => record.cardId === cardId);
  };

  // 获取当前统计数据
  const getCurrentStats = () => {
    switch (statsViewType) {
      case 'day':
        return consumptionStatsData[currentDate] || {
          date: currentDate,
          cash: 0,
          cardConsumption: 0,
          productConsumption: 0,
          manual: 0,
          cardDeduction: 0,
          cardGift: 0,
          customerCount: 0,
          serviceCount: 0,
          itemCount: 0,
          inventory: 0,
          debt: 0
        };
      case 'week':
        return weeklyStats['2024-W51'] || {};
      case 'month':
        return monthlyStats[`${currentYear}-${String(currentMonth).padStart(2, '0')}`] || {};
      default:
        return {};
    }
  };

  // 日期导航
  const navigateDate = (direction: 'prev' | 'next') => {
    if (statsViewType === 'day') {
      const date = new Date(currentDate);
      if (direction === 'prev') {
        date.setDate(date.getDate() - 1);
      } else {
        date.setDate(date.getDate() + 1);
      }
      setCurrentDate(date.toISOString().split('T')[0]);
    } else if (statsViewType === 'month') {
      if (direction === 'prev') {
        if (currentMonth === 1) {
          setCurrentMonth(12);
          setCurrentYear(currentYear - 1);
        } else {
          setCurrentMonth(currentMonth - 1);
        }
      } else {
        if (currentMonth === 12) {
          setCurrentMonth(1);
          setCurrentYear(currentYear + 1);
        } else {
          setCurrentMonth(currentMonth + 1);
        }
      }
    }
  };

  // 格式化日期显示
  const formatDateDisplay = () => {
    if (statsViewType === 'day') {
      const date = new Date(currentDate);
      const weekday = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()];
      return `${date.getDate()}号${weekday}`;
    } else if (statsViewType === 'week') {
      return '第51周';
    }
    return `${currentMonth}月`;
  };

  // 排班日期导航
  const navigateScheduleDate = (direction: 'prev' | 'next') => {
    if (scheduleViewType === 'day') {
      const date = new Date(scheduleDate);
      if (direction === 'prev') {
        date.setDate(date.getDate() - 1);
      } else {
        date.setDate(date.getDate() + 1);
      }
      setScheduleDate(date.toISOString().split('T')[0]);
      
      // 更新年月
      setScheduleYear(date.getFullYear());
      setScheduleMonth(date.getMonth() + 1);
    }
  };

  // 格式化排班日期显示
  const formatScheduleDateDisplay = () => {
    const date = new Date(scheduleDate);
    const weekday = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()];
    return `${date.getDate()}号${weekday}`;
  };

  // 获取排班状态样式
  const getScheduleStatusStyle = (status: 'available' | 'busy' | 'off' | null) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 border-green-300';
      case 'busy':
        return 'bg-red-100 border-red-300';
      case 'off':
        return 'bg-gray-100 border-gray-300';
      default:
        return 'bg-white border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-medium">网店配置</h1>
        <div className="flex gap-2">
          <Button onClick={() => setCompletePreviewOpen(true)} variant="outline">
            <Eye className="w-4 h-4 mr-2" />
            预览小程序
          </Button>
          <Button onClick={() => setPublishDialogOpen(true)}>
            <Globe className="w-4 h-4 mr-2" />
            发布小程序
          </Button>
        </div>
      </div>

      <Tabs defaultValue="salon" className="w-full">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="salon">美容院信息</TabsTrigger>
          <TabsTrigger value="staff">员工管理</TabsTrigger>
          <TabsTrigger value="services">服务项目</TabsTrigger>
          <TabsTrigger value="products">产品管理</TabsTrigger>
          <TabsTrigger value="membership">会员卡管理</TabsTrigger>
          <TabsTrigger value="statistics">消费统计管理</TabsTrigger>
          <TabsTrigger value="schedule">排班管理</TabsTrigger>
        </TabsList>

        {/* 美容院信息 */}
        <TabsContent value="salon" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>基本信息</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>美容院名称</Label>
                  <Input defaultValue={salonInfo.name} />
                </div>
                <div className="space-y-2">
                  <Label>营业时间</Label>
                  <Input defaultValue={salonInfo.businessHours} />
                </div>
                <div className="space-y-2">
                  <Label>联系电话</Label>
                  <Input defaultValue={salonInfo.phone} />
                </div>
                <div className="space-y-2">
                  <Label>邮箱地址</Label>
                  <Input defaultValue={salonInfo.email} />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label>地址</Label>
                  <Input defaultValue={salonInfo.address} />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label>描述</Label>
                  <Textarea defaultValue={salonInfo.description} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 员工管理 */}
        <TabsContent value="staff" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">员工管理</h3>
            <Button onClick={() => handleAdd('staff')}>
              <Plus className="w-4 h-4 mr-2" />
              添加员工
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {staffData.map((staff) => (
              <Card key={staff.id}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar>
                      <AvatarImage src={`/${staff.avatar}`} />
                      <AvatarFallback>{staff.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium">{staff.name}</h4>
                      <p className="text-sm text-muted-foreground">{staff.position}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>工作经验:</span>
                      <span>{staff.experience}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>评分:</span>
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span>{staff.rating}</span>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <span>状态:</span>
                      <Badge variant={staff.available ? 'default' : 'secondary'}>
                        {staff.available ? '可预约' : '不可预约'}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex justify-between mt-3">
                    <Button variant="outline" size="sm" onClick={() => handleEdit('staff', staff)}>
                      <Edit className="w-3 h-3 mr-1" />
                      编辑
                    </Button>
                    <Button variant="outline" size="sm">
                      <Trash2 className="w-3 h-3 mr-1" />
                      删除
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 服务项目 */}
        <TabsContent value="services" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">服务项目</h3>
            <Button onClick={() => handleAdd('service')}>
              <Plus className="w-4 h-4 mr-2" />
              添加服务
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {servicesData.map((service) => (
              <Card key={service.id}>
                <CardContent className="p-4">
                  <div className="mb-3">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">{service.name}</h4>
                      {service.popular && (
                        <Badge variant="default">热门</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{service.category}</p>
                    <p className="text-sm text-gray-600">{service.description}</p>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>时长:</span>
                      <span>{service.duration}分钟</span>
                    </div>
                    <div className="flex justify-between">
                      <span>价格:</span>
                      <span>¥{service.price}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>状态:</span>
                      <Badge variant={service.available ? 'default' : 'secondary'}>
                        {service.available ? '可预约' : '暂停'}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex justify-between mt-3">
                    <Button variant="outline" size="sm" onClick={() => handleEdit('service', service)}>
                      <Edit className="w-3 h-3 mr-1" />
                      编辑
                    </Button>
                    <Button variant="outline" size="sm">
                      <Trash2 className="w-3 h-3 mr-1" />
                      删除
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 产品管理 */}
        <TabsContent value="products" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">产品管理</h3>
            <Button onClick={() => handleAdd('product')}>
              <Plus className="w-4 h-4 mr-2" />
              添加产品
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {productsData.map((product) => (
              <Card key={product.id}>
                <CardContent className="p-4">
                  <div className="mb-3">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">{product.name}</h4>
                      {product.onSale && (
                        <Badge variant="destructive">促销</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{product.brand} · {product.category}</p>
                    <p className="text-sm text-gray-600">{product.description}</p>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>价格:</span>
                      <div className="flex items-center gap-2">
                        <span>¥{product.price}</span>
                        {product.originalPrice !== product.price && (
                          <span className="text-gray-400 line-through">¥{product.originalPrice}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <span>库存:</span>
                      <span>{product.stock}件</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between mt-3">
                    <Button variant="outline" size="sm" onClick={() => handleEdit('product', product)}>
                      <Edit className="w-3 h-3 mr-1" />
                      ���辑
                    </Button>
                    <Button variant="outline" size="sm">
                      <Trash2 className="w-3 h-3 mr-1" />
                      删除
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 会员卡管理 */}
        <TabsContent value="membership" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">会员卡管理</h3>
            <Button onClick={() => handleAdd('membership')}>
              <Plus className="w-4 h-4 mr-2" />
              创建会员卡
            </Button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {membershipCards.map((card) => (
              <Card key={card.id} className="overflow-hidden">
                <CardHeader className={`text-white ${
                  card.type === 'premium' ? 'bg-gradient-to-r from-purple-500 to-pink-500' :
                  card.type === 'vip' ? 'bg-gradient-to-r from-yellow-400 to-orange-500' :
                  'bg-gradient-to-r from-blue-500 to-cyan-500'
                }`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-white">{card.name}</CardTitle>
                      <p className="text-white/90 mt-2">¥{card.totalValue.toLocaleString()}</p>
                    </div>
                    <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                      {card.type === 'premium' ? '高端卡' : card.type === 'vip' ? 'VIP卡' : '标准卡'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground mb-4">{card.description}</p>
                  
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">有效期:</span>
                        <span className="ml-2">{card.validityPeriod}个月</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">限购:</span>
                        <span className="ml-2">每年{card.purchaseLimit}张</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">状态:</span>
                        <Badge variant={card.status === 'active' ? 'default' : 'secondary'} className="ml-2">
                          {card.status === 'active' ? '激活' : card.status === 'inactive' ? '停用' : '归档'}
                        </Badge>
                      </div>
                      <div>
                        <span className="text-muted-foreground">销量:</span>
                        <span className="ml-2">{card.salesCount}张</span>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-2">特权服务:</p>
                      <div className="flex flex-wrap gap-1">
                        {card.benefits.map((benefit, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {benefit}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-2">服务项目 ({card.services.length}项):</p>
                      <div className="max-h-32 overflow-y-auto space-y-1">
                        {card.services.map((service) => (
                          <div key={service.id} className="flex justify-between text-xs p-2 bg-gray-50 rounded">
                            <span>{service.name}</span>
                            <span className="text-muted-foreground">{service.duration}分钟</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between mt-4">
                    <Button variant="outline" size="sm" onClick={() => handleEdit('membership', card)}>
                      <Edit className="w-3 h-3 mr-1" />
                      编辑
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleViewRecords(card.id)}>
                      <History className="w-3 h-3 mr-1" />
                      消费记录
                    </Button>
                    <Button variant="outline" size="sm">
                      <Trash2 className="w-3 h-3 mr-1" />
                      删除
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 消费统计管理 */}
        <TabsContent value="statistics" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">消费统计管理</h3>
            <div className="flex gap-2">
              <Button 
                variant={statsViewType === 'day' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setStatsViewType('day')}
              >
                按日统计
              </Button>
              <Button 
                variant={statsViewType === 'week' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setStatsViewType('week')}
              >
                按周统计
              </Button>
              <Button 
                variant={statsViewType === 'month' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setStatsViewType('month')}
              >
                按月统计
              </Button>
            </div>
          </div>

          {/* 时间选择器 */}
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Select value={String(currentYear)} onValueChange={(value) => setCurrentYear(Number(value))}>
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2023">2023年</SelectItem>
                      <SelectItem value="2024">2024年</SelectItem>
                      <SelectItem value="2025">2025年</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {(statsViewType === 'month' || statsViewType === 'day') && (
                  <div className="flex items-center gap-2">
                    <Select value={String(currentMonth)} onValueChange={(value) => setCurrentMonth(Number(value))}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 12 }, (_, i) => (
                          <SelectItem key={i + 1} value={String(i + 1)}>
                            {i + 1}月
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {statsViewType === 'day' && (
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => navigateDate('prev')}
                    >
                      <ArrowLeft className="w-4 h-4" />
                      前一天
                    </Button>
                    <Badge variant="outline" className="px-3 py-1">
                      {formatDateDisplay()}
                    </Badge>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => navigateDate('next')}
                    >
                      后一天
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Calendar className="w-4 h-4 mr-2" />
                  导出报表
                </Button>
                <Button variant="outline" size="sm">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  数据分析
                </Button>
              </div>
            </div>
          </Card>

          {/* 统计数据网格 */}
          <div className="grid grid-cols-4 gap-4">
            {(() => {
              const stats = getCurrentStats();
              const statItems = [
                { 
                  id: 1, 
                  label: '现金', 
                  value: stats.cash || 0, 
                  unit: '元', 
                  icon: DollarSign,
                  color: 'text-green-600'
                },
                { 
                  id: 2, 
                  label: '卡项耗', 
                  value: stats.cardConsumption || 0, 
                  unit: '元', 
                  icon: CreditCard,
                  color: 'text-blue-600'
                },
                { 
                  id: 3, 
                  label: '产品耗', 
                  value: stats.productConsumption || 0, 
                  unit: '元', 
                  icon: ShoppingCart,
                  color: 'text-purple-600'
                },
                { 
                  id: 4, 
                  label: '手工', 
                  value: stats.manual || 0, 
                  unit: '元', 
                  icon: User,
                  color: 'text-orange-600'
                },
                { 
                  id: 5, 
                  label: '卡扣', 
                  value: stats.cardDeduction || 0, 
                  unit: '元', 
                  icon: CreditCard,
                  color: 'text-red-600'
                },
                { 
                  id: 6, 
                  label: '卡扣(送)', 
                  value: stats.cardGift || 0, 
                  unit: '元', 
                  icon: Gift,
                  color: 'text-pink-600'
                },
                { 
                  id: 7, 
                  label: '人头', 
                  value: stats.customerCount || 0, 
                  unit: '人', 
                  icon: Users,
                  color: 'text-indigo-600'
                },
                { 
                  id: 8, 
                  label: '人次', 
                  value: stats.serviceCount || 0, 
                  unit: '人/次', 
                  icon: TrendingUp,
                  color: 'text-cyan-600'
                },
                { 
                  id: 9, 
                  label: '项次', 
                  value: stats.itemCount || 0, 
                  unit: '次', 
                  icon: BarChart3,
                  color: 'text-emerald-600'
                },
                { 
                  id: 10, 
                  label: '出入库', 
                  value: stats.inventory || 0, 
                  unit: '个', 
                  icon: Package,
                  color: 'text-yellow-600'
                },
                { 
                  id: 11, 
                  label: '欠款', 
                  value: stats.debt || 0, 
                  unit: '元', 
                  icon: History,
                  color: 'text-gray-600'
                },
                { 
                  id: 12, 
                  label: '更多核对', 
                  value: null, 
                  unit: '', 
                  icon: MoreHorizontal,
                  color: 'text-slate-600',
                  isAction: true,
                  description: '支出，赠送等'
                }
              ];

              return statItems.map((item) => (
                <Card key={item.id} className="p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-sm text-muted-foreground">{item.id}.</span>
                        <span className="text-sm text-muted-foreground">{item.label}</span>
                      </div>
                      {item.isAction ? (
                        <div>
                          <Button variant="outline" size="sm" className="w-full">
                            查看详情
                          </Button>
                          <p className="text-xs text-muted-foreground mt-1">{item.description}</p>
                        </div>
                      ) : (
                        <div className="flex items-baseline gap-1">
                          <span className="text-2xl font-bold">{item.value.toLocaleString()}</span>
                          <span className="text-sm text-muted-foreground">{item.unit}</span>
                        </div>
                      )}
                    </div>
                    <item.icon className={`w-5 h-5 ${item.color}`} />
                  </div>
                </Card>
              ));
            })()}
          </div>
        </TabsContent>

        {/* 排班管理 */}
        <TabsContent value="schedule" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">员工排班管理</h3>
            <div className="flex gap-2">
              <Button 
                variant={scheduleViewType === 'day' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setScheduleViewType('day')}
              >
                按天
              </Button>
              <Button 
                variant={scheduleViewType === 'week' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setScheduleViewType('week')}
              >
                按周
              </Button>
            </div>
          </div>

          {/* 时间选择器和操作按钮 */}
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Select value={String(scheduleYear)} onValueChange={(value) => setScheduleYear(Number(value))}>
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2024">2024年</SelectItem>
                      <SelectItem value="2025">2025年</SelectItem>
                      <SelectItem value="2026">2026年</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center gap-2">
                  <Select value={String(scheduleMonth)} onValueChange={(value) => setScheduleMonth(Number(value))}>
                    <SelectTrigger className="w-20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 12 }, (_, i) => (
                        <SelectItem key={i + 1} value={String(i + 1)}>
                          {i + 1}月
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {scheduleViewType === 'day' && (
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => navigateScheduleDate('prev')}
                    >
                      <ArrowLeft className="w-4 h-4" />
                      前一天
                    </Button>
                    <Badge variant="outline" className="px-3 py-1">
                      {formatScheduleDateDisplay()}
                    </Badge>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => navigateScheduleDate('next')}
                    >
                      后一天
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Calendar className="w-4 h-4 mr-2" />
                  排期
                </Button>
                <Button variant="outline" size="sm">
                  <Copy className="w-4 h-4 mr-2" />
                  拷贝
                </Button>
                <Button variant="outline" size="sm">
                  <Edit className="w-4 h-4 mr-2" />
                  编辑
                </Button>
                <Button variant="outline" size="sm">
                  <Home className="w-4 h-4 mr-2" />
                  房间配置
                </Button>
                <Button variant="outline" size="sm">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>

          {/* 排班表格 */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  预约来店表(8:00-21:00)
                </div>
                <div className="flex gap-2">
                  <Badge variant="secondary" className="text-xs">搜索</Badge>
                  <Badge variant="secondary" className="text-xs">操作</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {scheduleViewType === 'day' ? (
                <div className="border rounded-lg overflow-hidden">
                  {/* 表头 */}
                  <div className="bg-gray-50 border-b">
                    <div className="grid grid-cols-4 gap-0">
                      <div className="p-3 border-r">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">时间/美容师</span>
                        </div>
                      </div>
                      {staffData.map((staff, index) => (
                        <div key={staff.id} className={`p-3 ${index < staffData.length - 1 ? 'border-r' : ''}`}>
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-orange-500 text-white text-xs flex items-center justify-center">
                              {index + 1}
                            </div>
                            <span className="text-sm font-medium">{staff.name}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 排班数据 */}
                  <div className="max-h-96 overflow-y-auto">
                    {scheduleData.map((slot, rowIndex) => (
                      <div key={slot.time} className={`grid grid-cols-4 gap-0 ${rowIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                        <div className="p-3 border-r border-b text-sm font-medium text-blue-600">
                          {slot.time}
                        </div>
                        {staffData.map((staff, colIndex) => {
                          const status = slot.staffSchedules[staff.id];
                          return (
                            <div 
                              key={staff.id} 
                              className={`p-3 border-b ${colIndex < staffData.length - 1 ? 'border-r' : ''} min-h-[48px] cursor-pointer hover:bg-gray-100 transition-colors ${getScheduleStatusStyle(status)}`}
                              onClick={() => {
                                // 这里可以添加点击事件处理逻辑
                                console.log(`Clicked ${staff.name} at ${slot.time}`);
                              }}
                            >
                              {status && (
                                <div className="text-xs text-center">
                                  {status === 'busy' && '忙碌'}
                                  {status === 'available' && '空闲'}
                                  {status === 'off' && '休息'}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                /* 按周视图 */
                <div className="border rounded-lg overflow-hidden">
                  {/* 表头 */}
                  <div className="bg-gray-50 border-b">
                    <div className="grid grid-cols-8 gap-0">
                      <div className="p-3 border-r">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">员工/星期</span>
                        </div>
                      </div>
                      {['周一', '周二', '周三', '周四', '周五', '周六', '周日'].map((day, index) => (
                        <div key={day} className={`p-3 text-center ${index < 6 ? 'border-r' : ''}`}>
                          <div className="flex flex-col items-center gap-1">
                            <span className="text-sm font-medium">{day}</span>
                            <span className="text-xs text-muted-foreground">
                              {new Date(2025, 8, 9 + index).getDate()}号
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 按周排班数据 */}
                  <div className="max-h-96 overflow-y-auto">
                    {weeklyScheduleData.map((staffSchedule, staffIndex) => {
                      const staff = staffData.find(s => s.id === staffSchedule.staffId);
                      if (!staff) return null;

                      return (
                        <div key={staff.id} className={`grid grid-cols-8 gap-0 ${staffIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                          <div className="p-3 border-r border-b">
                            <div className="flex items-center gap-2">
                              <div className="w-6 h-6 rounded-full bg-orange-500 text-white text-xs flex items-center justify-center">
                                {staffIndex + 1}
                              </div>
                              <div>
                                <div className="text-sm font-medium">{staff.name}</div>
                                <div className="text-xs text-muted-foreground">{staff.position}</div>
                              </div>
                            </div>
                          </div>
                          
                          {['周一', '周二', '周三', '周四', '周五', '周六', '周日'].map((day, dayIndex) => {
                            const daySchedule = staffSchedule.weekDays[day];
                            const getWeekStatusStyle = (status: string) => {
                              switch (status) {
                                case 'working':
                                  return 'bg-green-50 border-green-200';
                                case 'half-day':
                                  return 'bg-yellow-50 border-yellow-200';
                                case 'off':
                                  return 'bg-gray-50 border-gray-200';
                                default:
                                  return 'bg-white border-gray-200';
                              }
                            };

                            return (
                              <div 
                                key={`${staff.id}-${day}`}
                                className={`p-3 border-b ${dayIndex < 6 ? 'border-r' : ''} min-h-[80px] cursor-pointer hover:bg-gray-100 transition-colors ${getWeekStatusStyle(daySchedule.status)}`}
                                onClick={() => {
                                  console.log(`Clicked ${staff.name} on ${day}`);
                                }}
                              >
                                <div className="text-xs space-y-1">
                                  <div className="font-medium">
                                    {daySchedule.status === 'working' && '全天班'}
                                    {daySchedule.status === 'half-day' && '半天班'}
                                    {daySchedule.status === 'off' && '休息'}
                                  </div>
                                  <div className="text-muted-foreground">
                                    {daySchedule.workTime}
                                  </div>
                                  {daySchedule.appointments > 0 && (
                                    <div className="flex items-center gap-1">
                                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                      <span className="text-blue-600">{daySchedule.appointments}个预约</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>

                  {/* 按周统计信息 */}
                  <div className="border-t bg-gray-50 p-3">
                    <div className="grid grid-cols-8 gap-0 text-xs">
                      <div className="font-medium text-muted-foreground">本周汇总</div>
                      {['周一', '周二', '周三', '周四', '周五', '周六', '周日'].map((day) => {
                        const dayTotal = weeklyScheduleData.reduce((total, staff) => 
                          total + staff.weekDays[day].appointments, 0
                        );
                        const workingStaff = weeklyScheduleData.filter(staff => 
                          staff.weekDays[day].status !== 'off'
                        ).length;
                        
                        return (
                          <div key={day} className="text-center space-y-1">
                            <div className="text-blue-600 font-medium">{dayTotal}个预约</div>
                            <div className="text-muted-foreground">{workingStaff}人上班</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* 排班说明 */}
          <Card className="p-4">
            <div className="flex items-start gap-4">
              <div className="flex-1">
                <h4 className="font-medium mb-2">排班状态说明</h4>
                <div className="flex gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-green-100 border border-green-300 rounded"></div>
                    <span>空闲可预约</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-red-100 border border-red-300 rounded"></div>
                    <span>已有预约</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-gray-100 border border-gray-300 rounded"></div>
                    <span>休息时间</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">营业时间：8:00-21:00</p>
                <p className="text-sm text-muted-foreground">时间间隔：30分钟</p>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 小程序预览对话框 */}
      <CompleteMiniprogramPreview 
        open={completePreviewOpen} 
        onOpenChange={setCompletePreviewOpen} 
      />

      {/* 发布对话框 */}
      <Dialog open={publishDialogOpen} onOpenChange={setPublishDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>发布小程序</DialogTitle>
            <DialogDescription>
              确认发布您的美容院小程序，发布后客户可以通过小程序预约服务。
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setPublishDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={() => {
              setPublishDialogOpen(false);
              // 这里可以添加实际的发布逻辑
            }}>
              确认发布
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* 消费记录对话框 */}
      <Dialog open={recordsDialogOpen} onOpenChange={setRecordsDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>消费记录</DialogTitle>
            <DialogDescription>
              查看会员卡消费记录详情
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>日期</TableHead>
                  <TableHead>客户姓名</TableHead>
                  <TableHead>服务项目</TableHead>
                  <TableHead>消费金额</TableHead>
                  <TableHead>服务员工</TableHead>
                  <TableHead>余额</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedCardForRecords && getRecordsForCard(selectedCardForRecords).map((record) => (
                  <TableRow key={record.id}>
                    <TableCell>{record.consumptionDate}</TableCell>
                    <TableCell>{record.customerName}</TableCell>
                    <TableCell>{record.serviceName}</TableCell>
                    <TableCell>¥{record.consumptionAmount}</TableCell>
                    <TableCell>{record.staff}</TableCell>
                    <TableCell>¥{record.remainingBalance}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* 通用编辑对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? '编辑' : '添加'} 
              {dialogType === 'staff' ? '员工' : 
               dialogType === 'service' ? '服务' : 
               dialogType === 'product' ? '产品' :
               dialogType === 'membership' ? '会员卡' : ''}
            </DialogTitle>
            <DialogDescription>
              {editingItem ? '修改' : '创建新的'}
              {dialogType === 'staff' ? '员工信息和工作安排' : 
               dialogType === 'service' ? '服务项目详情和价格设置' : 
               dialogType === 'product' ? '产品信息和库存管理' :
               dialogType === 'membership' ? '会员卡配置和服务项目' : '项目'}
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            {dialogType === 'staff' && <StaffForm />}
            {dialogType === 'service' && <ServiceForm />}
            {dialogType === 'product' && <ProductForm />}
            {dialogType === 'membership' && <MembershipForm />}
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={() => setDialogOpen(false)}>
              保存
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );

  // 内部表单组件
  function StaffForm() {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>员工姓名</Label>
            <Input placeholder="请输入员工姓名" defaultValue={editingItem?.name} />
          </div>
          <div className="space-y-2">
            <Label>职位</Label>
            <Select defaultValue={editingItem?.position}>
              <SelectTrigger>
                <SelectValue placeholder="选择职位" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="senior-beautician">高级美容师</SelectItem>
                <SelectItem value="chief-stylist">首席发型师</SelectItem>
                <SelectItem value="skin-manager">皮肤管理师</SelectItem>
                <SelectItem value="junior-beautician">初级美容师</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>工作经验</Label>
            <Input placeholder="如：5年" defaultValue={editingItem?.experience} />
          </div>
          <div className="space-y-2">
            <Label>专业技能</Label>
            <Input placeholder="如：面部护理,抗衰管理" defaultValue={editingItem?.specialties?.join(',')} />
          </div>
          <div className="col-span-2 space-y-2">
            <Label>个人简介</Label>
            <Textarea placeholder="请输入个人简介" defaultValue={editingItem?.introduction} />
          </div>
          <div className="col-span-2 space-y-2">
            <Label>头像</Label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Camera className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p className="text-sm text-gray-600">点击上传头像</p>
              <p className="text-xs text-gray-400">建议尺寸：400x400px</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Switch defaultChecked={editingItem?.available !== false} />
            <Label>是否可预约</Label>
          </div>
        </div>
      </div>
    );
  }

  function ServiceForm() {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>服务名称</Label>
            <Input placeholder="请输入服务名称" defaultValue={editingItem?.name} />
          </div>
          <div className="space-y-2">
            <Label>服务分类</Label>
            <Select defaultValue={editingItem?.category}>
              <SelectTrigger>
                <SelectValue placeholder="选择分类" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="facial-care">面部护理</SelectItem>
                <SelectItem value="anti-aging">抗衰管理</SelectItem>
                <SelectItem value="hair-service">发型服务</SelectItem>
                <SelectItem value="body-care">身体护理</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>服务时长（分钟）</Label>
            <Input type="number" placeholder="如：90" defaultValue={editingItem?.duration} />
          </div>
          <div className="space-y-2">
            <Label>服务价格（元）</Label>
            <Input type="number" placeholder="如：298" defaultValue={editingItem?.price} />
          </div>
          <div className="col-span-2 space-y-2">
            <Label>服务描述</Label>
            <Textarea placeholder="请输入服务详细描述" defaultValue={editingItem?.description} />
          </div>
          <div className="col-span-2 space-y-2">
            <Label>服务图片</Label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Camera className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p className="text-sm text-gray-600">点击上传服务图片</p>
              <p className="text-xs text-gray-400">建议尺寸：750x500px</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Switch defaultChecked={editingItem?.popular} />
            <Label>热门推荐</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Switch defaultChecked={editingItem?.available !== false} />
            <Label>可预约</Label>
          </div>
        </div>
      </div>
    );
  }

  function ProductForm() {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>产品名称</Label>
            <Input placeholder="请输入产品名称" defaultValue={editingItem?.name} />
          </div>
          <div className="space-y-2">
            <Label>产品分类</Label>
            <Select defaultValue={editingItem?.category}>
              <SelectTrigger>
                <SelectValue placeholder="选择分类" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="skincare">护肤品</SelectItem>
                <SelectItem value="essence">精华液</SelectItem>
                <SelectItem value="haircare">护发产品</SelectItem>
                <SelectItem value="makeup">彩妆产品</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>产品品牌</Label>
            <Input placeholder="请输入品牌名称" defaultValue={editingItem?.brand} />
          </div>
          <div className="space-y-2">
            <Label>库存数量</Label>
            <Input type="number" placeholder="如：25" defaultValue={editingItem?.stock} />
          </div>
          <div className="space-y-2">
            <Label>销售价格（元）</Label>
            <Input type="number" placeholder="如：1580" defaultValue={editingItem?.price} />
          </div>
          <div className="space-y-2">
            <Label>原价（元）</Label>
            <Input type="number" placeholder="如：1680" defaultValue={editingItem?.originalPrice} />
          </div>
          <div className="col-span-2 space-y-2">
            <Label>产品描述</Label>
            <Textarea placeholder="请输入产品详细描述" defaultValue={editingItem?.description} />
          </div>
          <div className="col-span-2 space-y-2">
            <Label>产品图片</Label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Camera className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p className="text-sm text-gray-600">点击上传产品图片</p>
              <p className="text-xs text-gray-400">建议尺寸：800x800px</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Switch defaultChecked={editingItem?.onSale} />
            <Label>促销活动</Label>
          </div>
        </div>
      </div>
    );
  }

  function MembershipForm() {
    const [services, setServices] = useState<MembershipService[]>(editingItem?.services || []);
    
    const addService = () => {
      setServices([...services, {
        id: `service-${Date.now()}`,
        name: '',
        duration: 60,
        category: '面部',
        singlePrice: 0,
        packagePrice: 0,
        packageCount: 10
      }]);
    };

    const updateService = (index: number, field: keyof MembershipService, value: any) => {
      const updatedServices = [...services];
      updatedServices[index] = { ...updatedServices[index], [field]: value };
      setServices(updatedServices);
    };

    const removeService = (index: number) => {
      setServices(services.filter((_, i) => i !== index));
    };

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>会员卡名称</Label>
            <Input placeholder="请输入会员卡名称" defaultValue={editingItem?.name} />
          </div>
          <div className="space-y-2">
            <Label>卡片类型</Label>
            <Select defaultValue={editingItem?.type}>
              <SelectTrigger>
                <SelectValue placeholder="选择类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="premium">高端卡</SelectItem>
                <SelectItem value="vip">VIP卡</SelectItem>
                <SelectItem value="standard">标准卡</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>卡片价值（元）</Label>
            <Input type="number" placeholder="如：2991" defaultValue={editingItem?.totalValue} />
          </div>
          <div className="space-y-2">
            <Label>有效期（月）</Label>
            <Input type="number" placeholder="如：12" defaultValue={editingItem?.validityPeriod} />
          </div>
          <div className="space-y-2">
            <Label>每年限购数量</Label>
            <Input type="number" placeholder="如：1" defaultValue={editingItem?.purchaseLimit} />
          </div>
          <div className="space-y-2">
            <Label>状态</Label>
            <Select defaultValue={editingItem?.status}>
              <SelectTrigger>
                <SelectValue placeholder="选择状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">激活</SelectItem>
                <SelectItem value="inactive">停用</SelectItem>
                <SelectItem value="archived">归档</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2 space-y-2">
            <Label>卡片描述</Label>
            <Textarea placeholder="请输入卡片描述" defaultValue={editingItem?.description} />
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="font-medium">服务项目配置</h4>
            <Button type="button" variant="outline" onClick={addService}>
              <Plus className="w-4 h-4 mr-2" />
              添加服务
            </Button>
          </div>

          {services.length > 0 && (
            <div className="space-y-4">
              {services.map((service, index) => (
                <Card key={service.id} className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                    <div className="space-y-2">
                      <Label>服务名称</Label>
                      <Input 
                        placeholder="如：巨补水"
                        value={service.name}
                        onChange={(e) => updateService(index, 'name', e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>分类</Label>
                      <Select 
                        value={service.category}
                        onValueChange={(value) => updateService(index, 'category', value as '面部' | '身体')}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="面部">面部</SelectItem>
                          <SelectItem value="身体">身体</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>时长（分钟）</Label>
                      <Input 
                        type="number"
                        value={service.duration}
                        onChange={(e) => updateService(index, 'duration', parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>单次价格（元）</Label>
                      <Input 
                        type="number"
                        value={service.singlePrice}
                        onChange={(e) => updateService(index, 'singlePrice', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>套餐价格（元）</Label>
                      <Input 
                        type="number"
                        value={service.packagePrice}
                        onChange={(e) => updateService(index, 'packagePrice', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div className="space-y-2 flex items-end">
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm" 
                        onClick={() => removeService(index)}
                        className="w-full"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }
}