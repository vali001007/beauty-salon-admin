const fs = require('fs');

// Read the file content
const content = fs.readFileSync('/components/DataCollection.tsx', 'utf8');

// Split into lines for easier analysis
const lines = content.split('\n');

let inDialog = false;
let dialogStart = -1;
let dialogContentStart = -1;
let hasDescription = false;
const results = [];

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  if (line.includes('<Dialog ')) {
    inDialog = true;
    dialogStart = i;
    hasDescription = false;
  }
  
  if (inDialog && line.includes('<DialogContent')) {
    dialogContentStart = i;
  }
  
  if (inDialog && line.includes('<DialogDescription')) {
    hasDescription = true;
  }
  
  if (inDialog && line.includes('</Dialog>')) {
    results.push({
      start: dialogStart,
      contentStart: dialogContentStart,
      hasDescription,
      preview: lines.slice(Math.max(0, dialogStart - 1), dialogStart + 10).join('\n')
    });
    inDialog = false;
    dialogStart = -1;
    dialogContentStart = -1;
    hasDescription = false;
  }
}

console.log('Found dialogs:', results.length);
results.forEach((dialog, index) => {
  console.log(`\nDialog ${index + 1} (line ${dialog.start + 1}):`, dialog.hasDescription ? 'HAS description' : 'MISSING description');
  if (!dialog.hasDescription) {
    console.log('Preview:');
    console.log(dialog.preview);
  }
});