// Search for DialogContent without DialogDescription
const fs = require('fs');
const content = fs.readFileSync('/components/DataCollection.tsx', 'utf8');

// Find all DialogContent occurrences
const dialogContentMatches = content.match(/<DialogContent[^>]*>/g);
const dialogDescriptionMatches = content.match(/<DialogDescription[^>]*>/g);

console.log('DialogContent found:', dialogContentMatches?.length || 0);
console.log('DialogDescription found:', dialogDescriptionMatches?.length || 0);

// Find positions of DialogContent
let pos = 0;
const dialogPositions = [];
while ((pos = content.indexOf('<DialogContent', pos)) !== -1) {
  const endPos = content.indexOf('</DialogContent>', pos);
  if (endPos !== -1) {
    const dialogContent = content.substring(pos, endPos + 16);
    const hasDescription = dialogContent.includes('<DialogDescription');
    dialogPositions.push({
      start: pos,
      hasDescription,
      content: dialogContent.substring(0, 200) + '...'
    });
  }
  pos++;
}

console.log('Dialog positions and descriptions:', dialogPositions);