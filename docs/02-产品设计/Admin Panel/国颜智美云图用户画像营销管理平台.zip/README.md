
  # 国颜智美云图用户画像营销管理平台

  This is a code bundle for 国颜智美云图用户画像营销管理平台. The original project is available at https://www.figma.com/design/mbahKHQKavg22DaB5No9ZN/%E5%9B%BD%E9%A2%9C%E6%99%BA%E7%BE%8E%E4%BA%91%E5%9B%BE%E7%94%A8%E6%88%B7%E7%94%BB%E5%83%8F%E8%90%A5%E9%94%80%E7%AE%A1%E7%90%86%E5%B9%B3%E5%8F%B0.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  